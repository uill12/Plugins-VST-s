#!/usr/bin/env python3
"""Deterministic ORIGINAL synthesized 96-kHz mono 24-bit material bank.
No third-party audio recordings, no attribution dependencies, no ambience baked in.
VTRB1 container: 8-byte magic, uint32 count/rate/frames, then per-slot PCM24 LE.
"""
import numpy as np
from scipy.signal import butter,sosfilt
from pathlib import Path
import struct, hashlib, argparse
ROOT=Path(__file__).resolve().parent
NAMES=[
 'Bronze Quiver','Hollow Glass','Copper Bloom','Bell Dust','Reed Current','Plucked Wire','Wooden Vein','Ceramic Grain',
 'Felt Pulse','Membrane Ember','Air Column','Spring Alloy','Ice Lattice','Stone Ripple','Water Pearl','Electric Filament',
 'Soft Machine','Sand Drift','Vowel Foam','Carbon Friction','Polyphonic Metal','Marimba Wood','Granular Resin','Light Ash',
 'Ink Falls','Shimmer Film','Mechanical Ember','Earth Drone','Azure Swell','Porcelain Bloom','Mineral Rain','Living Circuit'
]
def render(j,fs,n):
 rng=np.random.default_rng(31033+12331*j)
 t=np.arange(n,dtype=np.float64)/fs
 noise=rng.standard_normal(n)
 f0=78*(2**((j*3%29)/12))
 families=j%8
 if families==0: # struck metal, independent inharmonic partials
  ratios=[1,2.41,3.96,5.43,7.91,10.12]
  harmonics=sum(np.sin(2*np.pi*f0*r*t+r*1.8)*np.exp(-t*(.34+r*.13))/(r**.7) for r in ratios)
  env=(1-np.exp(-t*880))
 elif families==1: # glassy mallet / bell
  ratios=[1,2.0,2.99,4.18,6.3,8.9]
  harmonics=sum(np.sin(2*np.pi*f0*r*t+r*.41)*np.exp(-t*(.18+r*.19))/r**1.18 for r in ratios)
  env=1-np.exp(-t*400)
 elif families==2: # harmonic reed, subtle breath
  harmonics=sum(np.sin(2*np.pi*f0*k*t+.06*np.sin(2*np.pi*4.1*t))/(k**(.58+j/120)) for k in range(1,16))
  env=(1-np.exp(-t*35))*np.exp(-t*.4)
 elif families==3: # plucked string
  harmonics=sum(np.cos(2*np.pi*f0*k*t)*np.exp(-t*(.32+.075*k))*((1 if k%2 else -.32)/k**.85) for k in range(1,14))
  env=(1-np.exp(-t*1500))
 elif families==4: # modal drums and wood
  ratios=[1,1.51,2.28,3.54,4.42,6.82]
  harmonics=sum(np.sin(2*np.pi*f0*r*t)*np.exp(-t*(1.1+.34*r))/r**1.3 for r in ratios)
  env=(1-np.exp(-t*1100))*np.exp(-t*.65)
 elif families==5: # slow circuit / drone, dry mono
  harmonics=sum(np.sin(2*np.pi*f0*r*t+.18*np.sin(2*np.pi*(.13+.02*j)*t))*np.exp(-t*.14)/(r**1.22) for r in [1,2,3,4,6,8,12])
  env=(1-np.exp(-t*8))
 elif families==6: # organically beating soft partials
  harmonics=sum((np.sin(2*np.pi*f0*k*t)+.45*np.sin(2*np.pi*f0*k*1.007*t))/(k**1.15) for k in range(1,12))
  env=(1-np.exp(-t*24))*np.exp(-t*.34)
 else: # textured stretched resonance
  harmonics=sum(np.sin(2*np.pi*f0*(r+.015*r*r)*t)*np.exp(-t*(.24+.05*r))/r**.9 for r in range(1,13))
  env=(1-np.exp(-t*95))
 # Dry, frequency-shaped broadband excitation. No reverb or stereo spatial effect.
 cutoff=np.clip(850+j*460,120,18000)
 if j%3==0:
  noise=sosfilt(butter(2,cutoff,fs=fs,output='sos'),noise)
 elif j%3==1:
  noise=sosfilt(butter(2,[max(80,cutoff/3),min(22000,cutoff*1.5)],btype='bandpass',fs=fs,output='sos'),noise)
 else:
  noise=sosfilt(butter(2,cutoff,fs=fs,btype='highpass',output='sos'),noise)
 noise=noise/(max(0.001,np.std(noise))*3)
 ne=np.exp(-t*(2+j%7))
 mix=np.tanh((.84*harmonics*env+.22*noise*ne)*(1+j%4*.08))
 mix*=np.minimum(1,np.maximum(0,(n-np.arange(n))/int(fs*.04)))
 peak=np.max(np.abs(mix))
 return np.asarray(np.round(np.clip(mix/peak*.88,-1,1)*8388607),dtype=np.int32)
def pcm24_le(a):
 u=a.astype(np.uint32)&0xffffff
 out=np.empty((len(a),3),dtype=np.uint8)
 out[:,0]=u&255;out[:,1]=(u>>8)&255;out[:,2]=(u>>16)&255
 return out.tobytes()
def generate(output):
 fs=96000; dur=2.25; frames=int(fs*dur)
 output=Path(output)
 h=hashlib.sha256()
 with output.open('wb') as f:
  header=struct.pack('<8sIII',b'VTRB1\0\0\0',len(NAMES),fs,frames)
  f.write(header);h.update(header)
  for i,name in enumerate(NAMES):
   data=pcm24_le(render(i,fs,frames))
   f.write(data);h.update(data)
   print(f'{i:02d} {name}: {len(data)} bytes')
 print('FILE',output,'BYTES',output.stat().st_size,'SHA256',h.hexdigest())
 (output.parent/'soundbank_manifest.txt').write_text('ALBEDO ORIGINAL PCM24 96kHz - dry mono\n'+f'File SHA256: {h.hexdigest()}\n'+'\n'.join(f'{i:02d} {n}' for i,n in enumerate(NAMES))+'\n')
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--output',default=str(ROOT/'Albedo_Materia32_PCM24_96k.vtrb'));a=ap.parse_args();generate(a.output)
