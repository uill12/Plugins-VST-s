# Albedo Quintessential Synth · CP12 GUI Parity Source

**Goal:** ship Windows x64 CLAP + VST3 using one native Win32/GDI editor, retaining the approved horizontal alchemical GUI in both light Albedo and dark Nigredo modes. No WebView2 or HTML renderer is needed at runtime.

**This package is a Windows-buildable source checkpoint, not Windows plugin binaries.** Windows SDK and Steinberg VST3 SDK are unavailable in this Linux environment; a real Windows host build remains required. A separate Linux x86-64 `.clap` has been built and smoke-tested for the DSP, but its GUI is not the Win32 editor.

## Contents
- `src/` + `include/`: DSP, CLAP/VST3 wrappers, native editor and new `albedo_waveform_visuals.hpp`.
- `resources/Albedo_CP07_Horizontal.html`: responsive HTML **reference**; it does not run inside the plugin.
- `resources/Albedo_Horizontal_Light.bmp` and `...Nigredo.bmp`: exact approved source bitmap references embedded into native editor.
- `resources/Albedo_Materia32_PCM24_96k.vtrb`: embedded material bank.
- `Presets/`: 64 factory `.albp` patches + historical archive.
- `Build_Windows_x64.ps1`: Windows CMake/MSVC build, VST3 SDK acquisition and PE export verification.
- `.github/workflows/albedo-cp12-windows.yml`: Windows 2022 CI workflow (runs after full source/assets are pushed to GitHub).
- `QA_CP12.md`, `QA_CP12_HTML_Interaction_Results.json`, screenshots: test evidence and limitations.

### Compile on Windows
In PowerShell from this extracted directory, with Visual Studio 2022 Desktop C++ workload, Windows SDK, CMake, Python 3 and Git installed:
```powershell
.\Build_Windows_x64.ps1 -Configuration Release
```
The script creates `Albedo_Quintessential_Synth_Windows_x64_CP12.zip` **only after** both genuine Windows .clap / .vst3 binaries compile, native tests pass, and PE export checks succeed.

### Host installation after actual Windows build
- CLAP: `C:\Program Files\Common Files\CLAP\Albedo_Quintessential_Synth.clap`
- VST3: `C:\Program Files\Common Files\VST3\Albedo_Quintessential_Synth.vst3` (bundle folder)
Then rescan plugins in Bitwig and compare both formats using the same preset and sample rate.

**Rollback:** prior CP11 source checkpoint remains untouched. Read `QA_CP12.md` before treating native visuals as verified.
