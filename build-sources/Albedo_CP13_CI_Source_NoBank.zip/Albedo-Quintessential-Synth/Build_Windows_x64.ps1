# Albedo Quintessential Synth CP12 — RGNES-gated Windows x64 CLAP/VST3 build.
# Requires Windows 10/11, Visual Studio 2022 C++ build tools, CMake, Git,
# network access to Steinberg's official VST3 SDK unless -VST3Sdk is supplied.
param(
 [string]$VST3Sdk='',
 [ValidateSet('Release','Debug')][string]$Configuration='Release',
 [switch]$ClapOnly,
 [string]$SdkCommit='3cdf9ca5d1f5b1b21e0a86832aa4abe55607bd96'
)
$ErrorActionPreference='Stop'
$src=Split-Path -Parent $MyInvocation.MyCommand.Path
foreach($name in @('cmake','ctest','git')) {
 if(-not (Get-Command $name -ErrorAction SilentlyContinue)) { throw "Required build tool not found in PATH: $name" }
}
if (-not (Get-Command 'vswhere.exe' -ErrorAction SilentlyContinue)) {
 Write-Host 'Visual Studio C++ is required. The CMake -G Visual Studio 17 2022 configuration verifies its installation.'
}
$requiredAssets=@('resources/Albedo_Horizontal_Light.bmp','resources/Albedo_Horizontal_Nigredo.bmp',
                 'resources/Albedo_Materia32_PCM24_96k.vtrb','include/albedo_factory_patches.hpp')
foreach($rel in $requiredAssets){if(-not(Test-Path (Join-Path $src $rel))) {throw "Required native asset missing: $rel"}}

$build=Join-Path $src 'build_windows_x64'
# SDK provenance: Steinberg's upstream VST3 SDK 3.8.1 (2026-08-11).
# This is a real external dependency, never a renamed CLAP binary.
$resolvedSdkCommit='not-used-clap-only'
if(-not $ClapOnly){
 if(-not $VST3Sdk){$VST3Sdk=Join-Path $src 'external\vst3sdk'}
 if(-not [IO.Path]::IsPathRooted($VST3Sdk)){$VST3Sdk=Join-Path $src $VST3Sdk}
 $VST3Sdk=[IO.Path]::GetFullPath($VST3Sdk)
 if(-not (Test-Path (Join-Path $VST3Sdk '.git'))){
  if(Test-Path $VST3Sdk){
   # Allow explicitly supplied release archives that include the real SDK.
   if(-not(Test-Path (Join-Path $VST3Sdk 'public.sdk\source\vst\vstaudioeffect.h'))){
    throw 'VST3Sdk exists but is not a valid official SDK checkout or source tree.'
   }
   if($SdkCommit){throw 'To enforce a pinned SDK commit, pass a git checkout rather than a source archive.'}
  }else{
   New-Item -ItemType Directory -Force -Path (Split-Path -Parent $VST3Sdk) | Out-Null
   & git clone https://github.com/steinbergmedia/vst3sdk.git $VST3Sdk
   if($LASTEXITCODE -ne 0){throw 'Could not clone the official Steinberg VST3 SDK.'}
  }
 }
 if(Test-Path (Join-Path $VST3Sdk '.git')){
  # Full clones already contain the pinned ancestor. Fetch only if needed.
  & git -C $VST3Sdk cat-file -e "$SdkCommit^{commit}" 2>$null
  if($LASTEXITCODE -ne 0){
   & git -C $VST3Sdk fetch origin $SdkCommit
   if($LASTEXITCODE -ne 0){throw "Could not fetch pinned VST3 SDK commit $SdkCommit"}
  }
  & git -C $VST3Sdk checkout --detach $SdkCommit
  if($LASTEXITCODE -ne 0){throw "Could not check out pinned VST3 SDK commit $SdkCommit"}
  & git -C $VST3Sdk submodule update --init --recursive
  if($LASTEXITCODE -ne 0){throw 'Official SDK submodule initialization failed.'}
  $resolvedSdkCommit=(& git -C $VST3Sdk rev-parse HEAD).Trim()
  if($LASTEXITCODE -ne 0 -or $resolvedSdkCommit -ne $SdkCommit){throw 'VST3 SDK commit SHA does not match the required source revision.'}
  $submoduleState=& git -C $VST3Sdk submodule status --recursive
  if($LASTEXITCODE -ne 0){throw 'Cannot verify official SDK submodules.'}
  if($submoduleState | Where-Object {$_ -match '^[-+U]'}){throw 'SDK submodules are missing or disagree with pinned revision.'}
 }
 if(-not (Test-Path (Join-Path $VST3Sdk 'public.sdk\source\vst\vstaudioeffect.h'))){
  throw 'Official VST3 SDK public headers are missing.'
 }
 Write-Host "Using Steinberg VST3 SDK: $VST3Sdk @ $resolvedSdkCommit"
}
$buildVST3=if($ClapOnly){'OFF'}else{'ON'}
$cmakeArgs=@('-S',$src,'-B',$build,'-G','Visual Studio 17 2022','-A','x64',"-DVITRIOL_BUILD_VST3=$buildVST3")
if(!$ClapOnly){$cmakeArgs+= "-DVST3_SDK_DIR=$VST3Sdk"}
& cmake @cmakeArgs
if($LASTEXITCODE -ne 0){throw 'CMake configuration failed'}
& cmake --build $build --config $Configuration --parallel
if($LASTEXITCODE -ne 0){throw 'Win64 compilation failed'}
& ctest --test-dir $build --config $Configuration --output-on-failure
if($LASTEXITCODE -ne 0){throw 'Native tests failed'}
$dist=Join-Path $src 'dist_windows_CP12'
New-Item -ItemType Directory -Force -Path $dist | Out-Null
$clap=Get-ChildItem -Path $build -Filter 'Albedo_Quintessential_Synth.clap' -Recurse -File | Where-Object {$_.FullName -match ('[\\/]' + [regex]::Escape($Configuration) + '[\\/]')} | Select-Object -First 1
if(!$clap){$clap=Get-ChildItem -Path $build -Filter 'Albedo_Quintessential_Synth.clap' -Recurse -File | Select-Object -First 1}
if(!$clap){throw 'Compiled CLAP binary was not found'}
Copy-Item $clap.FullName (Join-Path $dist 'Albedo_Quintessential_Synth.clap') -Force
# Include a real stand-alone GUI tester built from the same editor and artwork.
$preview=Get-ChildItem -Path $build -Filter 'albedo_native_gui_preview.exe' -Recurse -File |
  Where-Object {$_.FullName -match ('[\\/]' + [regex]::Escape($Configuration) + '[\\/]')} | Select-Object -First 1
if(!$preview){$preview=Get-ChildItem -Path $build -Filter 'albedo_native_gui_preview.exe' -Recurse -File | Select-Object -First 1}
if(!$preview){throw 'Native preview EXE was not compiled; cannot verify GUI build'}
Copy-Item $preview.FullName (Join-Path $dist 'albedo_native_gui_preview.exe') -Force
if(!$ClapOnly){
 # Resolve the VST3 bundle directory, not its nested PE module with the same extension.
 $vst3=Get-ChildItem -Path $build -Filter 'Albedo_Quintessential_Synth.vst3' -Recurse -Directory | Select-Object -First 1
 if(!$vst3){throw 'Compiled VST3 bundle was not found'}
 Copy-Item -LiteralPath $vst3.FullName -Destination (Join-Path $dist 'Albedo_Quintessential_Synth.vst3') -Force -Recurse
}
# SHA-256 hashes are generated after PE verification; do not treat any source file as compiled output.
# Verify actual compiled Windows x64 PE images. A renamed Linux .so is not a Windows plugin.
function Assert-WindowsX64PE([string]$file) {
  if (!(Test-Path -LiteralPath $file -PathType Leaf)) { throw "Missing plugin PE binary: $file" }
  $stream=[IO.File]::OpenRead($file)
  try {
    $reader=[IO.BinaryReader]::new($stream)
    if($reader.ReadUInt16() -ne 0x5A4D){throw "Not a Windows MZ executable: $file"}
    $stream.Position=0x3C
    $peOffset=$reader.ReadInt32()
    if($peOffset -lt 64 -or $peOffset -gt $stream.Length-8){throw "Invalid PE header pointer: $file"}
    $stream.Position=$peOffset
    if($reader.ReadUInt32() -ne 0x00004550){throw "Not a PE executable: $file"}
    if($reader.ReadUInt16() -ne 0x8664){throw "Not an AMD64 binary: $file"}
  } finally { $stream.Dispose() }
}
Assert-WindowsX64PE (Join-Path $dist 'Albedo_Quintessential_Synth.clap')
Assert-WindowsX64PE (Join-Path $dist 'albedo_native_gui_preview.exe')
if(!$ClapOnly) {
 $native=Get-ChildItem -Path (Join-Path $dist 'Albedo_Quintessential_Synth.vst3') -Recurse -File | Where-Object {$_.Name -like '*.vst3'} | Select-Object -First 1
 if(!$native){throw 'VST3 bundle lacks an executable Windows .vst3 module'}
 Assert-WindowsX64PE $native.FullName
}
# Inspect export names, not just MZ/PE/Machine. This catches non-CLAP DLLs and
# VST3 bundles containing an unrelated/wrongly exported module.
$python=Get-Command python -ErrorAction SilentlyContinue
if(-not $python){throw 'Python 3 is required for the PE export gate; Windows CI includes it'}
& python (Join-Path $src 'tools\verify_pe_exports.py') (Join-Path $dist 'Albedo_Quintessential_Synth.clap') --require clap_entry
if($LASTEXITCODE -ne 0){throw 'CLAP export verification failed'}
if(!$ClapOnly){
 & python (Join-Path $src 'tools\verify_pe_exports.py') $native.FullName --require GetPluginFactory InitDll ExitDll
 if($LASTEXITCODE -ne 0){throw 'VST3 exports are incomplete'}
}
# Manifest, checksums and artifact archive generated only after genuine PE/AMD64 checks succeed.
$releaseFormats=if($ClapOnly){@('CLAP')}else{@('CLAP','VST3')}
$checks=Get-ChildItem $dist -Recurse -File | ForEach-Object {
 [PSCustomObject]@{path=$_.FullName.Substring($dist.Length+1).Replace('\','/');sha256=(Get-FileHash $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant();size_bytes=$_.Length}
}
$checks | ConvertTo-Json -Depth 4 | Set-Content -Encoding UTF8 (Join-Path $dist 'SHA256.json')
@{
 project='Albedo Quintessential Synth';checkpoint='CP12';version='1.0.0-cp12';
 platform='Windows x64';formats=$releaseFormats;
 build_date=(Get-Date -Format 'yyyy-MM-dd');status='compiled-and-offline-tested';
 host_qa='NOT TESTED in Bitwig';plugin_clap_id='org.vitriol.opussonorum';
 source='CP12 parity improvements; official Steinberg VST3 SDK 3.8.1 pin';vst3_sdk_commit=$resolvedSdkCommit;previous_release='CP10 source checkpoint'
} | ConvertTo-Json -Depth 4 | Set-Content -Encoding UTF8 (Join-Path $dist 'RELEASE_MANIFEST.json')
# Distribution bundle is created only after both compilation and Windows local tests succeed.
$zip=Join-Path $src 'Albedo_Quintessential_Synth_Windows_x64_CP12.zip'
if(Test-Path $zip){Remove-Item -Force $zip}
Compress-Archive -Path (Join-Path $dist '*') -DestinationPath $zip -CompressionLevel Optimal
Write-Host 'CP12 Windows build outputs are in dist_windows_CP12.'
Write-Host "Distribution ZIP: $zip"
Write-Host 'Not yet host-certified: scan both formats in a test Bitwig project and validate GUI, state, automation, MIDI and load/reopen.'
