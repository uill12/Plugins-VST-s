#!/usr/bin/env python3
"""Controlled source/reference acquisition from the user's Nereida CP40 ZIP.

Usage:
 python tools/import_nereida_cp40.py /path/to/Nereida_v0.40.1_CP40_Full_Source.zip
 python tools/import_nereida_cp40.py /path/to/zip --extract

No DSP or preset code is automatically merged. No audio is copied: the user
requires original/verified CC0 samples and no incompatible plugin identities.
"""
import argparse,hashlib,json,pathlib,re,sys,zipfile

WHITELIST=[
 r'(^|/)NereidaUiScene\.h$',r'(^|/)NexoDspShared\.h$',
 r'(^|/)renderer_migration/[^/]+\.(?:glsl|vert|frag|md|py)$',
 r'(^|/)(?:build_clap_windows_x64|build_windows_x64)\.sh$',
 r'(^|/)(?:test_window_scale[^/]*|test_foundation_multi_context[^/]*)\.(?:cpp|py)$',
 r'(^|/)RUN_V028_TESTS\.sh$',
 r'(^|/)CP[0-9][^/]*_Checkpoint\.md$'
]
MAX_SIZE=3*1024*1024
MAX_TOTAL=16*1024*1024

def scan(archive, out,extract):
 results=[];total=0
 with zipfile.ZipFile(archive) as z:
  entries=z.infolist()
  for info in entries:
   name=info.filename.replace('\\','/')
   if info.is_dir() or info.flag_bits & 1:continue
   pp=pathlib.PurePosixPath(name)
   if pp.is_absolute() or '..' in pp.parts or any(':' in part for part in pp.parts):continue
   if info.file_size>MAX_SIZE or total+info.file_size>MAX_TOTAL or not any(re.search(p,name,re.I) for p in WHITELIST):continue
   if pp.suffix.lower() in ('.wav','.aif','.aiff','.flac','.mp3','.dll','.vst3','.clap','.exe','.albp','.nexopreset'):continue
   if (info.external_attr>>16)&0o170000==0o120000:continue
   data=z.read(info)
   sha=hashlib.sha256(data).hexdigest()
   item={'source':name,'bytes':len(data),'sha256':sha,'status':'reference_only_unreviewed'}
   if extract:
    rel=pathlib.PurePosixPath(name)
    dest=out / pathlib.Path(*rel.parts)
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes(data)
    item['staged_path']=str(dest)
   total+=len(data);results.append(item)
 manifest={'archive_name':str(archive),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
           'files':results,'total_staged_bytes':total,'extracted':extract,
           'policy':'reference only; no automatic source merge; audio requires CC0 provenance and technical QA'}
 out.mkdir(parents=True,exist_ok=True)
 (out/'NEREIDA_REVIEW_MANIFEST.json').write_text(json.dumps(manifest,indent=2))
 return len(results)

if __name__=='__main__':
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('archive',type=pathlib.Path)
 ap.add_argument('--extract',action='store_true')
 ap.add_argument('--output',type=pathlib.Path,default=pathlib.Path('references/nereida_cp40_review'))
 a=ap.parse_args()
 if not a.archive.is_file():sys.exit('Nereida source archive is not present; nothing imported.')
 print('Nereida CP40 candidates:',scan(a.archive,a.output,a.extract))
