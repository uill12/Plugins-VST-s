#include "vitriol_dsp.hpp"
#include <array>
#include <cmath>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <cstring>
using namespace vitriol;
namespace fs=std::filesystem;
static void u32(std::ofstream&f,uint32_t x){for(int j=0;j<4;j++){char b=char((x>>(j*8))&255);f.write(&b,1);}}
static void u16(std::ofstream&f,uint16_t x){for(int j=0;j<2;j++){char b=char((x>>(j*8))&255);f.write(&b,1);}}
int main(int argc,char**argv){
 if(argc!=4){std::cerr<<"render_factory_audition <presets-folder> <soundbank.vtrb> <out.wav>\n";return 1;}
 Synth synth;constexpr int SR=48000;synth.prepare(SR);
 if(!synth.loadResourceBank(argv[2]))return 2;
 std::vector<fs::path>patches;
 for(auto& p:fs::directory_iterator(argv[1]))if(p.path().extension()==".albp")patches.push_back(p.path());
 std::sort(patches.begin(),patches.end());
 if(patches.size()!=64)return 3;
 const int picks[]={0,9,18,27,36,45,54,63};
 std::vector<int32_t>interleaved;interleaved.reserve(8*SR*2*2);
 std::array<float,128>l{},r{};
 for(int which:picks){
  std::ifstream in(patches[which]);std::string magic;int version=0;in>>magic>>version;
  if(magic!="ALBEDO_NATIVE_PATCH"||version!=1)return 4;
  uint32_t id;double val;while(in>>id>>val)synth.setParam(id,val);
  synth.reset();synth.noteOn(48+which%6*3,.8);
  const int frames=SR*2,cut=int(1.52*SR);
  for(int offset=0;offset<frames;offset+=128){
   if(offset==cut/128*128)synth.noteOff(48+which%6*3);
   synth.process(l.data(),r.data(),128);
   for(int k=0;k<128;k++){
    int pos=offset+k;if(pos>=frames)break;
    double fade=std::min({1.0,pos/(.018*SR), (frames-pos)/(.065*SR)});
    for(float v:{l[k],r[k]}){
     double smp=std::clamp(double(v)*fade,-.999999,.999999);
     interleaved.push_back(int32_t(std::lrint(smp*8388607.)));
    }
   }
  }
 }
 std::ofstream f(argv[3],std::ios::binary);
 if(!f)return 5;
 uint32_t dataBytes=uint32_t(interleaved.size()*3);
 f.write("RIFF",4);u32(f,36+dataBytes);f.write("WAVEfmt ",8);u32(f,16);u16(f,1);u16(f,2);u32(f,SR);u32(f,SR*6);u16(f,6);u16(f,24);
 f.write("data",4);u32(f,dataBytes);
 for(int32_t s:interleaved){for(int b=0;b<3;b++){char x=char((uint32_t(s)>>(8*b))&255);f.write(&x,1);}}
 std::cout<<"Audition: "<<interleaved.size()/2<<" frames, 8 factory patches, PCM24 stereo 48k\n";
}
