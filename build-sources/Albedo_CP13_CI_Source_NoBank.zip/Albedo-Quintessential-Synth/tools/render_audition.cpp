// Standalone CP06 technical sound examples (no musical-reference imitation).
// Four successive source-method notes in 48 kHz stereo signed PCM24.
#include "vitriol_dsp.hpp"
#include <cstdint>
#include <cmath>
#include <algorithm>
#include <vector>
#include <cstdio>
#include <string>
using namespace vitriol;
static void u32(FILE*f,uint32_t x){for(int i=0;i<4;i++)std::fputc((x>>(8*i))&255,f);}
static void u16(FILE*f,uint16_t x){for(int i=0;i<2;i++)std::fputc((x>>(8*i))&255,f);}
int main(int argc,char**argv){
 if(argc<3){std::fprintf(stderr,"usage: vitriol_audition <material.vtrb> <out.wav>\n");return 1;}
 constexpr uint32_t sr=48000,seconds=10,frames=sr*seconds;
 Synth s;if(!s.loadResourceBank(argv[1]))return 2;
 FILE* f=std::fopen(argv[2],"wb");if(!f)return 3;
 std::fwrite("RIFF",1,4,f);u32(f,36+frames*6);std::fwrite("WAVEfmt ",1,8,f);u32(f,16);u16(f,1);u16(f,2);u32(f,sr);u32(f,sr*6);u16(f,6);u16(f,24);
 std::fwrite("data",1,4,f);u32(f,frames*6);
 double peak=0;for(int section=0;section<4;section++){
  s.prepare(sr);
  for(int e=0;e<4;e++){s.setParam(1001+e*32,e==section?1:0);s.setParam(1000+e*32+2,section==2?75:90);}
  s.setParam(9000,-4);s.setParam(9001,1);s.setParam(9002,3);s.setParam(6020,0);
  s.setParam(3100,section==2?.002:.04);s.setParam(3101,section==2?1.2:.32);
  s.setParam(3102,section==2?0:80);s.setParam(3103,.6);
  s.setParam(3000,15000);s.setParam(3003,17000);s.setParam(3001,8);s.setParam(3004,6);
  s.setParam(2100,(section%2)*75+10);s.setParam(2101,(section/2)*70+10);
  s.setParam(2200,0);s.setParam(2201,0);s.setParam(2202,0);s.setParam(2203,0);s.setParam(2204,0);s.setParam(2205,0);
  int e=section,base=1000+e*32;
  const int methods[]={1,3,2,9};const int notes[]={57,52,74,48};
  s.setParam(base,methods[section]);s.setParam(base+6,section==0?82:section==1?65:section==2?54:44);
  s.setParam(base+7,section==0?25:section==1?77:section==2?83:74);
  s.setParam(base+8,section==0?35:section==1?61:section==2?62:48);
  s.setParam(base+9,section==0?50:section==1?69:section==2?57:63);
  s.setParam(base+10,section*7+2);s.setParam(base+16,5.5);
  s.setParam(4003,section%4);s.setParam(4000,8.7);
  s.noteOn(notes[section],.76);
  float l[128]{},r[128]{};
  for(int i=0;i<int(sr*2.5);i+=128){int n=std::min(128,int(sr*2.5)-i);
   if(i>=int(sr*1.9)&&i-128<int(sr*1.9))s.noteOff(notes[section]);
   s.process(l,r,n);
   for(int j=0;j<n;j++){int frame=i+j;double fade=std::clamp(double(std::min(frame,int(sr*2.5)-1-frame))/1200.,0.,1.);
    for(double sample:{double(l[j]),double(r[j])}){
     sample=std::clamp(sample*fade,-1.0,1.0);peak=std::max(peak,std::abs(sample));
     int32_t q=int32_t(std::lround(sample*8388607.0));for(int k=0;k<3;k++)std::fputc((uint32_t(q)>>(k*8))&0xff,f);
    }
   }
  }
 }
 std::fclose(f);std::printf("Generated 4 x 2.5 s technical notes, 48 kHz stereo PCM24, peak %.6f\n",peak);return peak>.0001?0:4;
}
