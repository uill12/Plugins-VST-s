#!/usr/bin/env python3
"""Synchronize the horizontal web design reference with real CP07 factory metadata.
HTML is an editor mockup; .albp/C++ patches are the instrument truth.
"""
from pathlib import Path
import re,json,subprocess
r=Path(__file__).resolve().parents[1]
p=r/'resources'/'Albedo_CP07_Horizontal.html';s=p.read_text()
manifest=json.loads((r/'Presets'/'CP07_Quintessential_Collection'/'MANIFEST.json').read_text())
source=r/'Presets'/'CP07_Quintessential_Collection'
entries=[]
for item in manifest['patches']:
 values={int(k):float(v) for k,v in (line.split() for line in (source/item['file']).read_text().splitlines()[1:])}
 entries.append({'name':item['name'],'methods':item['methods'],'macros':[round(values[2000+i]) for i in range(7)],'xy':[round(values[2100]/100,3),round(values[2101]/100,3)]})
list_js='const NPRESETS='+json.dumps(entries,ensure_ascii=False,separators=(',',':'))+';'
s,n=re.subn(r'const NPRESETS=\[.*?\];',lambda _:list_js,s,count=1,flags=re.S)
assert n==1,n
# Use the first factory as starting look in the browser, not an obsolete sketch.
s=s.replace("name:'Aether Cartography'", "name:'"+entries[0]['name']+"'")
s=s.replace("METHODS[[1,3,2,4][i]]","METHODS["+str(entries[0]['methods']).replace(' ','')+"[i]]")
s=s.replace('const cp04Registry=', 'const cp04Registry=')
registry=json.loads(subprocess.check_output([str(r/'build'/'vitriol_registry_export')],text=True))
pos=s.index('const cp04Registry=')
end=s.index(';',pos)
# Registry is one line of JSON; synchronize exact parameter descriptors.
old=json.loads(s[pos+len('const cp04Registry='):end]);old['parameters']=registry['parameters'];old['schema']='albedo-cp07-197-parameters'
s=s[:pos]+'const cp04Registry='+json.dumps(old,ensure_ascii=False,separators=(',',':'))+s[end:]
# Human-facing status and library info.
s=s.replace('Aether Cartography','Vitreous | Glass Pressure')
s=s.replace('Untitled Opus','Untitled Albedo')
s=s.replace('The VITRIOL Workbench','Albedo Quintessential Synth Workbench')
s=s.replace('const cp04Registry=', 'const cp04Registry=')
s=s.replace('HTML control state; native DSP uses identical host parameter identifiers','HTML UI demonstration only; native .albp patches contain 197 real DSP values')
s=s.replace('<small>ALBEDO / QUINTESSENTIAL SYNTH · INSTRUMENT CORE</small>','<small>ALBEDO QUINTESSENTIAL SYNTH · INSTRUMENT CORE</small>')
p.write_text(s)
print('synced 64 CP07 HTML factory metadata and',len(registry['parameters']),'live host parameter descriptors')
