#!/usr/bin/env python3
"""RGNES CP11 PE export audit (Win64 AMD64 DLL). No PE parsing deps.
Usage: python verify_pe_exports.py <file.clap|file.vst3> --require clap_entry|GetPluginFactory ...
Verifies PE32+ x64 machine, DLL bit and actual named exports. Cannot prove host compatibility.
"""
import argparse, json, struct, sys
from pathlib import Path

class PEError(Exception): pass

def inspect(raw):
    def at(off,fmt):
        n=struct.calcsize(fmt)
        if off<0 or off+n>len(raw): raise PEError(f"Out-of-bounds PE access at {off}")
        return struct.unpack_from(fmt,raw,off)[0] if len(struct.unpack_from(fmt,raw,off))==1 else struct.unpack_from(fmt,raw,off)
    if len(raw)<0x100 or raw[:2]!=b'MZ': raise PEError('Not an MZ executable')
    pe=at(0x3c,'<I')
    if pe<0x40 or pe>len(raw)-0x110 or raw[pe:pe+4]!=b'PE\0\0': raise PEError('Missing PE signature')
    coff=pe+4
    machine,sections,_,_,_,opt_size,chars=at(coff,'<HHIIIHH')
    if machine!=0x8664:raise PEError(f'Not AMD64 (machine={machine:#x})')
    if not chars & 0x2000:raise PEError('Not a DLL (IMAGE_FILE_DLL absent)')
    opt=coff+20
    if opt_size<112 or at(opt,'<H')!=0x20b:raise PEError('Not PE32+ optional header')
    count=at(opt+108,'<I')
    if count<1:raise PEError('No PE data directory')
    exp_rva,exp_size=at(opt+112,'<II')
    sh=opt+opt_size
    regions=[]
    for i in range(sections):
        pos=sh+40*i
        vsize,va,rawsize,rawptr=at(pos+8,'<IIII')
        regions.append((va,max(vsize,rawsize),rawptr,rawsize))
    def rva(addr):
        for va,extent,ptr,rawsize in regions:
            if va<=addr<va+extent:
                delta=addr-va
                if delta>=rawsize:raise PEError(f'RVA {addr:#x} lies beyond section raw bytes')
                return ptr+delta
        raise PEError(f'RVA {addr:#x} not mapped to file bytes')
    exports=[]
    if exp_rva and exp_size:
        e=rva(exp_rva)
        if e+40>len(raw):raise PEError('Truncated export directory')
        _,_,_,_,_,base,nfunc,nname,funcs,names,ordinals=at(e,'<IIHHIIIIIII')
        if nname>4096:raise PEError('Suspicious export name count')
        for i in range(nname):
            name_rva=at(rva(names)+4*i,'<I')
            start=rva(name_rva)
            end=raw.find(b'\0',start,min(len(raw),start+256))
            if end<0:raise PEError('Missing export-name terminator')
            exports.append(raw[start:end].decode('ascii','replace'))
    return {'format':'PE32+','architecture':'x86_64','dll':True,'exports':exports}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('binary',type=Path);ap.add_argument('--require',nargs='+',required=True)
    a=ap.parse_args()
    try:
        info=inspect(a.binary.read_bytes())
        missing=sorted(set(a.require)-set(info['exports']))
        if missing:raise PEError('Missing exports: '+', '.join(missing))
        print(json.dumps({'binary':str(a.binary),'status':'PASS',**info},indent=2))
    except (PEError,OSError,ValueError) as exc:
        print(f'PE_EXPORT_AUDIT_FAIL: {exc}',file=sys.stderr);return 2
    return 0

if __name__=='__main__':sys.exit(main())
