#!/usr/bin/env python3
"""RGNES gate for Albedo CP11 assets/source. Prevent partial/incorrect Windows builds."""
import hashlib, json, struct, sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
manifest=json.loads((root/'CP12_BUILDGATE_MANIFEST.json').read_text())
checks=manifest['audio_gui_source_sha256']|manifest['art_sha256']|manifest['new_gui_sources_sha256']
errors=[]
for rel,ref in checks.items():
 path=root/rel
 if not path.is_file():errors.append('missing '+rel);continue
 hash=hashlib.file_digest(path.open('rb'),'sha256').hexdigest()
 if hash != ref:errors.append(f'{rel}: SHA-256 mismatch expected={ref} got={hash}')
presets=list((root/'Presets/CP07_Quintessential_Collection').glob('*.albp'))
if len(presets)!=64:errors.append(f'factory preset count should be 64, found {len(presets)}')
bank=root/'resources/Albedo_Materia32_PCM24_96k.vtrb'
if bank.exists():
    with bank.open('rb') as f:head=f.read(20)
    if len(head)!=20:errors.append('bank header truncated')
    else:
        magic,count,rate,frames=struct.unpack('<8sIII',head)
        if (magic,count,rate,frames)!=(b'VTRB1\0\0\0',32,96000,216000):errors.append(f'invalid bank header: {magic,count,rate,frames}')
        expected=20+32*216000*3
        if bank.stat().st_size!=expected:errors.append(f'bank size {bank.stat().st_size} expected {expected}')
if errors:
    print('CP12 SOURCE ASSET GATE FAIL:','; '.join(errors),file=sys.stderr);sys.exit(2)
print('CP12 SOURCE ASSET GATE PASS: preserved DSP+GUI source, 3 exact resources, 32 materials, 64 factory presets')
