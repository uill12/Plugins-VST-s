#!/usr/bin/env python3
"""Revoice 64 factory patches against the 32 original PCM24/96kHz resources.

Factory source of truth: host parameter registry output, material-bank metadata,
role-first envelope/pitch constraints, distinct layer-engine plans, and a
reproducible static C++ header for the Windows editor. No FM algorithms.
"""
from pathlib import Path
from collections import Counter
import hashlib,json,subprocess,math,sys
R=Path(__file__).resolve().parents[1]
export=R/'build'/'vitriol_registry_export'
if len(sys.argv)>1:export=Path(sys.argv[1])
assert export.exists(),f'first build registry exporter: {export}'
registry=json.loads(subprocess.check_output([str(export)],text=True))
P=registry['parameters'];pids=[int(p['id']) for p in P];defs={int(p['id']):float(p['default']) for p in P}
assert len(pids)==197,len(pids)
assert not any('FM' in p['name'] for p in P)
MATNAMES=['Bronze Quiver','Hollow Glass','Copper Bloom','Bell Dust','Reed Current','Plucked Wire','Wooden Vein','Ceramic Grain',
           'Felt Pulse','Membrane Ember','Air Column','Spring Alloy','Ice Lattice','Stone Ripple','Water Pearl','Electric Filament',
           'Soft Machine','Sand Drift','Vowel Foam','Carbon Friction','Polyphonic Metal','Marimba Wood','Granular Resin','Light Ash',
           'Ink Falls','Shimmer Film','Mechanical Ember','Earth Drone','Azure Swell','Porcelain Bloom','Mineral Rain','Living Circuit']
FAMILIES=[
 ('Vitreous',[1,7,12,29],[1,2,7,4],(68,29,42,23,70,33,49)),
 ('Organic',[4,6,10,21],[5,7,1,3],(45,35,61,32,39,49,64)),
 ('Metallic',[0,2,11,20],[2,5,1,7],(81,50,46,54,44,39,23)),
 ('Cellular',[16,15,26,31],[9,1,3,7],(58,68,64,43,61,91,68)),
 ('Nocturnal',[19,23,24,27],[6,4,7,9],(24,48,77,38,45,51,87)),
 ('Aerial',[14,18,25,28],[3,1,4,7],(62,30,69,15,89,55,74)),
 ('Kinetic',[8,9,17,22],[0,7,6,3],(69,50,34,89,34,56,22)),
 ('Chimeric',[3,5,13,30],[8,5,2,3],(64,59,56,48,65,72,54)),
]
assert set(idx for _,indices,_,_ in FAMILIES for idx in indices)==set(range(32))
ROLES=[
 ('Bass',(.005,.19,81,.27,700),[0,1,2,7],[85,42,29,35],(12,0),(-7,0,0,1)),
 ('Lead',(.018,.25,67,.28,3900),[1,2,8,5],[70,57,38,24],(28,10),(-7,0,0,0)),
 ('Pad',(.42,1.2,76,2.4,5400),[1,4,3,9],[53,56,48,43],(54,42),(-8,0,0,0)),
 ('Pluck',(.003,.16,24,.33,4100),[5,7,2,6],[84,37,25,0],(22,0),(-3,0,0,0)),
 ('Keys',(.009,.51,48,.72,3300),[2,5,7,0],[76,50,38,19],(35,10),(-5,0,0,0)),
 ('Percussion',(.002,.10,9,.18,7300),[6,7,5,3],[86,69,20,0],(18,0),(-5,0,0,0)),
 ('Drone',(.95,2.1,87,4.1,5100),[4,9,3,1],[44,54,56,51],(67,56),(-8,0,0,0)),
 ('Texture',(.19,1.75,67,2.7,9100),[3,6,7,9],[52,55,57,43],(62,66),(-8,0,0,0)),
]
TITLES={
'Vitreous':['Glass Pressure','Silica Glint','Crystal Veil','Ceramic Speck','Porcelain Chord','Ice Fragment','Hollow Horizon','Refractive Dust'],
'Organic':['Reed Floor','Woodgrain Voice','Breathing Canopy','Bamboo Needle','Resonant Bark','Root Percussion','Air Column Earth','Living Branch'],
'Metallic':['Copper Foundation','Bronze Filament','Alloy Halo','Spring Needle','Bellplate Keys','Iron Strike','Metallic Monolith','Resonant Shards'],
'Cellular':['Soft Circuit','Voltage Edge','Circuit Bloom','Logic Grain','Electric Keyway','Mechanical Tick','Self Similar Current','Automata Rain'],
'Nocturnal':['Carbon Sub','Inkline Signal','Shadow Canopy','Ash Splinter','Dark Matter Keys','Black Dust Hit','Earth Nocturne','Ember Drift'],
'Aerial':['Aqua Current','Vowel Ribbon','Azure Suspension','Pearl Bead','Cloud Glass','Rainfall Skin','High Atmosphere','Floating Particles'],
'Kinetic':['Felt Foundation','Mechanism Signal','Pulse Loom','Sand Trigger','Membrane Keys','Transient Atlas','Motor Field','Rhythmic Detritus'],
'Chimeric':['Stoneweight Bass','Wireline Lead','Bellfield Pad','Quartz Pluck','Mineral Keys','Fracture Knock','Composite Resonance','Hybrid Matter'],
}

out=R/'Presets'/'CP07_Quintessential_Collection';out.mkdir(parents=True,exist_ok=True)
rows=[]
for fi,(family,material,signature,macro) in enumerate(FAMILIES):
 for ri,(role,(attack,decay,sustain,release,cut),role_methods,role_levels,xy,other) in enumerate(ROLES):
  q=defs.copy()
  # Sonic function is the priority; material family sets spectral identity.
  main=role_methods[0]
  if ri in (0,1,2,6,7):
   main=signature[0] if fi in (1,3,4,5,7) else role_methods[0]
  methods=[main,role_methods[1],signature[2],role_methods[3]]
  if role=='Percussion':methods[0]=6 if fi in (0,2,4,6) else 7
  if role=='Pluck':methods[0]=5
  if role=='Drone':methods[0]=4 if fi%2==0 else 9
  if role=='Texture':methods[0]=3 if fi%2==0 else 7
  if role=='Keys' and fi in (0,2,7):methods[0]=2
  # Ensure at least one *enabled* source plays the PCM material bank.
  nactive=[3,2,4,2,3,2,4,4][ri]
  # Shift part of the bank-driven sources into true granular playback.
  # This avoids making every patch a reskinned time-warp sampler.
  if (fi*3+ri)%3==1:
   methods=[3 if (j<nactive and m==7) else m for j,m in enumerate(methods)]
  if 3 not in methods[:nactive] and 7 not in methods[:nactive]:methods[nactive-1]=3 if (fi+ri)%2 else 7
  # Role-specific ADSR, filter and effects, tempered by material family.
  q.update({3100:min(8,attack*(.86+fi*.042)),3101:min(10,decay*(.88+fi*.043)),3102:max(0,min(100,sustain+((fi%3)-1)*5)),3103:min(18,release*(.83+fi*.075)),
    3000:max(80,min(19200,cut*(.78+.072*fi))),3001:10+ri*2+fi%4*3,3002:(3+fi*1.3) if ri in (0,1,5) else (1+fi*.6),
    3003:min(18800,cut* (1.26+fi*.035)),3004:10+(fi%4)*4,3005:1+fi*.4,
    3010: (1 if fi in (1,3) else 2 if fi==5 and ri>3 else 0),3011: 0 if ri in (0,1,3) else 1,3012: 1 if ri in (0,1,3,4) else 2 if fi in (2,6) else 0,
    3120:16 if ri in (1,3,4,5) else 8,3121:10 if ri in (2,6,7) else 0,
    3122: max(.001,attack*.75),3123: min(9,decay*.9),3124: (26 if role in ('Percussion','Pluck') else 52),3125:max(.02,release*.65),
    3110:0,3111: 1 if ri==0 else 0,3112:0,3130:0 if ri in (0,3,4,5) else 6+fi*3,3131:0 if ri in (0,3,5) else 1.5+fi*.55,
    4000: .09+fi*.21+ri*.13,4001: 10 if ri in (0,3,5) else min(85,21+fi*6+ri*3),4002: 15+fi*5,4003: fi%4,
    4010:.06+fi*.11+ri*.07,4011:(fi+ri)%5,4012:(fi+2*ri)%5,4013:75 if ri in (0,3,5) else 90,4014:60 if ri in (0,3,5) else 88,
    5000: 3+fi*2+(5 if ri in (0,1,5) else 0),5001:1,
    5002: 4 if ri in (0,3,5) else 18+fi*3,5003:1,
    5004: 5 if ri in (0,3,5) else 35+fi*4,5005:1,
    5006: 3 if ri in (0,1,3,4,5) else 8+fi*3,5007:1 if ri in (2,6,7) else 0,
    5008:.14+fi*.04,5009:30+fi*7,5010: 55+fi*5,5011:85 if ri in (0,3,5) else 110+fi*3,5012:0,
    2000:macro[0],2001:macro[1],2002:macro[2],2003:macro[3],2004:macro[4],2005:macro[5],2006:macro[6],
    2100:xy[0]+(fi%3)*3,2101:xy[1]+((fi+ri)%4)*3,
    9000:other[0],9001:1,9002:0,
    6020: 0,8300: 3 if ri in (2,6,7) else 2,
    8000:0,8001:0,8002: 12 if ri in (0,3,5) else 26,
    8003:4,8004:10,8005:18+fi*3,
    8006:8,8007:7,8008:16 if ri in (2,6,7) else 7,
    8009:0,8010:0,8011:0,
   })
  for pair in range(6):q[2200+pair]=0 if ri in (0,3,5) else 6+(pair*3+fi*4)%20
  for e,m in enumerate(methods):
   base=1000+32*e
   active=e<([3,2,4,2,3,2,4,4][ri])
   level=role_levels[e]*(.78+fi*.028)
   char=[ [48,44,51,42],[38,56,47,45],[52,62,49,55],[46,42,61,55] ][e]
   q.update({base:m,base+1:int(active),base+2: min(100,level) if active else 0,
     base+3: 0 if e==0 else ([-12,-5,7,12][e]+(fi%3-1)*2),
     base+4: [-12,17,-25,30][e] if ri in (2,6,7) else [-5,6,-15,16][e],
     base+5:1,base+6:char[0]+fi*2+ri%4,
     base+7:char[1]+(ri*7+fi*3)%19-9,
     base+8:char[2]+((ri+fi)%6)*4-10,
     base+9:char[3]+(fi*5+ri*3)%15-7,
     base+10:material[e],base+11:1 if ri in (0,3,5) else (2+(ri+fi+e)%3 if e<2 else 1),
     base+12:0 if ri in (0,3,5) else 5+(fi+e*3)%12,
     base+13:20 if ri in (0,3,5) else 52+(fi+e*2)%20,
     base+14:85 if ri in (0,3,5) else 52,
     base+15:(fi+ri+e)%4,base+16:4+((fi*3+ri*2+e*5)%21),
     base+17: .7+((fi*2+ri+e)%14)*.2,
     base+18:35+(fi*9+ri*3+e*6)%55,
     base+19:13 if ri==0 and e==0 else 0,
     base+20:0 if ri in (0,3,5) else 10+fi*4,
     base+21:0 if ri in (0,3,5) else (fi*7+e*3)%17-8,
   })
  # Family signatures: control timbral identities using source method characteristics.
  if family=='Vitreous':q[1006]=32;q[1007]=63;q[2004]=74
  if family=='Organic':q[1007]=24;q[4001]=19 if ri==0 else 42;q[3010]=1
  if family=='Metallic':q[1008]=78;q[3001]=24;q[1000+16]=21
  if family=='Cellular':q[2005]=86;q[4001]=67;q[4003]=[0,1,2,3][ri%4]
  if family=='Nocturnal':q[2000]=22;q[3000]*=.56;q[5004]+=11
  if family=='Aerial':q[5004]=46 if ri not in (0,3,5) else 7;q[2004]=94
  if family=='Kinetic':q[3100]=min(.06,q[3100]);q[2003]=87;q[5002]=6
  if family=='Chimeric':q[2001]=74;q[2200]=25 if ri not in (0,3,5) else 0
  # Guard the original source name and the new harmonic parameter range.
  for p in P:
   pid=int(p['id']); v=q[pid]
   if not math.isfinite(v):raise ValueError((family,role,pid,v))
   q[pid]=max(float(p['min']),min(float(p['max']),v))
  filename=f'{fi*8+ri+1:02d}_{family}_{role}_{TITLES[family][ri].replace(" ","_")}.albp'
  content='ALBEDO_NATIVE_PATCH 1\n'+''.join(f'{pid} {q[pid]:.12g}\n' for pid in pids)
  (out/filename).write_text(content,encoding='ascii')
  rows.append({'number':fi*8+ri+1,'name':f'{family} | {TITLES[family][ri]}','family':family,'role':role,'file':filename,
   'methods':[int(q[1000+e*32]) for e in range(4)],'enabled':[int(q[1001+e*32]) for e in range(4)],
   'materials':[MATNAMES[material[e]] for e in range(4)],'material_indices':material,
   'sha256':hashlib.sha256(content.encode()).hexdigest(), 'values':q})

# All resources used, all categories present, all oscillator types used.
assert len(rows)==64
assert set(r['family'] for r in rows)==set(x[0] for x in FAMILIES)
assert all(any(r['enabled'][e] and r['methods'][e] in [3,7] for e in range(4)) for r in rows)
assert set(i for r in rows for i in r['material_indices'])==set(range(32))

# Windows GDI editor: embed full snapshots to avoid requiring samples/presets on disk.
hdr=R/'include'/'albedo_factory_patches.hpp'
with hdr.open('w',encoding='utf-8') as f:
 f.write('#pragma once\n#include <array>\n#include <cstdint>\n// Auto-generated from CP07 patches + parameter registry. Do not edit manually.\nnamespace albedo_factory {\n')
 f.write('inline constexpr std::array<uint32_t,197> parameterIds = {'+','.join(str(i) for i in pids)+'};\n')
 f.write('struct Patch { const wchar_t* name; std::array<float,197> values; };\n')
 f.write('inline constexpr std::array<Patch,64> patches = {{\n')
 for r0 in rows:
  name=(r0['name']+' ('+r0['role']+')').replace('"','\\"')
  def fl(v):
   token=f'{v:.7g}'
   if 'e' not in token and '.' not in token:token+='.0'
   return token+'f'
  f.write('{L"'+name+'", {'+','.join(fl(r0['values'][i]) for i in pids)+'}},\n')
 f.write('}};\n}\n')
manifest={'schema':'albedo-quintessential-cp07-1','collection':'Quintessential Collection','sample_rate_materials':96000,
 'bank':'Albedo_Materia32_PCM24_96k.vtrb (same legacy bank bytes, all 32 original materials)',
 'factory_count':64,'legacy_presets_archived':'Presets/Archives/CP05_Starter_Morphologies','fm_removed':True,
 'methods':['Analog / Subtractive','Wavetable / Vector','Harmonic / Additive','Granular / Cloud','Spectral / Resynthesis','Physical / Modal','Noise / Stochastic','Sample / Time Warp','Phase Distortion','Generative / Cellular'],
 'material_usage':{MATNAMES[i]:sum(i in x['material_indices'] for x in rows) for i in range(32)},
 'patches':[{k:v for k,v in row.items() if k!='values'} for row in rows]}
(out/'MANIFEST.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print('generated',len(rows),'patches with',len(pids),'parameters',len(set(i for row in rows for i in row['material_indices'])),'unique PCM material assignments')
print('methods active counts',Counter(row['methods'][e] for row in rows for e in range(4) if row['enabled'][e]))
