#!/usr/bin/env python3
"""Fail-closed audit of real Windows CLAP+VST3 binaries in the release ZIP.
Runs independently of Windows; does NOT prove Bitwig host compatibility.
"""
from __future__ import annotations
import argparse, hashlib, json, os, struct, sys, zipfile
from pathlib import Path
from verify_pe_exports import inspect as inspect_pe_exports, PEError

def inspect_pe(blob, name):
    if len(blob) < 256 or blob[:2] != b'MZ':
        raise ValueError(f'{name}: missing Windows MZ header')
    ptr, = struct.unpack_from('<I', blob, 0x3c)
    if ptr < 64 or ptr + 24 > len(blob) or blob[ptr:ptr+4] != b'PE\0\0':
        raise ValueError(f'{name}: invalid Windows PE signature')
    machine, = struct.unpack_from('<H', blob, ptr+4)
    if machine != 0x8664:
        raise ValueError(f'{name}: expected x64 AMD64, got 0x{machine:04x}')
    opt_magic, = struct.unpack_from('<H', blob, ptr+24)
    if opt_magic != 0x20b:
        raise ValueError(f'{name}: expected PE32+ optional header, got 0x{opt_magic:04x}')
    return {'bytes': len(blob), 'sha256': hashlib.sha256(blob).hexdigest(), 'format': 'PE32+ AMD64'}

def audit(package):
    with zipfile.ZipFile(package) as z:
        bad = z.testzip()
        if bad: raise ValueError('Corrupt ZIP member: '+bad)
        files = [n for n in z.namelist() if not n.endswith('/')]
        names = {n.lower().rsplit('/', 1)[-1]: [] for n in files}
        for n in files: names[n.lower().rsplit('/', 1)[-1]].append(n)
        required = ['albedo_quintessential_synth.clap','albedo_native_gui_preview.exe','release_manifest.json']
        for k in required:
            if len(names.get(k,[])) != 1:
                raise ValueError('Expected exactly one '+k+' in release ZIP')
        vsts = [n for n in files if n.lower().startswith('albedo_quintessential_synth.vst3/') and n.lower().endswith('.vst3')]
        if len(vsts) != 1:
            raise ValueError('Expected one real VST3 PE module inside Steinberg bundle, got '+str(len(vsts)))
        result={'archive':str(package),'plugin_formats': {}, 'gui_preview': None}
        for fmt, member in [('clap',names[required[0]][0]),('vst3',vsts[0])]:
            blob=z.read(member)
            entrypoints=['clap_entry'] if fmt=='clap' else ['GetPluginFactory','InitDll','ExitDll']
            try:
                exports=inspect_pe_exports(blob)['exports']
            except PEError as exc:
                raise ValueError(f'{member}: failed export parsing: {exc}') from exc
            missing=sorted(set(entrypoints)-set(exports))
            if missing:
                raise ValueError(f'{member}: missing required exports: {", ".join(missing)}')
            result['plugin_formats'][fmt]={'path':member,**inspect_pe(blob, member),'verified_exports':entrypoints}
        gui_name=names[required[1]][0]
        result['gui_preview']={'path':gui_name,**inspect_pe(z.read(gui_name),gui_name)}
        release=json.loads(z.read(names[required[2]][0]))
        if release.get('status')!='compiled-and-offline-tested' or set(release.get('formats',[]))!={'CLAP','VST3'}:
            raise ValueError('Release manifest is not a verified CLAP+VST3 Windows release')
        if release.get('platform') != 'Windows x64':
            raise ValueError('Release manifest platform is not Windows x64')
        if release.get('vst3_sdk_commit') != '3cdf9ca5d1f5b1b21e0a86832aa4abe55607bd96':
            raise ValueError('Official Steinberg SDK revision is missing or unexpected')
        result['release']={k:release.get(k) for k in ['project','version','checkpoint','platform','vst3_sdk_commit','host_qa']}
        return result

def main():
    p=argparse.ArgumentParser()
    p.add_argument('archive',type=Path)
    ns=p.parse_args()
    try:
        result=audit(ns.archive)
    except (ValueError,zipfile.BadZipFile,OSError,json.JSONDecodeError) as exc:
        print(f'FAIL — not a verified Windows CLAP+VST3 release: {exc}',file=sys.stderr)
        return 1
    print(json.dumps(result,indent=2))
    print('PASS: both real Windows AMD64 plugins and standalone native GUI PE verified')
    print('Bitwig plugin scan, GUI DPI, automation, session recall still require host QA')
    return 0
if __name__=='__main__': sys.exit(main())
