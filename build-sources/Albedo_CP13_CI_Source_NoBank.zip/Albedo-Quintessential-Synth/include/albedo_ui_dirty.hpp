#pragma once
// Albedo-owned implementation of GUI dirty-state filtering.
// Informed by the Nereida UI checkpoint's redraw/normalized-tolerance design.
// NO Nereida source code is copied into this file.
#include <unordered_map>
#include <cstdint>
#include <cmath>
#include <algorithm>
namespace vitriol {
class UiDirtyTracker {
public:
 static constexpr double kContinuousTolerance=0.0025;
 bool observe(uint32_t id, double real, bool stepped, double lo, double hi) {
  if (!std::isfinite(real) || !std::isfinite(lo) || !std::isfinite(hi) || hi <= lo) return false;
  double observed=stepped ? std::round(std::clamp(real,lo,hi)) : std::clamp((real-lo)/(hi-lo),0.0,1.0);
  auto [it,inserted]=last_.emplace(id,observed);
  if(inserted)return true;
  const double epsilon=stepped?0.0:kContinuousTolerance;
  if(std::abs(it->second-observed)<=epsilon)return false;
  it->second=observed;return true;
 }
 void clear(){last_.clear();}
 size_t size()const{return last_.size();}
private:
 std::unordered_map<uint32_t,double> last_;
};
}
