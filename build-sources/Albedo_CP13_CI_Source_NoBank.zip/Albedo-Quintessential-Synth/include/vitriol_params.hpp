#pragma once
#include <cstdint>
#include <vector>
#include <string>
#include <array>
#include <algorithm>
#include <cmath>
namespace vitriol {
struct ParamDef {uint32_t id; std::string name, group, unit; double min,max,def; bool stepped=false;};
inline std::vector<ParamDef> defineParams() {
 std::vector<ParamDef> p;
 auto add=[&](uint32_t id,std::string name,std::string group,double mn,double mx,double d,std::string u="",bool s=false){p.push_back({id,name,group,u,mn,mx,d,s});};
 const char* engines[]={"Ignis / A","Aer / B","Aqua / C","Terra / D"};
 for(int i=0;i<4;i++){
  uint32_t b=1000+i*32;std::string g=std::string("Prima Materia / ")+engines[i];
  add(b+0,"Method",g,0,9, (i==0?1:i==1?3:i==2?2:4),"",true); add(b+1,"Enabled",g,0,1,1,"",true);
  add(b+2,"Level",g,0,100, (i==0?80:i==1?55:i==2?48:40),"%");
  add(b+3,"Tune",g,-24,24,0,"st"); add(b+4,"Pan",g,-100,100,0,"L/R");add(b+5,"Keytrack",g,0,1,1,"",true);
  for(int j=0;j<4;j++)add(b+6+j,"Character "+std::to_string(j+1),g,0,100,50,"%");
  // CP04: extended per-generator controls; all ids fit previously unused reserved slots.
  add(b+10,"Material",g,0,31,i*7,"",true);
  add(b+11,"Unison Voices",g,1,8,1,"",true);
  add(b+12,"Unison Detune",g,0,40,0,"ct");
  add(b+13,"Unison Spread",g,0,100,38,"%");
  add(b+14,"Transient Shape",g,0,100,50,"%");
  add(b+15,"Grain Window",g,0,3,0,"",true);
  add(b+16,"Additive Harmonic Count",g,1,24,12,"partials",true);
  add(b+17,"Additive Spectral Tilt",g,.5,4,1.6,"slope");
  add(b+18,"Noise Colour",g,0,100,50,"%");
  add(b+19,"Sub Osc Level",g,0,100,0,"%");
  add(b+20,"Phase Randomness",g,0,100,0,"%");
  add(b+21,"Osc Pitch Fine",g,-100,100,0,"ct");
 }
 const char* macro[]={"Brilliance","Exchange","Contour","Impact","Width","Growth","Memory"};
 double md[]={62,45,53,32,61,58,41};
 for(int i=0;i<7;i++)add(2000+i,macro[i],"Quintessentia / Seven Domains",0,100,md[i],"%");
 add(2100,"Form / XY X","Quintessentia",0,100,55,"%"); add(2101,"Matter / XY Y","Quintessentia",0,100,42,"%");
 const char* pairs[]={"A ↔ B","A ↔ C","A ↔ D","B ↔ C","B ↔ D","C ↔ D"}; double dc[]={35,15,18,40,12,28};
 for(int i=0;i<6;i++)add(2200+i,pairs[i],"Syzygia / Bounded Coupling",0,100,dc[i],"%");
 const char* fs[]={"A Cutoff","A Resonance","A Drive","B Cutoff","B Resonance","B Drive"};double fmn[]={20,0,0,20,0,0},fmx[]={20000,100,24,20000,100,24},fdf[]={2600,27,3,6900,18,1.5};
 for(int i=0;i<6;i++)add(3000+i,fs[i],"Corpus / Filters",fmn[i],fmx[i],fdf[i],(i%3==0?"Hz":i%3==1?"%":"dB"));
 add(3010,"Filter A Type","Corpus / Filters",0,4,0,"",true); add(3011,"Filter B Type","Corpus / Filters",0,4,0,"",true); add(3012,"Filter Routing","Corpus / Filters",0,2,0,"",true);
 add(3100,"Attack","Corpus / Envelope",.001,8,.06,"s"); add(3101,"Decay","Corpus / Envelope",.01,10,.52,"s");add(3102,"Sustain","Corpus / Envelope",0,100,68,"%");add(3103,"Release","Corpus / Envelope",.01,18,1.9,"s");
 add(3110,"Pitch Mode","Corpus / Pitch Guard",0,2,0,"",true);add(3111,"Voice Mode","Corpus / Voice",0,3,0,"",true);add(3112,"Tuning","Corpus / Voice",0,4,0,"",true);
 add(3120,"Filter A Env Amount","Corpus / Filter Envelope",-100,100,0,"%");
 add(3121,"Filter B Env Amount","Corpus / Filter Envelope",-100,100,0,"%");
 add(3122,"Filter Env Attack","Corpus / Filter Envelope",.001,5,.022,"s");
 add(3123,"Filter Env Decay","Corpus / Filter Envelope",.01,10,.38,"s");
 add(3124,"Filter Env Sustain","Corpus / Filter Envelope",0,100,24,"%");
 add(3125,"Filter Env Release","Corpus / Filter Envelope",.01,12,.45,"s");
 add(3130,"Portamento","Corpus / Voice",0,2000,0,"ms");
 add(3131,"Analog Drift","Corpus / Voice",0,20,0,"ct");
 add(4000,"Motion Rate","Motus & Cellular",.02,24,1.25,"Hz");add(4001,"Motion Depth","Motus & Cellular",0,100,54,"%");add(4002,"Motion Slew","Motus & Cellular",0,100,20,"%");add(4003,"Cellular Rule","Motus & Cellular",0,3,2,"",true);
 add(4010,"LFO 2 Rate","Motus & Cellular",.01,30,.8775,"Hz");
 add(4011,"LFO 1 Shape","Motus & Cellular",0,4,0,"",true);
 add(4012,"LFO 2 Shape","Motus & Cellular",0,4,0,"",true);
 add(4013,"LFO 1 Range","Motus & Cellular",0,100,100,"%");
 add(4014,"LFO 2 Range","Motus & Cellular",0,100,100,"%");
 const char* fx[]={"Saturation","Chorus / Depth","Space / Reverb","Diffusion"};double wets[]={18,27,39,12};
 for(int i=0;i<4;i++){add(5000+i*2,std::string(fx[i])+" Mix","Spatium & Transform",0,100,wets[i],"%");add(5001+i*2,std::string(fx[i])+" Enabled","Spatium & Transform",0,1,i!=3,"",true);}
 add(5008,"Chorus Rate","Spatium & Transform",.02,6,.17,"Hz");
 add(5009,"Chorus Spread","Spatium & Transform",0,100,70,"%");
 add(5010,"Reverb Damping","Spatium & Transform",0,100,70.37037,"%");
 add(5011,"Reverb Size","Spatium & Transform",40,140,100,"%");
 add(5012,"Saturation Bias","Spatium & Transform",-60,60,0,"%");
 for(int i=0;i<16;i++)add(6000+i,"Step "+std::to_string(i+1),"Pulsus / 16-Step Amplitude",0,1,((i%4==0)||(i==13))?1:0,"",true);
 add(6020,"Pulse Enabled","Pulsus",0,1,0,"",true);add(6021,"Pulse Division","Pulsus",.05,1,.25,"s");add(6022,"Pulse Depth","Pulsus",0,100,70,"%");add(6023,"Pulse Gate","Pulsus",0,100,72,"%");
 const char* src[]={"LFO 1","LFO 2","ENV / A","ENV / B","CELLULAR","VELOCITY","MOD WHEEL","AFTERTOUCH","XY / X","XY / Y","KEY TRACK","FOLLOWER"};
 const char* dst[]={"Filter A Cutoff","Filter B Cutoff","Engine A Timbre","Engine B Morph","Engine C Timbre","Engine D Texture","Macro Brilliance","Macro Exchange","Space / Mix","Pan / Width","Body / Material","Pitch Lab"};
 (void)src;(void)dst;
 for(int i=0;i<8;i++){int b=8000+i*3;add(b,"Source "+std::to_string(i+1),"Correspondentiae",0,11,i==0?0:i==1?3:i==2?4:i==3?8:0,"",true);add(b+1,"Destination "+std::to_string(i+1),"Correspondentiae",0,11,i==0?0:i==1?3:i==2?5:i==3?7:0,"",true);add(b+2,"Depth "+std::to_string(i+1),"Correspondentiae",-100,100,i==0?34:i==1?57:i==2?26:i==3?49:0,"%");}
 add(8300,"Active Routes","Correspondentiae",0,8,4,"",true);
 add(9000,"Output Gain","Master / Claritas",-36,12,-3,"dB");add(9001,"Output Guard","Master / Claritas",0,1,1,"",true);add(9002,"Oversampling","Master / Claritas",0,4,0,"",true);
 return p;
}
inline const char* const kMaterialNames[]={
 "Bronze Quiver","Hollow Glass","Copper Bloom","Bell Dust","Reed Current","Plucked Wire","Wooden Vein","Ceramic Grain",
 "Felt Pulse","Membrane Ember","Air Column","Spring Alloy","Ice Lattice","Stone Ripple","Water Pearl","Electric Filament",
 "Soft Machine","Sand Drift","Vowel Foam","Carbon Friction","Polyphonic Metal","Marimba Wood","Granular Resin","Light Ash",
 "Ink Falls","Shimmer Film","Mechanical Ember","Earth Drone","Azure Swell","Porcelain Bloom","Mineral Rain","Living Circuit"};
inline const char* const kMethods[]={"Analog / Subtractive","Wavetable / Vector","Harmonic / Additive","Granular / Cloud","Spectral / Resynthesis","Physical / Modal","Noise / Stochastic","Sample / Time Warp","Phase Distortion","Generative / Cellular"};
inline const char* const kSources[]={"LFO 1","LFO 2","ENV / A","ENV / B","CELLULAR","VELOCITY","MOD WHEEL","AFTERTOUCH","XY / X","XY / Y","KEY TRACK","FOLLOWER"};
inline const char* const kTargets[]={"Filter A Cutoff","Filter B Cutoff","Engine A Timbre","Engine B Morph","Engine C Timbre","Engine D Texture","Macro Brilliance","Macro Exchange","Space / Mix","Pan / Width","Body / Material","Pitch Lab"};
}
