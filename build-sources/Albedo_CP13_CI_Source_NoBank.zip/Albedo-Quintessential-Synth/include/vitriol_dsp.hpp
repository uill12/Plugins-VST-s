#pragma once
#include "vitriol_params.hpp"
#include <array>
#include <vector>
#include <atomic>
#include <cstdint>
#include <cstddef>
#include <memory>
#include <string>
namespace vitriol {
constexpr int kVoices=24, kEngines=4, kParamStorage=10000;
class Synth {
public:
 Synth();
 void prepare(double sampleRate); void reset();
 bool loadResourceBank(const std::string& file);
 bool loadResourceBankBytes(const unsigned char* bytes,size_t length);
 bool resourcesReady() const {return bankReady_;}
 void noteOn(int note,double velocity,int channel=0);
 void noteOff(int note,int channel=0);
 void allNotesOff();
 void midiCC(int cc,int val); void bend(int value14); void aftertouch(double v);
 bool setParam(uint32_t id,double v);
 double getParam(uint32_t id) const;
 const std::vector<ParamDef>& descriptors()const{return defs_;}
 void process(float* l,float* r,uint32_t n);
 void process64(double* l,double* r,uint32_t n);
 int activeVoices()const; double sampleRate()const{return fs_;}
 int oversamplingFactor()const;
private:
 struct Voice {
  bool active=false,released=false;
  int note=60,ch=0; uint64_t age=0;double freq=261.63,velocity=1,env=0,cellValue=0,detuneCents=0,panOffset=0;
  int envStage=0; // 0 attack,1 decay,2 sustain,3 release
  double phase[4]{},subphase[4]{},colorLP[4]{},grainPhase[4]{},samplePos[4]{},modalEnergy[4]{};
  double unisonPhase[4][8]{}, filterEnv=0, filterLevel=0;int filterStage=0;
  int stringPos[4]{};std::array<std::array<double,8192>,4> strings{};
  uint32_t random=0x18953u,caBits=1u<<16;
  uint32_t cellClock=0;
 };
 struct Filter {
  double ic1=0,ic2=0,ladder[4]{},combLP=0;std::array<double,4096> comb{};int combPos=0;
  double run(double x,double cutoff,double resonance,double drive,int type,double fs);
  void clear();
 };
 struct Delay {std::vector<double> buf;size_t pos=0;void sizeTo(size_t n);double read(double lag)const;double tick(double input);void clear();};
 struct ChannelFX { Delay chorus,reverb[4],ap[2],diffuse;double reverbLP[4]{},diffLP=0;};
 std::array<Voice,kVoices> voices_{};
 Filter filters_[2][2]{};
 ChannelFX fx_[2];
 std::array<std::atomic<double>,kParamStorage> values_{};
 std::array<bool,kParamStorage> hasParam_{};
 std::vector<ParamDef> defs_;
 std::array<std::array<double,2048>,11> wavetable_{};
 // CP07 precomputed normalized harmonic tilt lookup, avoids pow() per partial/sample.
 std::array<std::array<double,24>,128> harmonicTilt_{};
 std::vector<double> proceduralSample_;
 std::array<std::vector<float>,32> materialBank_{};
 uint32_t materialFrames_=0,materialSampleRate_=96000;bool bankReady_=false;
 double filterEnvFrame_=0;
 // CP06: realtime de-zippering (engine-domain filter control and output-domain gain/pulse).
 // All state is scalar, per instance, and requires no allocation in process().
 double cutoffLogSmooth_[2]{};
 double pulseGain_=1.0, outputGainSmooth_=1.0, cutoffSmoothAlpha_=1.0;
 std::array<std::array<double,64>,2> decimHist_{};int decimPos_=0;
 std::array<double,64> decimCoeffs_{};int decimLen_=0;
 double modFrame_[12]{};double modWeight_=0;
 double fs_=48000,modwheel_=0,aftertouch_=0,bend_=0,lfoPhase_=0,lfo2Phase_=0,lfoSlew_=0,motion_=0;
 uint64_t clock_=0,ageCounter_=0;double meterL_=0,meterR_=0;int prevOS_=0;
 double get(uint32_t id)const{return id<kParamStorage?values_[id].load(std::memory_order_relaxed):0.0;}
 uint32_t noise(Voice& v);
 double noteHz(int note)const;
 double sourceSample(Voice& v,int engine,int method,double freq,double ch0,double ch1,double ch2,double ch3,double fsInternal);
 double voiceEnvelope(Voice& v,double fsInternal);
 double filterEnvelope(Voice& v,double fsInternal);
 double materialSample(int index,double normalizedPhase)const;
 static double lfoShape(double phase,int shape);
 void runCells(Voice& v,int rule,double rate,double fsInternal);
 double routeSource(int index,const Voice& v,double lfo1,double lfo2,double follower)const;
 void sampleVoice(Voice& v,int os,double& l,double& r);
 void nextInternal(double& l,double& r,int os);
 void processEffects(double& l,double& r);
 void setupDecimator(int os);
 static double soft(double v);
 static double limit(double v);
};
}
