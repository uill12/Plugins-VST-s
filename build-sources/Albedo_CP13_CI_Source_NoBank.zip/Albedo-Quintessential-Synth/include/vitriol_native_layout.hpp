#pragma once
// RG NES CP05 / GENERATED FROM LIVE HTML, DOM->native geometry. Do not edit coordinates by hand.
// Source: resources/VITRIOL_v08_Horizontal.html; generator: tools/build_horizontal_registry.py
#include "vitriol_params.hpp"
#include <cstdint>
#include <vector>
#include <algorithm>
namespace vitriol {
constexpr int kArtWidth=1920, kArtHeight=1366;
enum class ControlKind : uint8_t {Dial, Slider, Toggle, Choice, XY, Source, Step, Button};
struct NativeControl {
 int x,y,w,h; uint32_t id; ControlKind kind; const char* label;uint8_t sourceRelative=0;
 bool contains(int a,int b)const{return a>=x&&b>=y&&a<x+w&&b<y+h;}
};
inline std::vector<NativeControl> makeNativeControls(){
 std::vector<NativeControl> v;v.reserve(102);
 auto add=[&](int x,int y,int w,int h,uint32_t id,ControlKind kind,const char*label,bool relative=false){v.push_back({x,y,w,h,id,kind,label,uint8_t(relative)});};
 add(26,150,461,90,4293918720u,ControlKind::Source,"Ignis",false);
 add(452,163,24,24,1001u,ControlKind::Toggle,"Ignis Enabled",false);
 add(381,205,63,12,1002u,ControlKind::Slider,"Ignis Level",false);
 add(495,150,461,90,4293918721u,ControlKind::Source,"Aer",false);
 add(921,163,24,24,1033u,ControlKind::Toggle,"Aer Enabled",false);
 add(850,205,63,12,1034u,ControlKind::Slider,"Aer Level",false);
 add(964,150,461,90,4293918722u,ControlKind::Source,"Aqua",false);
 add(1390,163,24,24,1065u,ControlKind::Toggle,"Aqua Enabled",false);
 add(1319,205,63,12,1066u,ControlKind::Slider,"Aqua Level",false);
 add(1433,150,461,90,4293918723u,ControlKind::Source,"Terra",false);
 add(1859,163,24,24,1097u,ControlKind::Toggle,"Terra Enabled",false);
 add(1788,205,63,12,1098u,ControlKind::Slider,"Terra Level",false);
 add(33,375,443,30,1000u,ControlKind::Choice,"Source Method",true);
 add(64,431,45,45,1006u,ControlKind::Dial,"Character Shape",true);
 add(176,431,45,45,1007u,ControlKind::Dial,"Character Color",true);
 add(288,431,45,45,1008u,ControlKind::Dial,"Character Motion",true);
 add(400,431,45,45,1009u,ControlKind::Dial,"Character Texture",true);
 add(83,535,45,45,1002u,ControlKind::Dial,"Level",true);
 add(232,535,45,45,1003u,ControlKind::Dial,"Tune",true);
 add(381,535,45,45,1004u,ControlKind::Dial,"Pan",true);
 add(411,621,65,25,1005u,ControlKind::Toggle,"Keytracking",true);
 add(896,385,106,106,2100u,ControlKind::XY,"Morph / Form + Matter",false);
 add(553,609,43,43,2000u,ControlKind::Dial,"Bright",false);
 add(678,609,43,43,2001u,ControlKind::Dial,"Exchange",false);
 add(803,609,43,43,2002u,ControlKind::Dial,"Contour",false);
 add(928,609,43,43,2003u,ControlKind::Dial,"Impact",false);
 add(1053,609,43,43,2004u,ControlKind::Dial,"Width",false);
 add(1177,609,43,43,2005u,ControlKind::Dial,"Growth",false);
 add(1302,609,43,43,2006u,ControlKind::Dial,"Memory",false);
 add(530,852,265,10,2200u,ControlKind::Slider,"A-B",false);
 add(817,852,265,10,2201u,ControlKind::Slider,"A-C",false);
 add(1104,852,265,10,2202u,ControlKind::Slider,"A-D",false);
 add(530,904,265,10,2203u,ControlKind::Slider,"B-C",false);
 add(817,904,265,10,2204u,ControlKind::Slider,"B-D",false);
 add(1104,904,265,10,2205u,ControlKind::Slider,"C-D",false);
 add(1476,396,43,43,3000u,ControlKind::Dial,"filterAcut",false);
 add(1633,396,43,43,3001u,ControlKind::Dial,"filterAres",false);
 add(1790,396,43,43,3002u,ControlKind::Dial,"filterAdrive",false);
 add(1476,568,43,43,3003u,ControlKind::Dial,"filterBcut",false);
 add(1633,568,43,43,3004u,ControlKind::Dial,"filterBres",false);
 add(1790,568,43,43,3005u,ControlKind::Dial,"filterBdrive",false);
 add(1792,319,97,25,3010u,ControlKind::Choice,"Filter A Type",false);
 add(1792,491,97,25,3011u,ControlKind::Choice,"Filter B Type",false);
 add(1807,866,82,25,3012u,ControlKind::Choice,"Filter Route",false);
 add(1757,777,132,24,3110u,ControlKind::Choice,"Pitch Mode",false);
 add(1817,821,72,25,3111u,ControlKind::Choice,"Voice Mode",false);
 add(538,1286,90,24,3112u,ControlKind::Choice,"Tuning",false);
 add(930,999,79,25,4003u,ControlKind::Choice,"Cellular Rule",false);
 add(1204,1286,57,24,9002u,ControlKind::Choice,"Oversampling",false);
 add(1457,694,41,41,3100u,ControlKind::Dial,"envAttack",false);
 add(1575,694,41,41,3101u,ControlKind::Dial,"envDecay",false);
 add(1693,694,41,41,3102u,ControlKind::Dial,"envSustain",false);
 add(1811,694,41,41,3103u,ControlKind::Dial,"envRelease",false);
 add(645,1132,39,39,4000u,ControlKind::Dial,"motionRate",false);
 add(784,1132,39,39,4001u,ControlKind::Dial,"motionDepth",false);
 add(924,1132,39,39,4002u,ControlKind::Dial,"motionSlew",false);
 add(26,1013,177,22,8000u,ControlKind::Choice,"Mod Source 1",false);
 add(223,1013,177,22,8001u,ControlKind::Choice,"Mod Target 1",false);
 add(406,1016,138,16,8002u,ControlKind::Slider,"Mod Depth 1",false);
 add(26,1039,177,22,8003u,ControlKind::Choice,"Mod Source 2",false);
 add(223,1039,177,22,8004u,ControlKind::Choice,"Mod Target 2",false);
 add(406,1042,138,16,8005u,ControlKind::Slider,"Mod Depth 2",false);
 add(26,1065,177,22,8006u,ControlKind::Choice,"Mod Source 3",false);
 add(223,1065,177,22,8007u,ControlKind::Choice,"Mod Target 3",false);
 add(406,1068,138,16,8008u,ControlKind::Slider,"Mod Depth 3",false);
 add(26,1091,177,22,8009u,ControlKind::Choice,"Mod Source 4",false);
 add(223,1091,177,22,8010u,ControlKind::Choice,"Mod Target 4",false);
 add(406,1094,138,16,8011u,ControlKind::Slider,"Mod Depth 4",false);
 add(1236,1010,186,16,5000u,ControlKind::Slider,"Saturation Mix",false);
 add(1427,1007,23,23,5001u,ControlKind::Toggle,"FX Power",false);
 add(1236,1048,186,16,5002u,ControlKind::Slider,"Chorus Mix",false);
 add(1427,1045,23,23,5003u,ControlKind::Toggle,"FX Power",false);
 add(1236,1087,186,16,5004u,ControlKind::Slider,"Reverb Mix",false);
 add(1427,1083,23,23,5005u,ControlKind::Toggle,"FX Power",false);
 add(1236,1125,186,16,5006u,ControlKind::Slider,"Diffusion Mix",false);
 add(1427,1122,23,23,5007u,ControlKind::Toggle,"FX Power",false);
 add(1483,1017,24,31,6000u,ControlKind::Step,"Pulse Step 1",false);
 add(1509,1017,24,31,6001u,ControlKind::Step,"Pulse Step 2",false);
 add(1534,1017,24,31,6002u,ControlKind::Step,"Pulse Step 3",false);
 add(1560,1017,24,31,6003u,ControlKind::Step,"Pulse Step 4",false);
 add(1586,1017,24,31,6004u,ControlKind::Step,"Pulse Step 5",false);
 add(1612,1017,24,31,6005u,ControlKind::Step,"Pulse Step 6",false);
 add(1638,1017,24,31,6006u,ControlKind::Step,"Pulse Step 7",false);
 add(1664,1017,24,31,6007u,ControlKind::Step,"Pulse Step 8",false);
 add(1689,1017,24,31,6008u,ControlKind::Step,"Pulse Step 9",false);
 add(1715,1017,24,31,6009u,ControlKind::Step,"Pulse Step 10",false);
 add(1741,1017,24,31,6010u,ControlKind::Step,"Pulse Step 11",false);
 add(1767,1017,24,31,6011u,ControlKind::Step,"Pulse Step 12",false);
 add(1793,1017,24,31,6012u,ControlKind::Step,"Pulse Step 13",false);
 add(1819,1017,24,31,6013u,ControlKind::Step,"Pulse Step 14",false);
 add(1844,1017,24,31,6014u,ControlKind::Step,"Pulse Step 15",false);
 add(1870,1017,24,31,6015u,ControlKind::Step,"Pulse Step 16",false);
 add(1483,1052,73,28,6020u,ControlKind::Button,"Pulse Preview",false);
 add(1838,1053,56,27,6021u,ControlKind::Choice,"Pulse Division",false);
 add(1807,1286,87,35,9001u,ControlKind::Toggle,"Output Guard",false);
 add(1741,21,125,28,4292870145u,ControlKind::Button,"Synthesis Lab",false);
 add(1423,21,79,28,4292870147u,ControlKind::Button,"Mutate",false);
 add(1509,21,77,28,4292870148u,ControlKind::Button,"Import Native Patch",false);
 add(1593,21,104,28,4292870149u,ControlKind::Button,"Export Native Patch",false);
 add(1704,21,30,28,4292870150u,ControlKind::Button,"Nigredo Theme",false);
 add(1062,18,238,34,4292870151u,ControlKind::Choice,"Factory Morphology",false);
 add(1873,21,27,28,4292870146u,ControlKind::Button,"Help",false);
 return v;
}
inline std::vector<NativeControl> makeLabControls(){
 std::vector<NativeControl> v;v.reserve(34);
 auto add=[&](int x,int y,int w,int h,uint32_t id,ControlKind kind,const char*label,bool relative=false){v.push_back({x,y,w,h,id,kind,label,uint8_t(relative)});};
 const char* names[]={"Ignis","Aer","Aqua","Terra"};
 for(int i=0;i<4;i++)add(176+i*392,206,368,53,0xfff00000u+unsigned(i),ControlKind::Source,names[i]);
 const char* slabels[]={"Material Bank","Unison Voices","Unison Detune","Stereo Spread","Transient Shape","Grain Window","Harmonic Count","Spectral Tilt","Noise Colour","Sub Level","Phase Random","Pitch Fine"};
 for(int i=0;i<12;i++){int x=176+(i%6)*263,y=319+(i/6)*124;ControlKind kind=(i==0||i==1||i==5)?ControlKind::Choice:ControlKind::Dial;
 add(x,y,235,100,1010u+unsigned(i),kind,slabels[i],true);}
 const uint32_t global[]={3120,3121,3122,3123,3124,3125,3130,3131,4010,4011,4012,4013,4014,5008,5009,5010,5011,5012};
 const char* glabels[]={"Filter A Env","Filter B Env","F.Attack","F.Decay","F.Sustain","F.Release","Portamento","Analog Drift","LFO 2 Rate","LFO1 Shape","LFO2 Shape","LFO1 Range","LFO2 Range","Chorus Rate","Chorus Spread","Reverb Damping","Reverb Size","Sat Bias"};
 for(int i=0;i<18;i++){int x=176+(i%6)*263,y=703+(i/6)*124;
 ControlKind kind=(global[i]==4011||global[i]==4012)?ControlKind::Choice:(global[i]==3130?ControlKind::Slider:ControlKind::Dial);
 add(x,y,235,100,global[i],kind,glabels[i]);}
 return v;
}
inline uint32_t resolvedParam(const NativeControl&c,int selected){return c.sourceRelative?(1000u+uint32_t(std::clamp(selected,0,3))*32u+c.id-1000u):c.id;}
inline bool nativeEditorCovers(uint32_t id){auto all=makeNativeControls();for(const auto&w:all)if(w.id==id||(w.sourceRelative&&id>=1000&&id<1128&&(id-1000)%32==w.id-1000))return true;return false;}
}
