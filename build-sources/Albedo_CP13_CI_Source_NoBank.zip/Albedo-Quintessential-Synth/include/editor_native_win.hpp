#pragma once
// Native Win32 visual editor: GDI + embedded BMP resource, no WebView2, HTML runtime, or third-party renderer.
#if defined(_WIN32)
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <memory>
#include <map>
#include <functional>
#include <vector>
#include <cstdint>
#include "vitriol_params.hpp"
#include "vitriol_native_layout.hpp"
#include "albedo_ui_dirty.hpp"
namespace vitriol {
class NativeEditor {
public:
 using WriteFn=std::function<void(uint32_t,double)>;
 using ReadFn=std::function<double(uint32_t)>;
 using GestureFn=std::function<void(uint32_t)>;
 NativeEditor(WriteFn onChange,ReadFn read,GestureFn onBegin={},GestureFn onEnd={});
 ~NativeEditor();
 bool attach(HWND parent,int width=1600,int height=1138);
 void detach();
 void resize(int w,int h);
 void show(bool visible);
 void invalidate();
 void updateParam(uint32_t id,double value);  // Call on GUI/main thread only
 HWND hwnd()const{return hwnd_;}
private:
 static LRESULT CALLBACK wndproc(HWND,UINT,WPARAM,LPARAM);
 LRESULT message(HWND,UINT,WPARAM,LPARAM);
 void paint(HDC dc);
 void drawInspector(HDC dc);
 void drawLab(HDC dc);
 void drawDynamicGraphs(HDC dc);
 void drawSourceWaveforms(HDC dc);
 void drawControl(HDC dc,const NativeControl&c,bool highlighted);
 void exportPatch();
 void importPatch();
 void mutatePatch();
 void openFactoryMenu();
 void openChoiceMenu(const NativeControl&);
 void resetControl(const NativeControl&);
 void edit(const NativeControl&c,int x,int y,int delta,bool coarse=false);
 void modify(uint32_t id,double normalizedDelta);
 void selectAt(int x,int y,bool pressed);
 void beginGesture(uint32_t primary,bool xy=false);
 void endGesture();
 double value(uint32_t id)const;
 void change(uint32_t id,double v);
 uint32_t resolve(const NativeControl&c)const;
 int ix(int x)const,iy(int y)const;
 void geometry(int &sx,int &sy,int &ox,int &oy)const;
 HMODULE module_=nullptr;HWND hwnd_=nullptr;HBITMAP artwork_=nullptr,artworkDark_=nullptr;
 HDC backingDC_=nullptr;HBITMAP backingBitmap_=nullptr;HGDIOBJ backingOriginal_=nullptr;
 std::map<int,HFONT> fontCache_; // per-editor, released on detach (RGNES redraw QA)
 int width_=1600,height_=1138,selected_=0,hover_=-1,drag_=-1,startY_=0,startX_=0;
 int inspectorOffset_=0,inspectorSelected_=0;bool inspector_=false,lab_=false,dark_=false,applyingFactory_=false;int selectedPreset_=-1,keyboardControl_=-1;
 double startValue_=0;
 uint32_t gesturePrimary_=UINT32_MAX;bool gestureXY_=false;
 int wheelAccumulator_=0;
 std::vector<NativeControl> controls_,labControls_;std::vector<ParamDef> parameters_;
 UiDirtyTracker dirty_;
 WriteFn write_;ReadFn read_;GestureFn begin_,end_;
};
}
#endif
