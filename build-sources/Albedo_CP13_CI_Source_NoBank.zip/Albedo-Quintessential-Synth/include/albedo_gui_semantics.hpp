#pragma once
// CP09: character labels mirror the actual four controls of each DSP oscillator.
// Source-relative IDs 1006..1009, 1038..1041, 1070..1073, 1102..1105.
// These labels are UI descriptions, not new automation parameter IDs.
namespace vitriol {
inline constexpr const char* kMethodCharacterLabels[10][4] = {
 {"Waveform", "Triangle Blend", "Pulse Width", "Sub Oscillator"},
 {"Wave Position", "Phase Warp", "Wave Fold", "Sub Harmonic"},
 {"Harmonic Gain", "Spectral Slope", "Odd / Even", "Material Blend"},
 {"Grain Size", "Cloud Density", "Sine Blend", "Grain Scatter"},
 {"Spectral Freeze", "Partial Tilt", "Inharmonicity", "Phase Spread"},
 {"Excitation", "Damping", "String Blend", "Resonance"},
 {"Noise Color", "Color Response", "Tonal Blend", "Texture Level"},
 {"Sample Start", "Playback Rate", "Tonal Blend", "Position Drift"},
 {"Phase Bend", "Phase Warp", "Fold Drive", "Output Body"},
 {"Rule Motion", "Cell Influence", "Spectral Mix", "Energy"}
};
}
