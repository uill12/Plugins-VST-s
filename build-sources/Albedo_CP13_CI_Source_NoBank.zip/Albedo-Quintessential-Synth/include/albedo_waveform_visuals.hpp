#pragma once
// Stateless, host-independent source waveform visualization for the native
// alchemical engine rack. Parameter-derived shape; explicitly NOT live audio.
#include <algorithm>
#include <cmath>
#include <cstdint>
namespace albedo_visual {
inline double sourceWave(int method,double shape,double colour,double motion,int source,int i,int width) {
 constexpr double pi=3.14159265358979323846;
 if(width<=0)return 0.;
 shape=std::clamp(shape,0.,1.);colour=std::clamp(colour,0.,1.);motion=std::clamp(motion,0.,1.);
 const double t=double(i)/double(width),p=t*2*pi*(3.2+shape*2.4),sinus=std::sin(p);
 double amp=sinus;
 switch(method){
  case 0:amp=(1.0-colour*.6)*sinus+colour*.6*std::sin(3*p);break;
  case 1:amp=.65*std::sin(p+shape*std::sin(2*p))+.28*std::sin(2*p+motion);break;
  case 2:{amp=0.;double sum=0.;const int partials=3+int(shape*8);
   for(int k=1;k<=partials;k++){double a=1.0/std::pow(double(k),.55+colour*1.4);
    amp+=a*std::sin(k*p);sum+=a;}
   amp/=std::max(.01,sum);break;}
  case 3:{double grain=std::sin(p*4+motion*6.)*std::sin(p*.5);
   amp=grain*(.35+.65*std::pow(std::max(0.,std::sin(pi*t*7.)),1.+shape*3.));break;}
  case 4:amp=.54*sinus+.27*std::sin(4*p+.25*motion)+.15*std::sin(7*p);break;
  case 5:amp=(std::sin(p)+.43*std::sin(2.31*p))*std::exp(-1.5*t);break;
  case 6:{uint32_t n=uint32_t(i*1664525u+1013904223u+source*137u);
   n^=n>>13;n*=1274126177u;n^=n>>16;
   amp=(double(n&65535u)/32767.5-1.)*(.25+.75*colour);break;}
  case 7:amp=.72*sinus+.2*std::sin(7*p+.7);break;
  case 8:amp=std::sin(p+shape*2.5*std::sin(p));break;
  default:amp=(std::sin(p)+.31*std::sin(3*p+motion*3.))*(.6+.4*std::sin(t*19.));break;
 }
 return std::clamp(amp,-1.,1.);
}
} // namespace albedo_visual
