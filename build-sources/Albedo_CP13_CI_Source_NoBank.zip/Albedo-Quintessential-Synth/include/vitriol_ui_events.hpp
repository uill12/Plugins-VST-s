#pragma once
// Bounded single-producer/single-consumer queue used by the native GUI->DSP path.
// UI callbacks may only enqueue and update atomic mirrors; they never touch voices.
// The audio/flush consumer drains a bounded number of events per invocation.
#include <array>
#include <atomic>
#include <cstdint>
#include <type_traits>

namespace vitriol {
enum class UiEventKind : uint8_t { GestureBegin=0, Value=1, GestureEnd=2 };
struct UiEvent {
  uint32_t param=0;
  double value=0.0;
  UiEventKind kind=UiEventKind::Value;
};
static_assert(std::is_trivially_copyable_v<UiEvent>);

template<uint32_t Capacity=4096>
class UiEventQueue {
  static_assert(Capacity>=2 && (Capacity&(Capacity-1))==0,"Queue capacity must be power of two");
  std::array<UiEvent,Capacity> items_{};
  alignas(64) std::atomic<uint32_t> writer_{0};
  alignas(64) std::atomic<uint32_t> reader_{0};
public:
  // The producer is one Win32 editor instance, and the consumer is the plugin
  // host's processing/flush path (never concurrent process & flush per CLAP).
  bool push(UiEvent event) noexcept {
    uint32_t wr=writer_.load(std::memory_order_relaxed);
    if(wr-reader_.load(std::memory_order_acquire)>=Capacity)return false;
    items_[wr&(Capacity-1)]=event;
    writer_.store(wr+1,std::memory_order_release);
    return true;
  }
  bool pop(UiEvent& out) noexcept {
    uint32_t rd=reader_.load(std::memory_order_relaxed);
    if(rd==writer_.load(std::memory_order_acquire))return false;
    out=items_[rd&(Capacity-1)];
    reader_.store(rd+1,std::memory_order_release);
    return true;
  }
  uint32_t pending()const noexcept {
    return writer_.load(std::memory_order_acquire)-reader_.load(std::memory_order_acquire);
  }
  // Only valid if the host has stopped processing before loading a new state.
  void resetInactive() noexcept {
    reader_.store(0,std::memory_order_relaxed);
    writer_.store(0,std::memory_order_relaxed);
  }
};
}
