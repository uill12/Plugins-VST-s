@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Albedo Quintessential Synth - Windows x64 CLAP and VST3 build
where powershell.exe >nul 2>nul
if errorlevel 1 (
 echo ERROR: Windows PowerShell not found.
 pause
 exit /b 1
)
echo.
echo --------------------------------------------------------------
echo  ALBEDO QUINTESSENTIAL SYNTH - WINDOWS x64 CLAP + VST3
 echo  Official Steinberg VST3 SDK 3.8.1 ^| Native Win32 GUI
 echo --------------------------------------------------------------
echo.
echo Requires Windows 10/11 x64, MSVC 2022 C++ tools, Windows SDK,
echo CMake, Git and Python. The SDK is downloaded by the script.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Launch_Windows_Build.ps1"
set "RESULT=%ERRORLEVEL%"
echo.
if not "%RESULT%"=="0" (
 echo ERROR: build or validation failed. No Windows release is certified.
 echo See WINDOWS_BUILD_LOG.txt in this directory for diagnostic details.
) else (
 echo SUCCESS: all native build gates passed.
 echo Output: Albedo_Quintessential_Synth_Windows_x64_CP12.zip
)
pause
exit /b %RESULT%
