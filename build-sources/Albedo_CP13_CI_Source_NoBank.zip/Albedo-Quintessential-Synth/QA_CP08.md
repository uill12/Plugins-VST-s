# Albedo CP08 — verification evidence and remaining release blockers

| Check | Result | Evidence / limitation |
|---|---|---|
| Linux DSP / CLAP CTest | PASS 11/11 | `ctest --test-dir ... --output-on-failure`; includes 64 patch render, additive, materials, routing, and CLAP host smoke |
| Native HTML-to-geometry source match | PASS 102/102 | `tests/qa_native_contract.py` and `QA_CP08_STATIC_CONTRACT.json` |
| Intentional hitbox overlaps | PASS 8/8 | Each of 4 source cards overlaps its own power and level child controls only |
| 64 factory names; actual preset load | Source reviewed; runtime pending | Embedded `albedo_factory_patches.hpp` / `openFactoryMenu()` has all 64; native display now uses real names |
| Complete selector menus | Source reviewed; runtime pending | Native `openChoiceMenu()` lists methods, materials, filter types, LFOs, voice/tuning modes, modulation sources/targets, and routing |
| Knob sensitivity, wheel, reset | Source reviewed; runtime pending | Shift drag fine, wheel fine, mouse dblclick default, keyboard navigation |
| XY morph and host gestures | Source reviewed; runtime pending | Two linked IDs 2100/2101; Windows smoke test added, cannot execute on Linux |
| Responsive geometry | Static verified; runtime pending | 1920×1366 shared geometry, proportional scaling; no HTML CSS reflow in native editor |
| Nigredo/light visual fidelity | Partial | Overlay palette improved; full screenshot comparison and HiDPI needed |
| Windows CLAP `.clap` binary | NOT BUILT | No MSVC/Windows SDK available locally |
| Windows VST3 `.vst3` bundle | NOT BUILT | Official Steinberg SDK not available locally; workflow scripted |
| Windows Bitwig scan and audio/GUI host test | NOT TESTED | Requires Windows + DAW |
| Perceptual hi-fi / anti-alias testing | Not certified | CTest verifies numeric stability, not complete subjective or spectrum quality |

## Testing scope

The source now has 102 mapped native controls, 197 CLAP/VST3 parameter definitions, 64 native factory patches and 32 embedded original audio materials. CTest passed locally on Linux, but this does *not* validate Win32 compilation, exact visual parity, Windows run-time focus/gesture handling, VST3 SDK ABI, installer location or Bitwig behavior.

## Pending acceptance test (Windows + Bitwig)

- Confirm .clap and .vst3 are real AMD64 PE binaries (`Build_Windows_x64.ps1` checks), and bundle loads in plugin scan.
- Confirm 4 generators enable, edit, sound and retain state independently, methods include Harmonic/Additive and no FM.
- Test all 64 patches across sound families, sample bank recall, save/load and reopen.
- Verify 32-material native menu, proper host automation from knobs/XY/filter/routes/step controls, popup selection and undo.
- Compare GUI screenshots side-by-side with approved HTML at 1600×1138 and 1920×1366, both Albedo and Nigredo, and at Windows DPI 100/150/200%.
- Verify no pointer-offset clicks on resized editors; check sub-35px controls are usable.
- Validate audio at 44.1/48/88.2/96 kHz, voice limits, CPU spikes, aliasing, note lifecycle, and tails.
