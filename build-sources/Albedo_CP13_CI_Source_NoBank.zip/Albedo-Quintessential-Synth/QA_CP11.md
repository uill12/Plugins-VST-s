# Albedo Quintessential Synth — CP11 Windows build-gate QA

Date: 2026-11-15. Status: **SOURCE CHECKPOINT; WINDOWS CLAP/VST3 NOT COMPILED**.

## Recovered tools and constraints

- Prior Nereida/Rubedo projects used LLVM Clang/LLD for Windows PE outputs; the current machine contains `clang`, `clang++`, `clang-cl`, `lld-link`, CMake and Ninja.
- No Windows SDK header set, Windows C++ target sysroot/import libraries, official Steinberg VST3 SDK, Wine, or Windows runner is locally available.
- An attempted `clang++ --target=x86_64-w64-windows-gnu -std=c++20 -fsyntax-only -I include src/clap_plugin.cpp` failed on `<cstdint>` because there is no target C++ standard library. This is a toolchain dependency, not an Albedo source-code error.
- No external download was possible from this container; DNS is unavailable. The official VST3 SDK acquisition is delegated to the Windows CI script from Steinberg's MIT-licensed repository.

## Completed in CP11

- Windows 2022 GitHub Actions workflow committed to the user's repository, initial commit `9a1c3906658e886a7b1f668bffc3abdda1dddfb9`, hash-gate update `5fd955a6d0915d8a1b630c94ad74098e8c768b77`: `.github/workflows/albedo-cp11-windows.yml` on `main`.
- Full source/assets are **not** in the remote GitHub branch. **No actual Windows Actions build has run**; no `.clap` or `.vst3` PE binary has been generated.
- CP11 build script requires official VST3 SDK for VST3 and verifies Windows PE32+ AMD64 images after building.
- Additional `tools/verify_pe_exports.py` verifies `clap_entry` for CLAP and `GetPluginFactory`, `InitDll`, `ExitDll` for VST3, instead of trusting a file extension.
- `tests/verify_pe_audit.py` tests synthetic PE export tables, rejects non-PE and non-DLL input, passes on Linux. `tools/verify_source_assets.py` verifies exact source/GUI/PCM hashes and 64/32 presets/material counts, also passes.
- `SMTG_CREATE_PLUGIN_LINK` disabled to avoid link/symlink permissions issues in Windows CI.
- Source/GUI/DSP/assets preserved unchanged from CP10. Check SHA-256 fingerprints in `CP11_BUILDGATE_MANIFEST.json`.

## Actual local test evidence

Command: `cmake -S ... -B ... -G Ninja -DCMAKE_BUILD_TYPE=Release && cmake --build ... --parallel 4 && ctest --test-dir ... --output-on-failure --parallel 4`.

**16/16 CTest tests passed** (Linux, source-level, DSP/audio, registry, CLAP smoke and PE export parser unit test). No Windows native HWND test ran.

## Remaining RGNES release gate

1. Before any GitHub Actions run, upload the full CP11 source/assets to an `Albedo-Quintessential-Synth/` directory on a `albedo-cp11` branch. The included `Publish_Windows_CI_To_GitHub.ps1` can do that on an authenticated Windows machine. The repository is public, so review what will be published.
2. Observe successful Windows 2022 MSVC compilation and native GUI test; verify both real binaries' exports, ZIP extraction and SHA-256.
3. In Windows Bitwig, verify CLAP + VST3 separately: editor open/resize/reparent, default/compact DPI 100/125/150/200%, 64 presets, 32 materials, 102 hit regions, mouse/keyboard/fine drag/menus/XY, host automation undo, project save/restore, MIDI note-on/off and 44.1/48/88.2/96 kHz.
4. Keep previous user-confirmed release as rollback. Do not mark this CP11 source-only package as a Windows binary distribution or the latest verified Drive release.
