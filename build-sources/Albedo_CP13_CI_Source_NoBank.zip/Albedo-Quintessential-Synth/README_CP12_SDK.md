# Albedo Quintessential Synth — official Steinberg VST3 SDK integration (CP12R1)

**SDK reference supplied by user:** https://github.com/steinbergmedia/vst3sdk#100

The `#100` link navigates to **The VST SDK package** section of Steinberg's README. It does not mean SDK version 1.0. Upstream `master` at the inspected point was **VST3 SDK 3.8.1**, commit `3cdf9ca5d1f5b1b21e0a86832aa4abe55607bd96` (2026-08-11).

Steinberg's SDK is licensed under MIT; this package does **not** copy the SDK or claim rights to SDK trademarks. The official dependency is downloaded from Steinberg by the Windows build script.

## What CP12R1 fixes

1. The SDK commit is pinned; `git submodule update --init --recursive` is run and verified.
2. The broken regex used by `Build_Windows_x64.ps1` to locate `Release` output paths is corrected.
3. The Windows workflow calls the pinned SDK build and still gates release on CTest, genuine AMD64 PE headers and CLAP/VST3 exports.
4. All Albedo DSP, GUI artwork, plugin ID, 197 parameter IDs, 32 PCM materials, 64 factory patches, and 102 mapped controls remain unchanged from CP12.

## How to actually produce Windows CLAP/VST3

On **Windows 11 x64** with Visual Studio 2022 Desktop development with C++, the Windows SDK, CMake, Git and Python 3 installed, unpack the attached full source ZIP and open PowerShell in its root.

```powershell
.\Build_Windows_x64.ps1 -Configuration Release
```

The script downloads and pins the official Steinberg SDK, configures CMake for `Visual Studio 17 2022` `x64`, compiles both plugins, runs native CTest, verifies the native PE exports, and *only then* writes `Albedo_Quintessential_Synth_Windows_x64_CP12.zip`. Without a successful Windows run, **no Windows binary has been built**. Avoid marking Bitwig GUI/DPI/automation behavior as certified until host validation.

For remote CI, publish the full source/assets to the user's `uill12/Plugins-VST-s` repository on branch `albedo-cp12`; the included `.github/workflows/albedo-cp12-windows.yml` will run on Windows 2022 runners. **Only uploading the workflow is insufficient**; all 32 materials and native graphics must also be in the repository. A CI artifact is not currently verified.

## Local audit scope

- Official upstream SDK README and commit verified through connected GitHub.
- Windows PowerShell source corrected; cannot execute PowerShell/MSVC inside the current Linux runtime.
- Linux-based DSP/CLAP regression tests may be rerun (see QA file).
- Windows/Bitwig status: **pending, not compiled or tested**.
