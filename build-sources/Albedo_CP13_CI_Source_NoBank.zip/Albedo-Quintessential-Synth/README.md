# Albedo Quintessential Synth — CP08 · Windows Build/GUI Parity Checkpoint

This checkpoint follows CP07 and retains the approved horizontal 1920×1366 alchemical design, 32 original PCM24/96k materials, 64 factory patches, 197 stable parameter IDs and four synthesis layers. FM synthesis is removed (method slot 2 = Harmonic / Additive). The native editor is Win32/GDI and requires **no WebView2**. It draws responsive, parameter-aware controls over the approved horizontal raster, with a separate native Synthesis Lab and Parameter Atlas.

## What was actually verified

- CMake compiled the DSP/CLAP Linux configuration and CTest **11/11** tests passed locally.
- Cross-platform source/geometry audit: **102/102** main native controls match the original DOM-derived 1920×1366 registry in ID, type, location and dimensions. The eight overlaps are intentional source-card subcontrols. 64 embedded presets and 197 IDs are structurally verified.
- Win32 editor fixes: full 64-factory-name selector, choice-popup menus, source/method/material/filter/tuning/modulation menus, native double-click reset, Shift fine dragging, keyboard focus navigation, fine wheel adjustments, and palette-aware dark-mode overlays.
- `tests/win32_gui_smoke.cpp` is integrated into CMake only for WIN32. It will exercise real HWND creation, source knob gestures, XY, output guard, resize hit testing and balanced begin/end host automation gestures. **This test was not executable in the Linux environment.**
- `Build_Windows_x64.ps1` builds Windows CLAP and VST3 using Visual Studio, runs CTest, verifies actual x64 PE headers and packages binaries only after success.

## Windows compilation status

**NOT COMPILED / NOT TESTED on Windows in this environment.** No Visual Studio Windows C++ toolchain, Windows SDK or official Steinberg SDK is available locally; the connected GitHub repository has no uploaded Albedo source tree or started build workflow. This source ZIP is **not** a Windows .clap/.vst3 binary and is not proof of bit-perfect rendering or Bitwig host compatibility.

### Compile on Windows x64

1. Install Visual Studio 2022 Desktop development with C++ (MSVC x64, Windows 10/11 SDK, CMake tools) and Git.
2. Extract this entire source archive, including `resources/` (the binary PCM24 bank and both 24-bit RGB BMPs). Do not move source files away from the bank.
3. In PowerShell at the root of the extracted source run:

```powershell
powershell -ExecutionPolicy Bypass -File .\Build_Windows_x64.ps1 -Configuration Release
```

The script acquires the **official Steinberg VST3 SDK** with Git submodules. If already present, specify `-VST3Sdk 'C:\your-vst3sdk'`. For CLAP-only (no VST3 SDK) add `-ClapOnly`. The output ZIP will be named `Albedo_Quintessential_Synth_Windows_x64.zip` and contain actual compiled binaries only after CTest and PE checks succeed.

4. Test the native GUI in Bitwig on Windows: plug-in scan, presets, 100–200% Windows DPI, window sizes ≥800×600, source knobs, all selectors (including 32 Materials), waveform/ADSR/XY visual changes, host automation and undo, modulation routing, effects, project save/reopen, MIDI notes, and quality at 44.1/48/88.2/96 kHz. Confirm no clipped UI and no graphical redraw flicker.

## GitHub Actions Windows build

The included `.github/workflows/albedo-windows-x64.yml` runs on Windows 2022 (manual dispatch or push to branch `albedo-cp08`). **For it to run, you must first commit the *contents* of this extracted source directory at the repository root or adjust the workflow working-directory to your own folder.** A ZIP attached to a chat cannot automatically become GitHub repository files. Do not treat an unrun workflow as a successful build.

## GUI parity and limitations

Native and HTML interfaces share all mapped controls and the original color/symbolic composition. Native selectors are Windows popup menus rather than HTML `<select>` elements; the editor scales the 1920×1366 horizontal canvas proportionally rather than CSS-reflowing the layout at narrow window widths. GDI vector diagrams are parameter-derived design indicators, **not live FFT audio analyzers**. Native control overlays are rendered with Win32 GDI, so exact per-pixel equality to HTML and high-DPI behavior need direct Windows screenshot comparison. Full UI/host certification is pending. See `QA_CP08.md`.

## Files

- `src/editor_native_win.cpp`, `include/editor_native_win.hpp`: improved native UI.
- `include/vitriol_native_layout.hpp`: existing DOM-matched controls.
- `resources/Albedo_CP07_Horizontal.html`: interactive reference GUI.
- `resources/Albedo_Horizontal_Light.bmp`, `...Nigredo.bmp`: bitmap layers.
- `resources/Albedo_Materia32_PCM24_96k.vtrb`: embedded original 32-material soundbank.
- `Presets/CP07_Quintessential_Collection`: 64 presets; factory array is also embedded in `include/albedo_factory_patches.hpp`.
- `tests/win32_gui_smoke.cpp`: native runtime interaction suite, Windows-only.
- `tests/qa_native_contract.py`: cross-platform source/geometry integrity test.
- `Build_Windows_x64.ps1`: Windows build and package verifier.
