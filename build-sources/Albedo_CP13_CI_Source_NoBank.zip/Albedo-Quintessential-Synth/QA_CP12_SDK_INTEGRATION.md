# CP12R1 Steinberg VST3 SDK integration audit

- Exact upstream URL: `https://github.com/steinbergmedia/vst3sdk#100` (README section ``The VST SDK package``; not SDK 1.0).
- Upstream README: SDK 3.8.x, Windows supported with MSVC Visual Studio 2022; build with CMake. License MIT.
- Reproducible upstream checkout: commit `3cdf9ca5d1f5b1b21e0a86832aa4abe55607bd96`, upstream commit message `VST3 SDK 3.8.1` dated 2026-08-11.
- Windows build PowerShell repaired: wrong regular expressions in both binary path matchers now match Windows/Unix path separators; `-SdkCommit` provenance pinned; recursive submodule verification.
- Unchanged: DSP engine sources, CLAP wrapper, VST3 wrapper, Win32/GDI native editor, 197 parameter IDs, 64 presets, PCM bank, approved source BMP artwork.
- Local Linux CMake/Ninja compilation succeeded; CTest **18/18 passed** on 2026-11-15; see `QA_CP12_SDK381_CTEST.log`.
- Static PowerShell inspection only; actual PowerShell/MSVC build has **not** been executed here.
- No VST3 ABI, PE/AMD64, Bitwig DAW scan, native GUI DPI or automation certification was performed.
- GitHub repo `uill12/Plugins-VST-s` was inspected and currently does not contain `Albedo-Quintessential-Synth` sources; workflow alone cannot build without publishing the source/assets.
