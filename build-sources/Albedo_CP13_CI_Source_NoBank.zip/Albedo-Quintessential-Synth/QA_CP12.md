# Albedo Quintessential Synth — CP12 GUI fidelity checkpoint

**Platform targets:** Windows x64 CLAP and VST3.  **Actual binaries here:** Linux x86-64 CLAP only.  **Windows status:** not compiled and not Bitwig-tested.

## Scope — no visual redesign

- Preserved approved horizontal 1920×1366 Albedo / Nigredo art BMPs **bit-for-bit**, plus original 32-material PCM24 96kHz bank (see immutable manifest hashes).
- Native Win32/GDI editor remains independent of WebView2. CLAP and Steinberg VST3 source wrappers instantiate the same editor and share 197 parameter IDs / 64 presets.
- Four engine waveform slots are now parameter-driven in the native editor (ten synthesis modes including Harmonic/Additive; FM remains removed). Waveform previews are **illustrative transfer curves**, not live analyzers.
- Existing native param-aware filters, ADSR envelope, cellular automata, macro spectrum, XY morph, selected/off network nodes, source/method/morph labels and light/Nigredo themes remain present.
- Corrected left/top letterbox pointer coordinate rounding so a one-pixel click just beyond a resized artwork edge is not rounded onto the artwork.
- Preserved the original 102 DOM-derived clickable GUI elements and 197 automatable host parameter IDs. Fixed stepped wheel increments so multiple accumulated steps are not lost.
- Preserved host gesture begin/end, pointer capture, continuous/stepped knobs, keyboard navigation, popup selectors, factory menu, native patch import/export, Synthesis Lab and full Parameter Atlas.

## Actual verification

1. **18/18 CTest pass** on Linux; includes DSP renders, source and soundbank checks, CLAP host smoke, native layout registry, event queue, 64-preset audio and new waveform/hit-region tests.
2. **816/816 geometry click-region tests** (102 controls × 8 editor viewport sizes: 1920×1366, 1600×1138, 1280×910, 900×620, 800×600, 2500×1700, 1200×854, 3840×2160). Numeric transform tests validate pointer coordinate mapping, not native Windows mouse delivery or DPI screenshots.
3. **10/10 synthesis method waveform responses** are finite/non-silent/distinguishable from analog reference under tested settings. Harmonic/Additive response reacts to user character parameters.
4. **25/25 Chromium HTML reference checks** pass with zero browser script errors at widths 1920, 1440, 1120, 760 and 430. Test generated reference screenshots in Albedo and Nigredo themes. The HTML reflows at narrow widths, while the native plugin proportionally scales the panoramic art.
5. **CP12 resource identity gate passed**: SHA-256 of original DSP/CLAP/VST3 audio plugin sources and all embedded BMP/PCM resources match the immutable baseline. Native editor changes are separately fingerprinted.

## What is **not** verified

- Windows x64 CLAP/VST3 has **not** been compiled in this Linux environment; no Windows SDK/target sysroot, Steinberg VST3 SDK or Windows host runtime is present.
- Windows native GDI pixel accuracy, pointer capture, popup positioning, window reparenting, 125–200% DPI scaling, the VST3 ABI, host automation and Bitwig project state load/reopen remain untested here.
- There is no independent native Windows screenshot. The HTML reference screenshots are **not** evidence of the Windows editor appearance.
- HTML responsive CSS reflow does not translate identically into the fixed-aspect native Win32 canvas. Native scales the entire canvas with preserved aspect ratio and letterboxes if necessary.
- No perceptual hi-fi certification is implied by finite audio render tests.

## Windows build recipe and required release gate

On Windows 10/11 x64 with Visual Studio 2022 Desktop C++ tools, Windows SDK, CMake, Git and network access (for the official Steinberg SDK):

```powershell
powershell -ExecutionPolicy Bypass -File .\Build_Windows_x64.ps1 -Configuration Release
```

This script rejects builds missing official VST3 SDK, runs CTest (including `cp08_win32_gui_interaction` on Windows), verifies real AMD64 PE exports (`clap_entry` / `GetPluginFactory`, `InitDll`, `ExitDll`) and creates a Windows CLAP + VST3 distribution ZIP **only on success**. The bundle is not attached to this CP12 checkpoint because it has not been produced.

Manual host acceptance gates in Bitwig Studio: scan, sound, GUI resize and parent reattach, popup menus, accurate pointer hit targets, both themes, all four source methods and waveforms, preset switch/reopen, host automation/undo, sample rates 44.1/48/88.2/96kHz, 64 patches/32 PCM materials, GDI screenshots at 100/125/150/200%, and compare to supplied `QA_CP12_Albedo_HTML.png` / `QA_CP12_Nigredo_HTML.png` references. Do not mark release certified until those pass.

