# Albedo Quintessential Synth — CP11 Windows Build Gate

**Date:** 2026-11-15. **Source base:** CP10 RGNES. This is a release-gate/source checkpoint; it is **not a compiled Windows distribution**.

## Recovered tooling from earlier account projects

- Clang and LLD used in Nereida/Rubedo; local executables are present.
- This Linux runtime does **not** have the Windows C++ sysroot/import libraries or headers; targeting `x86_64-w64-windows-gnu` fails at `<cstdint>`.
- Windows 2022 GitHub Actions provides Visual Studio 2022, Windows SDK, CMake and Python. The build script clones the **official** Steinberg VST3 SDK with submodules; `-ClapOnly` skips SDK and builds only CLAP.
- Source stays local unless separately pushed. GitHub workflow will not run until the source/assets are checked into `Albedo-Quintessential-Synth` on `albedo-cp11`.

## Changes in this checkpoint

- Pinned Windows CI workflow for `.clap` + `.vst3` on Windows 2022 and Python.
- Source-preserving RGNES PE verifier now checks AMD64 PE32+ DLL **and** named export: `clap_entry` for CLAP; `GetPluginFactory`, `InitDll`, `ExitDll` for VST3.
- Disabled default SDK symbolic-link creation (`SMTG_CREATE_PLUGIN_LINK OFF`) for CI compatibility.
- Fixed output release filename/folder/manifest and uploader branch to `CP11` (internal version deliberately remains CP10 until actual compilation).
- Added no new engine/GUI controls and modified no audio/render source bytes.

## Build on Windows

From the unpacked source directory:

```powershell
powershell -ExecutionPolicy Bypass -File .\Build_Windows_x64.ps1 -Configuration Release
```

Run the included `Publish_Windows_CI_To_GitHub.ps1` **only after reviewing public source distribution**; it uploads the complete source and PCM/bmp assets to the currently public GitHub repository. It triggers a Windows runner on push.

## Required RGNES release gate

Windows output is accepted only if CMake compiles both formats, native Win32 GUI test passes, PE exports verify, distribution ZIP independently extracts, resource fingerprints match, and an actual Windows host validates the editor and audio. CI can prove the first group only; **Bitwig host validation is pending**.

## Exact asset identity

`python tools/verify_source_assets.py` verifies source/GUI/DSP fingerprints and the embedded bitmap and PCM24 bank before compiling. The CI runner and CTest both execute it.
