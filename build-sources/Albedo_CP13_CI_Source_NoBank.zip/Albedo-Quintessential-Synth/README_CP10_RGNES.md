# Albedo Quintessential Synth · CP10 · RG​​NES Windows build checkpoint

Date: 2026-11-15  |  Formats requested: **Windows x64 CLAP and VST3**.

**Stage: SOURCE READY AND LINUX TESTED; WINDOWS BINARIES NOT COMPILED.**

This checkpoint applies the private user-owned `rgnes-gui-engineering` standards (1.3.0). The user-provided approved horizontal appearance and 102 DOM-based native hit regions are retained. Native GUI features are implemented in C++/Win32 without WebView2, but appearance/responsiveness on Windows must be independently verified in a native host.

## Changes from CP09 Nereida Bridge
- Native GDI fonts are cached per editor instead of recreated for every dynamic label on each repaint. All cached GDI objects are reclaimed at editor detach.
- Added static source/asset release gate (102 controls, 64 patches, 32-material PCM bank, stable plugin IDs, source metadata).
- Hardened PowerShell Windows build: required asset checks, AMD64 PE header verification, test-before-packaging, SHA-256/manifest.
- Added portable GitHub Actions workflow (Windows 2022) and optional user-run publisher. The publisher copies full source into a branch and installs the workflow at the repository root, because GitHub Actions cannot run a workflow stored only in a nested project folder.
- Preserved CLAP plugin ID, Steinberg processor/controller GUIDs, 197 parameter IDs, 64 presets and 32 PCM assets; no FM synthesis restored.

## Windows build on a Windows 10/11 x64 machine

1. Install Visual Studio 2022 with **Desktop development with C++**, Windows SDK, Git, CMake.
2. Extract the source, retaining the folders. In PowerShell run:

```powershell
powershell -ExecutionPolicy Bypass -File .\Build_Windows_x64.ps1 -Configuration Release
```

The script fetches the **official** Steinberg VST3 SDK with submodules. To use an existing checkout pass `-VST3Sdk 'C:\src\vst3sdk'`.

CLAP-only builds may pass `-ClapOnly` but **do not** satisfy the requested dual-format deliverable. Successful dual-format builds produce `Albedo_Quintessential_Synth_Windows_x64_CP10.zip` containing an installable `.clap` and `.vst3` bundle under `dist_windows_CP10`.

## GitHub Actions route

This project is not yet committed in the connected repository `uill12/Plugins-VST-s` and the container cannot run Windows builds. The optional `Publish_Windows_CI_To_GitHub.ps1` script, executed explicitly by the user on a computer with authenticated Git, pushes the source to branch `albedo-cp10` and installs the workflow at repository root. GitHub Actions then runs on `windows-2022`, compiles both formats, runs Windows CTest and publishes a verified distribution artifact. A successful build log and artifact are required before claiming `.clap`/`.vst3` binaries exist.

## RGNES release gates still pending

- Actual Windows compiler + Steinberg SDK compilation of both formats.
- Windows Win32 GUI smoke (gesture/XY/resize); reference screenshot parity at 100%, 125%, 150%, 200% and compact/default sizes.
- Host plugin scan, automation, save/reopen, MIDI, presets, sample rates in Bitwig for both CLAP and VST3.
- Audio callback timing, GUI repaint profiling, 64 presets and 32 materials in-host.
- Only after binary QA: promote `latest` distribution / Drive sync; no source-only upload masquerades as a release.
