# CP09 — Nereida reference/resource bridge

**Provenance:** The user's most recent Nereida package has been identified in their ChatGPT Library as `Nereida_v0.40.1_CP40_Full_Source.zip` (~29.6 MB) together with CP40 CLAP and VST3 Windows x64 archives. Two attempts to materialize the source ZIP returned an authorization error, so its raw bytes **were not acquired or inspected** in this workspace. No claim of copied CP40 code or assets is made.

## Applied locally to Albedo (independent implementation)

- Reimplemented a normalized dirty-state filter in `include/albedo_ui_dirty.hpp`, based on the Nereida checkpoint's documented 0.0025 delta policy; stepped parameters are compared exactly and 197 Albedo parameter IDs are not changed.
- Suppressed spurious repaint requests when a hover target does not change; added `WM_MOUSELEAVE` cleanup.
- Added `tests/ui_dirty_check.cpp` (20,000 subpixel updates, stepped mode boundaries, NAN).
- Added `tests/win32_gui_preview.cpp`, a native Win32 parent/host simulator compiled from **Albedo's same editor source**, with F12 screenshot capture, proportional resizing and real knob/popup interaction, but no audio or DAW host.
- Kept CLAP/VST3 parameter and preset registries unchanged. No OpenGL renderer was assumed to be working from Nereida or transplanted into Albedo.

## References to retrieve from the CP40 source when available

| Resource | Purpose | Gate |
|---|---|---|
| `src/NereidaUiScene.h` (if present) | Structural geometry, graph-region conventions | Adapt geometry, do not copy layout or Nereida branding |
| `renderer_migration/*.glsl`, WGL fallback | High-resolution shaded dynamic graphics | Compile/link on Windows + GPU fallback + host context-loss QA |
| Windows build scripts | PE32+ x64, CLAP/VST3 exports, SDK paths | Must use official Steinberg VST3 SDK |
| Sample-rate and native GUI QA | Multi-context audio rendering, DPI/resize tests | Pass Albedo 197-param / 64-preset tests |
| `src/NexoDspShared.h` | DSP safety patterns (not entire engine) | No FM implementation or parameter ID substitution |

The external Nereida assets should **not** be linked into Albedo until provenance, codec/sample rate, licensing (original or CC0), identity separation and audio tests have been checked. The present Albedo 32-material bank and 64 rebuilt factory patches remain authoritative.

## How to complete actual acquisition

After making a local copy of the CP40 archive available, run:

```bash
python tools/import_nereida_cp40.py /path/to/Nereida_v0.40.1_CP40_Full_Source.zip --extract
```

This performs safe read-only staging under `references/nereida_cp40_review/`, creates SHA256 manifests, and excludes binaries, samples, plugin identities and presets from automated import.

**Status:** Reference-level integration and implementation of two GUI practices complete; actual CP40 file-copy not complete. Windows compilation and Bitwig host QA not complete.
