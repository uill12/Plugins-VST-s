# Runs ONLY when the user explicitly executes this script on their machine.
# Uploads the source and assets so GitHub Actions can compile using real Windows.
param([string]$Repo='https://github.com/uill12/Plugins-VST-s.git',
      [string]$Branch='albedo-cp12')
$ErrorActionPreference='Stop'
$source=Split-Path -Parent $MyInvocation.MyCommand.Path
if(-not(Get-Command git -ErrorAction SilentlyContinue)){throw 'Git executable required'}
$temporary=Join-Path $env:TEMP ('Albedo_GitHub_'+[guid]::NewGuid().ToString('N'))
& git clone --depth 1 $Repo $temporary
if($LASTEXITCODE -ne 0){throw 'Unable to clone repository. Authenticate GitHub first.'}
Push-Location $temporary
try {
 $existing=& git ls-remote --heads origin $Branch
 if($LASTEXITCODE -ne 0){throw 'Could not query remote branch'}
 if($existing){
   & git fetch origin $Branch
   if($LASTEXITCODE -ne 0){throw 'Could not fetch existing CI branch'}
   & git checkout -b $Branch FETCH_HEAD
 }else{& git checkout -b $Branch}
 if($LASTEXITCODE -ne 0){ throw 'Could not check out CI branch' }
 $destination=Join-Path $temporary 'Albedo-Quintessential-Synth'
 New-Item -ItemType Directory -Force $destination | Out-Null
 Get-ChildItem -Force -LiteralPath $source | Where-Object {
  ($_.Name -notin @('.git','external','build_windows_x64','dist_windows_CP10','dist_windows_CP12','Publish_Windows_CI_To_GitHub.ps1')) -and ($_.Extension -notin @('.zip','.7z','.exe','.dll','.pdb'))
 } | ForEach-Object {Copy-Item -LiteralPath $_.FullName -Destination $destination -Recurse -Force}
 $ci=Join-Path $temporary '.github/workflows'
 New-Item -ItemType Directory -Force $ci | Out-Null
 Copy-Item (Join-Path $source '.github/workflows/albedo-cp12-windows.yml') (Join-Path $ci 'albedo-cp12-windows.yml') -Force
 & git add --all
 & git commit -m 'Albedo CP12R1: official Steinberg SDK 3.8.1 pinned Windows CLAP/VST3 source'
 if($LASTEXITCODE -ne 0){throw 'Could not create commit; configure git identity and retry.'}
 & git push --set-upstream origin $Branch
 if($LASTEXITCODE -ne 0){throw 'Push failed; no CI build was confirmed.'}
 Write-Host 'Source pushed. Open GitHub Actions and verify actual Windows build, CTest and PE binaries before installation.'
}finally{Pop-Location}
