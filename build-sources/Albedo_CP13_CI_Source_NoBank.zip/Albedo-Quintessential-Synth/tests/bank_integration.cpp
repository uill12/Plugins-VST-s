#include "vitriol_dsp.hpp"
#include <vector>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <cstdint>
#include <cstring>
#include <string>
int main(int argc,char**argv){
 if(argc<2)return 10;
 vitriol::Synth s;
 if(!s.loadResourceBank(argv[1])){std::fprintf(stderr,"Material bank failed to load\n");return 11;}
 if(!s.resourcesReady())return 12;
 const auto defs=s.descriptors();
 if(defs.size()<185)return 13;
 std::printf("id;material;sample_rate;rms;peak;signature\n");
 uint64_t first=0,unique=0;
 for(int ix=0;ix<32;ix++){
  double fs=(ix%2)?96000.:48000.;s.prepare(fs);
  for(int e=1;e<4;e++)s.setParam(1000+e*32+1,0);
  s.setParam(1000,7); // sample/time-warp: bank resource independently selectable
  s.setParam(1002,90);s.setParam(1010,ix);s.setParam(1006,0);s.setParam(1007,50);s.setParam(1008,20);
  s.setParam(2100,5);s.setParam(2101,5);s.setParam(3000,14000);s.setParam(3003,14000);
  s.setParam(3001,1);s.setParam(3004,1);s.setParam(5001,0);s.setParam(5003,0);s.setParam(5005,0);s.setParam(5007,0);
  s.setParam(9000,-9);s.setParam(3120,0);s.setParam(3121,0);
  s.noteOn(60,.8);
  const int n=int(fs*.22);float L[128]{},R[128]{};double rms=0,peak=0;uint64_t hash=1469598103934665603ull;
  for(int i=0;i<n;i+=128){int sz=std::min(n-i,128);s.process(L,R,sz);
   for(int j=0;j<sz;j++){
    if(!std::isfinite(L[j])||!std::isfinite(R[j]))return 20;
    peak=std::max(peak,std::abs(double(L[j])));rms+=double(L[j])*double(L[j]);
    uint32_t bits;std::memcpy(&bits,&L[j],sizeof(bits));hash^=bits;hash*=1099511628211ull;
   }
  }
  rms=std::sqrt(rms/n);
  if(rms<1e-5||peak>.9999){std::fprintf(stderr,"Fail bank %d: rms %.6f peak %.6f\n",ix,rms,peak);return 21;}
  if(ix==0)first=hash;if(ix>0&&hash!=first)unique++;
  std::printf("%d;%d;%.0f;%.8f;%.8f;%016llx\n",ix,ix,fs,rms,peak,(unsigned long long)hash);
 }
 if(unique<29)return 22;
 return 0;
}
