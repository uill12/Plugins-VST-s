#include "clap_abi_min.h"
#include <dlfcn.h>
#include <cassert>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <array>
#include <vector>
#include <string>
#include <iostream>
struct Events {clap_input_events_t iface{};std::vector<const clap_event_header_t*> event;
 Events(){iface.ctx=this;iface.size=[](const clap_input_events_t*p)->uint32_t{return uint32_t(static_cast<Events*>(p->ctx)->event.size());};iface.get=[](const clap_input_events_t*p,uint32_t i)->const clap_event_header_t*{auto& e=static_cast<Events*>(p->ctx)->event;return i<e.size()?e[i]:nullptr;};}
};
struct Mem{std::string bytes;size_t pos=0;clap_ostream_t out{};clap_istream_t in{};Mem(){out.ctx=this;out.write=[](const clap_ostream_t*p,const void* b,uint64_t n)->int64_t{auto*x=static_cast<Mem*>(p->ctx);x->bytes.append((const char*)b,n);return int64_t(n);};in.ctx=this;in.read=[](const clap_istream_t*p,void* b,uint64_t n)->int64_t{auto*x=static_cast<Mem*>(p->ctx);size_t got=std::min(size_t(n),x->bytes.size()-x->pos);memcpy(b,x->bytes.data()+x->pos,got);x->pos+=got;return int64_t(got);};}};
int main(int argc,char**argv){if(argc<2)return 2;void*lib=dlopen(argv[1],RTLD_NOW);if(!lib){std::cerr<<dlerror()<<"\n";return 2;}auto*entry=(const clap_plugin_entry_t*)dlsym(lib,"clap_entry");assert(entry);assert(entry->init(argv[1]));auto*factory=(const clap_plugin_factory_t*)entry->get_factory(CLAP_PLUGIN_FACTORY_ID);assert(factory&&factory->get_plugin_count(factory)==1);auto*desc=factory->get_plugin_descriptor(factory,0);assert(desc&&desc->id);clap_host_t host{};host.clap_version={1,2,0};host.name="VITRIOL smoke host";auto*p=factory->create_plugin(factory,&host,desc->id);assert(p&&p->init(p));
 auto*param=(const clap_plugin_params_t*)p->get_extension(p,CLAP_EXT_PARAMS);auto*audio=(const clap_plugin_audio_ports_t*)p->get_extension(p,CLAP_EXT_AUDIO_PORTS);auto*note=(const clap_plugin_note_ports_t*)p->get_extension(p,CLAP_EXT_NOTE_PORTS);auto*state=(const clap_plugin_state_t*)p->get_extension(p,CLAP_EXT_STATE);
 assert(param&&audio&&note&&state);assert(param->count(p)>100);clap_param_info_t info{};assert(param->get_info(p,0,&info)&&info.id==1000);assert(audio->count(p,false)==1&&audio->count(p,true)==0);assert(note->count(p,true)==1);
 assert(p->activate(p,48000,1,512)&&p->start_processing(p));
 clap_event_note_t on{{uint32_t(sizeof(on)),0,0,CLAP_EVENT_NOTE_ON,0},0,0,0,60,.95};clap_event_note_t off{{uint32_t(sizeof(off)),120,0,CLAP_EVENT_NOTE_OFF,0},0,0,0,60,0};
 clap_event_param_value_t cut{{uint32_t(sizeof(cut)),1,0,CLAP_EVENT_PARAM_VALUE,0},3000,nullptr,-1,-1,-1,-1,8200.};
 Events ev;ev.event={&on.header,&cut.header,&off.header};std::array<float,256> L{},R{};float* pointers[]={L.data(),R.data()};clap_audio_buffer_t out{};out.data32=pointers;out.channel_count=2;
 clap_process_t pr{};pr.frames_count=256;pr.audio_outputs=&out;pr.audio_outputs_count=1;pr.in_events=&ev.iface;
 assert(p->process(p,&pr)==CLAP_PROCESS_CONTINUE);double max=0,sum=0;for(int i=0;i<256;i++){assert(std::isfinite(L[i])&&std::isfinite(R[i]));max=std::max(max,double(std::abs(L[i])));sum+=std::abs(L[i]);}
 assert(sum>0.0001&&max<1.001);double val=0;assert(param->get_value(p,3000,&val)&&std::abs(val-8200)<.01);
 Mem mem;assert(state->save(p,&mem.out));assert(mem.bytes.rfind("VITRIOL_CP01",0)==0);
 clap_event_param_value_t cutReset{{uint32_t(sizeof(cutReset)),0,0,CLAP_EVENT_PARAM_VALUE,0},3000,nullptr,-1,-1,-1,-1,1000.};
 Events evReset; evReset.event={&cutReset.header};param->flush(p,&evReset.iface,nullptr);
 assert(param->get_value(p,3000,&val)&&std::abs(val-1000)<.01);
 mem.pos=0; assert(state->load(p,&mem.in));
 assert(param->get_value(p,3000,&val)&&std::abs(val-8200)<.01);
 assert(p->get_extension(p,CLAP_EXT_LATENCY));
 auto count=param->count(p);
 p->stop_processing(p);p->deactivate(p);p->destroy(p);entry->deinit();dlclose(lib);
 std::cout<<"CLAP factory, descriptor, extensions, timed MIDI and automation, stereo audio, state save/load roundtrip: PASS ("<<count<<" params)\n";
 return 0;}
