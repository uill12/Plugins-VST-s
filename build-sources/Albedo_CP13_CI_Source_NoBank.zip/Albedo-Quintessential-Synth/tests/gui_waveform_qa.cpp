#include "albedo_waveform_visuals.hpp"
#include <iostream>
#include <array>
#include <cmath>
#include <algorithm>
int main(){
 constexpr int w=333;
 std::array<std::array<double,w>,10> waves{};
 for(int method=0;method<10;method++){
  double energy=0.;
  for(int i=0;i<w;i++){
   double v=albedo_visual::sourceWave(method,.47,.62,.55,1,i,w);
   if(!std::isfinite(v)||std::abs(v)>1.001){std::cerr<<"nonfinite/out of range method "<<method;return 1;}
   waves[method][i]=v;energy+=v*v;
  }
  if(energy<0.005){std::cerr<<"silent diagram method "<<method;return 2;}
 }
 for(int m=1;m<10;m++){
  double distance=0.;for(int i=0;i<w;i++)distance+=std::abs(waves[m][i]-waves[0][i]);
  if(distance<3.5){std::cerr<<"method visual indistinguishable "<<m;return 3;}
 }
 double change=0.;for(int i=0;i<w;i++)change+=std::abs(albedo_visual::sourceWave(2,.1,.2,.3,0,i,w)-albedo_visual::sourceWave(2,.9,.8,.3,0,i,w));
 if(change<8.0){std::cerr<<"harmonic character did not alter response";return 4;}
 std::cout<<"CP12 visuals: 10/10 finite expressive wave diagrams, harmonic character dynamic\n";
 return 0;
}
