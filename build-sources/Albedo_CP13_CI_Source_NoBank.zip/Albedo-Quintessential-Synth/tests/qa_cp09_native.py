#!/usr/bin/env python3
from pathlib import Path
root=Path(__file__).resolve().parents[1]
ui=(root/'src/editor_native_win.cpp').read_text()
clap=(root/'src/clap_plugin.cpp').read_text()
required=['#include "albedo_gui_semantics.hpp"','kMethodCharacterLabels[method][int(c.id-1006)]','case WM_GETDLGCODE:','DLGC_WANTARROWS|DLGC_WANTTAB|DLGC_WANTCHARS','case WM_DPICHANGED_AFTERPARENT:','dark_?RGB(33,60,57)','openFactoryMenu()','openChoiceMenu(c)','selectedPreset_=pick-1;invalidate();','setParamNormalized']
for s in required[:-1]: assert s in ui, s
assert 'static bool gui_scale(const clap_plugin_t*,double scale)' in clap
assert 'std::abs(scale-1.0)<0.001' in clap
assert len(list((root/'Presets/CP07_Quintessential_Collection').glob('[0-9][0-9]_*.albp')))==64
print('CP09 native-interaction/source contract PASS')
