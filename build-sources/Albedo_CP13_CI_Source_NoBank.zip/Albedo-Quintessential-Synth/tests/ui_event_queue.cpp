#include "vitriol_ui_events.hpp"
#include <cassert>
#include <cstdio>
#include <thread>
#include <atomic>
#include <vector>
int main(){
 using vitriol::UiEvent;using vitriol::UiEventKind;using vitriol::UiEventQueue;
 UiEventQueue<16> q;
 assert(q.push({3000,0,UiEventKind::GestureBegin}));
 for(int i=0;i<14;i++)assert(q.push({3000,double(i),UiEventKind::Value}));
 assert(q.push({3000,0,UiEventKind::GestureEnd}));
 assert(!q.push({3000,99,UiEventKind::Value}));
 UiEvent v;assert(q.pop(v)&&v.kind==UiEventKind::GestureBegin);
 for(int i=0;i<14;i++){assert(q.pop(v));assert(v.kind==UiEventKind::Value&&v.value==i);}
 assert(q.pop(v)&&v.kind==UiEventKind::GestureEnd);assert(!q.pop(v));
 q.resetInactive();
 // A producer/consumer thread stress test validates acquisition/release order.
 constexpr int count=240000;
 UiEventQueue<1024> threaded;
 std::atomic<bool> ok{true};
 std::thread producer([&]{for(int i=0;i<count;i++){
   UiEvent e{uint32_t(i%131),double(i),UiEventKind::Value};
   while(!threaded.push(e))std::this_thread::yield();
 }});
 std::thread consumer([&]{for(int i=0;i<count;i++){
   UiEvent e;while(!threaded.pop(e))std::this_thread::yield();
   if(e.value!=double(i)||e.param!=uint32_t(i%131)||e.kind!=UiEventKind::Value)ok.store(false);
 }});
 producer.join();consumer.join();
 assert(ok.load()&&threaded.pending()==0);
 std::printf("GUI/DSP FIFO, overflow behavior, 240000 ordered threaded events: PASS\n");
 return 0;
}
