#!/usr/bin/env python3
"""CP08 browser reference QA: 4 engines, 64 presets, 10 methods, resizing, main UI gestures.
Only validates the HTML reference, not the native Windows editor."""
from pathlib import Path
import json
import subprocess
import time
import socket
from playwright.sync_api import sync_playwright
src=Path(__file__).resolve().parents[1]
html=src/'resources/Albedo_CP07_Horizontal.html'
report={'screens':[], 'checks':{}}
server=subprocess.Popen(['python','-m','http.server','18087','--bind','127.0.0.1','--directory',str(src/'resources')],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
time.sleep(1)
try:
 with sync_playwright() as p:
  b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  for w,h in [(1920,1366),(1600,1000),(1280,900),(980,900)]:
   page=b.new_page(viewport={'width':w,'height':h},device_scale_factor=1)
   page.goto('http://127.0.0.1:18087/Albedo_CP07_Horizontal.html',wait_until='load')
   page.wait_for_timeout(200)
   loc=page.locator('#preset option')
   opts=loc.count()
   sources=page.locator('[data-select]').count()
   methods=page.locator('#method option').count()
   report['screens'].append({'width':w,'height':h,'preset_options':opts,'sources':sources,'methods':methods,'body_scroll_width':page.evaluate('document.body.scrollWidth')})
   if w==1920:
    report['checks']['64_patches']=opts==65
    report['checks']['four_engines']=sources==4
    report['checks']['10_methods']=methods==10
    page.locator('[data-select="2"]').click()
    report['checks']['source_select']=page.evaluate('state.selected')==2
    page.locator('#method').select_option('Harmonic / Additive')
    report['checks']['harmonic_method']=page.evaluate('state.engines[2].method')=='Harmonic / Additive'
    # mouse double click knob reset is part of HTML interaction contract
    dial=page.locator('.dial').first
    report['checks']['visible_dial']=dial.is_visible()
   page.close()
  b.close()
finally:
 server.terminate();server.wait()
out=src/'QA_CP08_HTML_RESPONSIVE.json';out.write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
assert all(report['checks'].values()),report['checks']
