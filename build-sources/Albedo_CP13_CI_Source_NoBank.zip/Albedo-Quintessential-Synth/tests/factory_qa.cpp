#include "vitriol_dsp.hpp"
#include <array>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <set>
#include <string>
#include <vector>
#include <unordered_map>
using namespace vitriol;
namespace fs=std::filesystem;
int main(int argc,char**argv){
 if(argc!=3){std::cerr<<"usage: factory_qa <collection-dir> <bank-file>\n";return 1;}
 Synth synth;
 synth.prepare(48000);
 if(!synth.loadResourceBank(argv[2])||!synth.resourcesReady()){std::cerr<<"Bank resource missing\n";return 2;}
 const auto&defs=synth.descriptors();if(defs.size()!=197){std::cerr<<"Parameter ID count changed\n";return 3;}
 for(const auto& d:defs)if(d.name.find("FM")!=std::string::npos){std::cerr<<"Stale FM parameter\n";return 4;}
 std::vector<fs::path> patches;
 for(const auto&e:fs::directory_iterator(argv[1]))if(e.path().extension()==".albp")patches.push_back(e.path());
 std::sort(patches.begin(),patches.end());
 if(patches.size()!=64){std::cerr<<"Expected 64 patches; got "<<patches.size()<<"\n";return 5;}
 std::set<uint64_t> fingerprints;
 std::set<int> activeMethods,bankIds;
 int failures=0;
 for(const auto& patch:patches){
  std::ifstream in(patch);std::string magic;int version=0;in>>magic>>version;
  if(magic!="ALBEDO_NATIVE_PATCH"||version!=1){std::cerr<<"Bad header "<<patch<<"\n";return 6;}
  std::unordered_map<uint32_t,double> vals;
  uint32_t id;double v;
  while(in>>id>>v){vals[id]=v;}
  if(vals.size()!=defs.size()){std::cerr<<"Incomplete patch "<<patch.filename()<<" "<<vals.size()<<"\n";return 7;}
  bool bankVoice=false;
  for(auto& d:defs){
   if(!vals.contains(d.id)||!std::isfinite(vals[d.id])||vals[d.id]<d.min-1e-6||vals[d.id]>d.max+1e-6){std::cerr<<"Invalid param "<<d.id<<" in "<<patch.filename()<<"\n";return 8;}
   if(!synth.setParam(d.id,vals[d.id])){std::cerr<<"Rejected param id "<<d.id<<"\n";return 9;}
  }
  for(int e=0;e<4;e++){
   int base=1000+32*e,method=int(vals[base]);
   bankIds.insert(int(vals[base+10]));
   if(vals[base+1]>.5){activeMethods.insert(method);if(method==3||method==7)bankVoice=true;}
  }
  if(!bankVoice){std::cerr<<"No active PCM source in "<<patch.filename()<<"\n";return 10;}
  synth.reset();synth.noteOn(48,.84);
  std::array<float,256>l{},r{};
  double power=0,peak=0;uint64_t hash=1469598103934665603ull;
  for(int n=0;n<64;n++){
   synth.process(l.data(),r.data(),l.size());
   for(int k=0;k<256;k++){
    double a=l[k],b=r[k];if(!std::isfinite(a)||!std::isfinite(b)){std::cerr<<"Nonfinite audio "<<patch.filename()<<"\n";return 11;}
    power+=(a*a+b*b)*.5;peak=std::max(peak,std::max(std::abs(a),std::abs(b)));
    int32_t quant=int32_t(std::lround(std::clamp(a,-1.,1.)*32767));
    hash^=uint32_t(quant);hash*=1099511628211ull;
   }
  }
  double rms=std::sqrt(power/(64*256));
  fingerprints.insert(hash);
  if(peak>1.001||rms<.000002||rms>.85){failures++;std::cerr<<"Level QA "<<patch.filename()<<" peak="<<peak<<" rms="<<rms<<"\n";}
 }
 if(bankIds.size()!=32){std::cerr<<"Material coverage "<<bankIds.size()<<"/32\n";failures++;}
 if(activeMethods.size()!=10){std::cerr<<"Active synthesis method coverage "<<activeMethods.size()<<"/10\n";failures++;}
 if(fingerprints.size()<60){std::cerr<<"Low sound fingerprint diversity "<<fingerprints.size()<<"/64\n";failures++;}
 std::cout<<"CP07 factory QA: files="<<patches.size()<<" material_usage="<<bankIds.size()<<"/32 active_methods="<<activeMethods.size()<<"/10 unique_pcm_fingerprints="<<fingerprints.size()<<"/64 level_failures="<<failures<<"\n";
 return failures?12:0;
}
