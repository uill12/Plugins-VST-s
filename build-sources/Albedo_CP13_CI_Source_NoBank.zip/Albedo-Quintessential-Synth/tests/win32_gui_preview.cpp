#if defined(_WIN32)
#include "editor_native_win.hpp"
#include <windows.h>
#include <windowsx.h>
#include <algorithm>
#include <unordered_map>
#include <cstdint>
#include <cstdio>
#include <vector>
#include <cmath>

namespace {
vitriol::NativeEditor* editor=nullptr;
const wchar_t* previewClass=L"Albedo.CP09.GUIPreview";
void capture(HWND window){
 HWND child=editor?editor->hwnd():nullptr;if(!child)return;
 RECT r{};GetClientRect(child,&r);int w=r.right,h=r.bottom;
 if(w<=0||h<=0)return;
 HDC screen=GetDC(child);HDC memory=CreateCompatibleDC(screen);
 HBITMAP bitmap=CreateCompatibleBitmap(screen,w,h);
 if(!memory||!bitmap){if(bitmap)DeleteObject(bitmap);if(memory)DeleteDC(memory);ReleaseDC(child,screen);return;}
 HGDIOBJ original=SelectObject(memory,bitmap);
 BitBlt(memory,0,0,w,h,screen,0,0,SRCCOPY);
 BITMAPINFO info{};info.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);
 info.bmiHeader.biWidth=w;info.bmiHeader.biHeight=-h;
 info.bmiHeader.biPlanes=1;info.bmiHeader.biBitCount=24;
 info.bmiHeader.biCompression=BI_RGB;
 DWORD stride=DWORD(((w*24+31)/32)*4), size=stride*DWORD(h);
 std::vector<unsigned char> pixels(size);
 if(GetDIBits(memory,bitmap,0,UINT(h),pixels.data(),&info,DIB_RGB_COLORS)){
  BITMAPFILEHEADER file{};file.bfType=0x4d42;file.bfOffBits=sizeof(file)+sizeof(BITMAPINFOHEADER);
  file.bfSize=file.bfOffBits+size;
  if(FILE*f=_wfopen(L"Albedo_CP09_Native_Editor_Capture.bmp",L"wb")){
   fwrite(&file,1,sizeof(file),f);fwrite(&info.bmiHeader,1,sizeof(info.bmiHeader),f);
   fwrite(pixels.data(),1,pixels.size(),f);fclose(f);
   SetWindowTextW(window,L"ALBEDO · CAPTURED to Albedo_CP09_Native_Editor_Capture.bmp");
  }
 }
 SelectObject(memory,original);DeleteObject(bitmap);DeleteDC(memory);ReleaseDC(child,screen);
}
LRESULT CALLBACK parentProc(HWND w,UINT m,WPARAM wp,LPARAM lp){
 switch(m){
 case WM_SIZE:
  if(editor&&editor->hwnd())editor->resize(std::max(320,int(LOWORD(lp))),std::max(300,int(HIWORD(lp))));return 0;
 case WM_KEYDOWN:
  if(wp==VK_F12){capture(w);return 0;}break;
 case WM_DESTROY:PostQuitMessage(0);return 0;
 }
 return DefWindowProcW(w,m,wp,lp);
}
}
int WINAPI wWinMain(HINSTANCE h,HINSTANCE,LPWSTR,int show){
 WNDCLASSEXW wc{};wc.cbSize=sizeof(wc);wc.hInstance=h;wc.lpfnWndProc=parentProc;
 wc.lpszClassName=previewClass;wc.hCursor=LoadCursor(nullptr,IDC_ARROW);
 if(!RegisterClassExW(&wc))return 1;
 std::unordered_map<uint32_t,double> values;
 for(auto&p:vitriol::defineParams())values[p.id]=p.def;
 vitriol::NativeEditor instrument(
  [&](uint32_t id,double v){values[id]=v;},
  [&](uint32_t id)->double{auto it=values.find(id);return it!=values.end()?it->second:0.;});
 editor=&instrument;
 HWND host=CreateWindowExW(0,previewClass,L"ALBEDO · GUI INTERACTION PREVIEW · F12 screenshot · NO AUDIO",
     WS_OVERLAPPEDWINDOW|WS_CLIPCHILDREN,CW_USEDEFAULT,CW_USEDEFAULT,1430,1060,
     nullptr,nullptr,h,nullptr);
 if(!host){editor=nullptr;return 2;}
 RECT r{};GetClientRect(host,&r);
 if(!instrument.attach(host,r.right,r.bottom)){DestroyWindow(host);editor=nullptr;return 3;}
 ShowWindow(host,show);UpdateWindow(host);
 MSG msg{};while(GetMessageW(&msg,nullptr,0,0)>0){
  // The plugin editor has focus, so F12 goes to its HWND, not our parent.
  if(msg.message==WM_KEYDOWN&&msg.wParam==VK_F12){capture(host);continue;}
  TranslateMessage(&msg);DispatchMessageW(&msg);
 }
 instrument.detach();editor=nullptr;return int(msg.wParam);
}
#else
int main(){return 0;}
#endif
