#include "vitriol_native_layout.hpp"
#include <cmath>
#include <algorithm>
#include <array>
#include <iostream>
using namespace vitriol;
struct Transform {
 int sx{},sy{},ox{},oy{};
 explicit Transform(int w,int h){double f=std::min(double(w)/kArtWidth,double(h)/kArtHeight);
  sx=std::max(1,int(std::lround(kArtWidth*f)));sy=std::max(1,int(std::lround(kArtHeight*f)));
  ox=(w-sx)/2;oy=(h-sy)/2;
 }
 int fromX(int x)const{return int(std::floor((x-ox)*double(kArtWidth)/sx));}
 int fromY(int y)const{return int(std::floor((y-oy)*double(kArtHeight)/sy));}
 int toX(double x)const{return ox+int(std::lround(x*sx/kArtWidth));}
 int toY(double y)const{return oy+int(std::lround(y*sy/kArtHeight));}
};
int main(){
 const std::array<std::pair<int,int>,8> viewports={{{1920,1366},{1600,1138},{1280,910},{900,620},{800,600},{2500,1700},{1200,854},{3840,2160}}};
 auto controls=makeNativeControls();if(controls.size()!=102)return 1;
 int passed=0;
 for(auto [w,h]:viewports){Transform t(w,h);
  for(auto&c:controls){int px=t.toX(c.x+(c.w-1)/2.0),py=t.toY(c.y+(c.h-1)/2.0);
   if(!c.contains(t.fromX(px),t.fromY(py))){std::cerr<<"scaled click miss "<<w<<'x'<<h<<" control="<<c.label<<"\n";return 2;}
   passed++;
  }
  if(t.ox>0&&t.fromX(t.ox-1)>=0)return 3;
  if(t.oy>0&&t.fromY(t.oy-1)>=0)return 4;
 }
 for(int n=0;n<4;n++){
  const NativeControl c{0,0,100,100,1006,ControlKind::Dial,"Character",1};
  if(resolvedParam(c,n)!=uint32_t(1006+n*32))return 5;
 }
 std::cout<<"CP12 viewport test "<<passed<<" / "<<passed<<" geometry controls, source relative bindings preserved\n";
 return 0;
}
