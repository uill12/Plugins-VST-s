#!/usr/bin/env python3
"""Browser-level HTML reference checks (not a Windows native runtime substitute)."""
from pathlib import Path
import json, sys, traceback
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
html=(root/'resources/Albedo_CP07_Horizontal.html').read_text()
report={'task':'ALBEDO CP12 HTML UI interaction reference','engine':'Chromium set_content (offline)', 'viewports':[], 'checks':[], 'errors':[]}
def check(name, condition, detail=''):
    report['checks'].append({'name':name,'pass':bool(condition),'detail':detail})
    if not condition:print('FAIL:',name,detail,file=sys.stderr)

def state(pg, expr):return pg.evaluate('()=>'+expr)
with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    p=browser.new_page(viewport={'width':1920,'height':1366},device_scale_factor=1)
    p.on('pageerror',lambda e:report['errors'].append(str(e)))
    p.set_content(html,wait_until='domcontentloaded',timeout=25000)
    check('full name and renderer', 'ALBEDO' in p.title(),p.title())
    check('synth methods ten no FM', p.locator('#method option').count()==10 and not p.locator('#method').inner_text().count('FM'), str(p.locator('#method option').all_text_contents()))
    check('four independent generator cards',p.locator('.source-card').count()==4)
    check('64 factory patch options',p.locator('#preset option').count()==65)
    check('16 step buttons',p.locator('#steps button').count()==16)
    check('4 FX sections',p.locator('#fx .fx-line').count()==4)
    check('7 macro controls',p.locator('#macros .dial').count()==7)
    check('source waveforms',p.locator('.source-card svg.wave').count()==4)
    check('synthesis lab opens', (p.locator('#cp04LabOpen').click() or p.locator('#cp04Lab').evaluate("e=>e.classList.contains('open')")))
    p.locator('#cp04LabClose').click()
    check('synthesis lab closes',not p.locator('#cp04Lab').evaluate("e=>e.classList.contains('open')"))
    # Choose source C; check method editing affects only C
    p.locator('[data-select="2"]').click()
    check('source C selected',state(p,'window.ALBEDO_CP04.state.selected')==2)
    pre=state(p,'window.ALBEDO_CP04.state.engines[0].method')
    p.locator('#method').select_option(label='Harmonic / Additive')
    check('Harmonic/Additive applied only to source C',state(p,'window.ALBEDO_CP04.state.engines[2].method')=='Harmonic / Additive' and state(p,'window.ALBEDO_CP04.state.engines[0].method')==pre)
    # Knob move and reset
    d=p.locator('#engineKnobs .dial').first; key=d.get_attribute('data-key');before=state(p,'window.ALBEDO_CP04.state.engines[2].knobs[0]')
    box=d.bounding_box();p.mouse.move(box['x']+box['width']/2,box['y']+box['height']/2)
    p.mouse.down();p.mouse.move(box['x']+box['width']/2,box['y']-45,steps=4);p.mouse.up()
    after=state(p,'window.ALBEDO_CP04.state.engines[2].knobs[0]')
    check('knob pointer drag changes numeric state',after!=before,f'{before} -> {after}; key {key}')
    d.dblclick();check('knob reset after double-click',state(p,'window.ALBEDO_CP04.state.engines[2].knobs[0]')!=after)
    # XY field with coordinate-derived visual response
    xy=p.locator('#xy');r=xy.bounding_box();p.mouse.click(r['x']+r['width']*.78,r['y']+r['height']*.24)
    check('XY 2-axis interaction and readout',state(p,'window.ALBEDO_CP04.state.xy.x')>.65 and state(p,'window.ALBEDO_CP04.state.xy.y')<.35, p.locator('#coords').inner_text())
    # Filter graph must mutate in response to cutoff dial
    graph_before=p.locator('#filterA').inner_html()
    f=p.locator('#filterKnobsA .dial').first; bb=f.bounding_box();p.mouse.move(bb['x']+bb['width']/2,bb['y']+bb['height']/2);p.mouse.wheel(0,-250)
    check('filter graph changes with cutoff',p.locator('#filterA').inner_html()!=graph_before)
    # Effects, step UI, route editing, wave disable, theme
    s0=p.locator('#steps [data-step="0"]');v0=s0.get_attribute('aria-pressed');s0.click()
    check('step toggle visual+state',s0.get_attribute('aria-pressed')!=v0)
    before_routes=p.locator('#routes .route-row').count();p.locator('#addRoute').click()
    check('route add updates dynamic matrix',p.locator('#routes .route-row').count()==before_routes+1)
    p.locator('#routes [data-remove]').last.click()
    check('route removal restores count',p.locator('#routes .route-row').count()==before_routes)
    p.locator('#theme').click();check('Nigredo mode updates surface',p.locator('#page').evaluate("e=>e.classList.contains('nigredo')"))
    p.locator('#theme').click()
    # Large and compact screens. HTML reflows; native scales proportionally.
    for w,h in [(1920,1366),(1440,900),(1120,900),(760,860),(430,860)]:
        p.set_viewport_size({'width':w,'height':h})
        v=p.evaluate('''() => ({screen:window.innerWidth,scroll:document.documentElement.scrollWidth,mainW:document.querySelector('.page').getBoundingClientRect().width,sourceCount:document.querySelectorAll('.source-card').length})''')
        # 1px may arise from anti-aliasing but horizontal spill must not be large.
        check(f'HTML horizontal no overflow {w}x{h}',v['scroll']<=w+3,str(v))
        report['viewports'].append({'w':w,'h':h,**v})
    p.set_viewport_size({'width':1920,'height':1366});p.locator('#theme').click()
    (root/'QA_CP12_Nigredo_HTML.png').parent.mkdir(parents=True,exist_ok=True)
    p.screenshot(path=str(root/'QA_CP12_Nigredo_HTML.png'),full_page=True)
    p.locator('#theme').click()
    p.screenshot(path=str(root/'QA_CP12_Albedo_HTML.png'),full_page=True)
    browser.close()
report['pass_count']=sum(x['pass'] for x in report['checks'])
report['total']=len(report['checks'])
(root/'QA_CP12_HTML_Interaction_Results.json').write_text(json.dumps(report,indent=2)+'\n')
print('HTML',report['pass_count'],'/',report['total'],'ERRORS',len(report['errors']))
for e in report['errors']:print('PAGEERROR',e)
sys.exit(0 if report['pass_count']==report['total'] and not report['errors'] else 1)
