#include "albedo_factory_patches.hpp"
#include "vitriol_params.hpp"
#include <cmath>
#include <iostream>
int main(){
 auto defs=vitriol::defineParams();
 if(defs.size()!=albedo_factory::parameterIds.size()||albedo_factory::patches.size()!=64)return 1;
 for(size_t i=0;i<defs.size();i++){
  if(defs[i].id!=albedo_factory::parameterIds[i])return 2;
  for(const auto&patch:albedo_factory::patches)
   if(!std::isfinite(patch.values[i])||patch.values[i]<defs[i].min-.0001||patch.values[i]>defs[i].max+.0001)return 3;
 }
 std::cout<<"Factory header: 64 embedded presets × 197 correct parameter assignments\n";
}
