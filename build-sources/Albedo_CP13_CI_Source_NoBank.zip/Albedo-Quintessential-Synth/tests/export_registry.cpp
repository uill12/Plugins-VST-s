#include "vitriol_native_layout.hpp"
#include <iostream>
#include <iomanip>
#include <string>
#include <cstdio>
int main(){
 const auto params=vitriol::defineParams();const auto main=vitriol::makeNativeControls();const auto lab=vitriol::makeLabControls();
 auto esc=[](const std::string&s){std::string r;for(char c:s){if(c=='"'||c=='\\')r+='\\';if(c=='\n'){r+="\\n";continue;}r+=c;}return r;};
 std::cout<<"{\n \"schema\":\"vitriol-rgnes-cp04-1\",\"reference\":{\"width\":1600,\"height\":1576},\n \"parameters\":[\n";
 for(size_t i=0;i<params.size();i++){auto&v=params[i];
  std::cout<<"  {\"id\":"<<v.id<<",\"name\":\""<<esc(v.name)<<"\",\"group\":\""<<esc(v.group)<<"\",\"unit\":\""<<esc(v.unit)<<"\",\"min\":"<<std::setprecision(12)<<v.min<<",\"max\":"<<v.max<<",\"default\":"<<v.def<<",\"stepped\":"<<(v.stepped?"true":"false")<<"}"<<(i+1==params.size()?"\n":",\n");
 }
 auto controls=[&](const auto&v,const char*label){std::cout<<" ],\n \""<<label<<"\":[\n";
  for(size_t i=0;i<v.size();i++){const auto&c=v[i];std::cout<<"  {\"id\":"<<c.id<<",\"label\":\""<<esc(c.label)<<"\",\"x\":"<<c.x<<",\"y\":"<<c.y<<",\"w\":"<<c.w<<",\"h\":"<<c.h<<",\"kind\":"<<unsigned(c.kind)<<",\"sourceRelative\":"<<(c.sourceRelative?"true":"false")<<"}"<<(i+1==v.size()?"\n":",\n");
  }
 };
 controls(main,"mainControls");controls(lab,"labControls");
 std::cout<<" ],\n \"gestureRules\":{\"drag\":\"vertical/diagonal\",\"wheel\":\"fine\",\"doubleClick\":\"reset\"},\"source\":\"C++ parameter definitions and native widget coordinates\"\n}\n";
}
