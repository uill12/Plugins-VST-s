#include "vitriol_params.hpp"
#include "albedo_gui_semantics.hpp"
#include <cassert>
#include <cstring>
#include <cstdio>
#include <string>
int main(){
 using namespace vitriol;
 static_assert(sizeof(kMethodCharacterLabels)/sizeof(kMethodCharacterLabels[0])==10);
 auto d=defineParams();
 if(d.size()!=197){std::fprintf(stderr,"parameter count changed\n");return 1;}
 if(std::string(kMethods[2])!="Harmonic / Additive")return 2;
 for(const char* text:kMethodCharacterLabels[2]){
  if(std::strlen(text)<4 || std::strstr(text,"Feedback")||std::strstr(text,"Index")||std::strstr(text,"Ratio"))return 3;
 }
 const char* exp[]={"Harmonic Gain","Spectral Slope","Odd / Even","Material Blend"};
 for(int i=0;i<4;i++)if(std::strcmp(kMethodCharacterLabels[2][i],exp[i]))return 4;
 std::printf("CP09: additive labels match actual DSP; 197 IDs unchanged\n");return 0;
}
