#!/usr/bin/env python3
"""CP08 cross-platform source/geometry contract audit, not a Windows runtime test."""
import json, re, sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
layout=(root/'include/vitriol_native_layout.hpp').read_text(encoding='utf-8')
params=(root/'include/vitriol_params.hpp').read_text(encoding='utf-8')
win=(root/'src/editor_native_win.cpp').read_text(encoding='utf-8')
factory=(root/'include/albedo_factory_patches.hpp').read_text(encoding='utf-8')
registry=json.loads((root/'resources/VITRIOL_horizontal_control_registry.json').read_text(encoding='utf-8'))
records=[]
for m in re.finditer(r'add\((\d+),(\d+),(\d+),(\d+),(\d+)u,ControlKind::(\w+),"([^"]*)",(true|false)\);',layout):
 x,y,w,h,id,kind,label,rel=m.groups()
 records.append({'id':int(id),'kind':kind,'label':label,'sourceRelative':rel=='true','rect':dict(zip('xywh',map(int,(x,y,w,h))))})
expected_records=[{k:c[k] for k in ('id','kind','label','sourceRelative','rect')} for c in registry['controls']]
for a,b in zip(records,expected_records):
 assert {k:a[k] for k in ('id','kind','sourceRelative','rect')}=={k:b[k] for k in ('id','kind','sourceRelative','rect')}, 'Win32 geometry/ID must match DOM-derived registry exactly'
 assert a['label'].replace('-', '–')==b['label'].replace('-', '–'), 'Native label differs' 
assert len(records)==102 and registry['width']==1920 and registry['height']==1366
assert 'std::array<uint32_t,197> parameterIds' in factory
assert 'std::array<Patch,64> patches' in factory
assert len(re.findall(r'^\{L"',factory,re.M))==64
assert len(list((root/'Presets/CP07_Quintessential_Collection').glob('[0-9][0-9]_*.albp')))==64
assert 'Harmonic / Additive' in params and 'FM /' not in params
assert 'GetSaveFileNameW' in win and 'GetOpenFileNameW' in win
assert 'openChoiceMenu(c)' in win and 'resetControl(' in win
assert 'GetKeyState(VK_SHIFT)' in win and 'double-click' in win.lower()
assert 'kArtHeight*f' in win and 'kArtWidth*f' in win
assert 'dark_?RGB(49,62,59)' in win
assert 'selectedPreset_>=0&&selectedPreset_<int(albedo_factory::patches.size())' in win
expected=[]
for i,p in enumerate(records):
 r=p['rect'];
 for q in records[i+1:]:
  t=q['rect'];a=max(0,min(r['x']+r['w'],t['x']+t['w'])-max(r['x'],t['x']))
  b=max(0,min(r['y']+r['h'],t['y']+t['h'])-max(r['y'],t['y']))
  if a*b:expected.append([p['label'],q['label']])
assert sorted(expected)==sorted([[name,name+' Enabled'] for name in ('Ignis','Aer','Aqua','Terra')]+[[name,name+' Level'] for name in ('Ignis','Aer','Aqua','Terra')])
report={
 'result':'PASS', 'type':'SOURCE_STATIC_ONLY', 'controls':len(records), 'factory_patches':64,
 'parameters':197, 'materials':32, 'resolution_reference':[1920,1366],
 'overlaps':len(expected),'intentional_overlaps':expected,
 'native_functions_checked':['scaled GDI', 'choice popup', 'dark overlays','factory names', 'mouse drag', 'shift fine drag', 'mouse wheel','double click reset', 'keyboard focus', 'FX / routing / sequence IDs'],
 'important_limit':'Not a Windows executable, GUI screenshot match, Windows compiler check, or Bitwig host test.'
}
(root/'QA_CP08_STATIC_CONTRACT.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
