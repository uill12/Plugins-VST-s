#include "vitriol_native_layout.hpp"
#include <cstdio>
#include <algorithm>
int main(){
 auto w=vitriol::makeNativeControls();auto defs=vitriol::defineParams();
 if(w.size()<65){std::fprintf(stderr,"Too few native widgets: %zu\n",w.size());return 1;}
 for(auto &c:w){if(c.x<0||c.y<0||c.x+c.w>vitriol::kArtWidth||c.y+c.h>vitriol::kArtHeight){std::fprintf(stderr,"Control out of bounds: %u\n",c.id);return 2;}
  if(c.id>=0xffe00000u&&c.id<0xfff00000u)continue;
  if(c.kind==vitriol::ControlKind::Source){if(c.id<0xFFF00000u||c.id>0xFFF00003u)return 3;continue;}
  for(int i=0;i<(c.sourceRelative?4:1);i++){
   auto id=vitriol::resolvedParam(c,i);if(std::none_of(defs.begin(),defs.end(),[&](const vitriol::ParamDef&p){return p.id==id;})){
    std::fprintf(stderr,"Invalid mapped parameter %u\n",id);return 4;}
  }
 }
 std::printf("OK %zu native controls; %zu host parameters; full inspector provides all param access\n",w.size(),defs.size());
 return 0;
}
