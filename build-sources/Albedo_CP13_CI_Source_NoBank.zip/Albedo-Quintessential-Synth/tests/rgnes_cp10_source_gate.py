#!/usr/bin/env python3
"""RGNES source-level release gate. Does not certify Windows compilation/host GUI."""
import hashlib, json, re, sys
from pathlib import Path
r=Path(__file__).resolve().parents[1]
required={
 'src/clap_plugin.cpp':5000,
 'src/vst3_plugin.cpp':5000,
 'src/editor_native_win.cpp':9000,
 'src/vitriol_dsp.cpp':10000,
 'resources/Albedo_Horizontal_Light.bmp':1000000,
 'resources/Albedo_Horizontal_Nigredo.bmp':1000000,
 'resources/Albedo_Materia32_PCM24_96k.vtrb':1000000,
 'resources/Albedo_CP07_Horizontal.html':1000,
 'include/albedo_factory_patches.hpp':1000,
 'include/vitriol_native_layout.hpp':1000,
 'tests/win32_gui_smoke.cpp':1000,
 'tests/win32_gui_preview.cpp':1000,
}
checks=[]
for rel,minimum in required.items():
 f=r/rel
 assert f.is_file() and f.stat().st_size>=minimum,f'Missing or truncated asset: {rel}'
 checks.append({'path':rel,'size':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
registry=json.loads((r/'resources/VITRIOL_horizontal_control_registry.json').read_text())
assert (registry['width'],registry['height'])==(1920,1366)
assert len(registry['controls'])==102,len(registry['controls'])
presets=list((r/'Presets/CP07_Quintessential_Collection').glob('*.albp'))
assert len(presets)==64,len(presets)
header=(r/'include/albedo_factory_patches.hpp').read_text()
assert 'Glass Pressure' in header and 'Refractive' in header,'Factory bank linkage missing'
clap=(r/'src/clap_plugin.cpp').read_text()
vst=(r/'src/vst3_plugin.cpp').read_text()
gui=(r/'src/editor_native_win.cpp').read_text()
assert 'org.vitriol.opussonorum' in clap,'Stable CLAP ID changed'
assert '0xF379A344' in vst,'Stable VST3 processor UID changed'
assert 'Harmonic / Additive' in (r/'include/vitriol_params.hpp').read_text() or 'Harmonic / Additive' in (r/'include/albedo_gui_semantics.hpp').read_text() or 'Harmonic / Additive' in clap,'Additive method missing'
assert 'FontCacheScope' in gui and 'fontCache_.clear()' in gui,'GDI cache lifecycle missing'
assert 'GetModuleHandleExW' in gui and 'WM_DPICHANGED_AFTERPARENT' in gui,'Win32 lifecycle missing'
assert 'performEdit' in vst and 'setParamNormalized' in vst,'VST3 automation path missing'
assert 'CLAP_EXT_GUI' in clap,'CLAP native GUI extension missing'
# The source gate is deliberately idempotent; distribution evidence is checked separately.
print('RGNES CP10 SOURCE GATE PASS: 102 geometry regions, 64 patch files, stable CLAP/VST3 identities, 32-material bank asset present')
print(json.dumps({'status':'source-only','windows_compiled':False,'windows_gui_tested':False,'assets':checks},indent=2))
