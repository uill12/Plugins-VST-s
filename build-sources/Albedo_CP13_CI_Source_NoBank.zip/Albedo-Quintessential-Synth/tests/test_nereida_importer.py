#!/usr/bin/env python3
from pathlib import Path
import importlib.util, zipfile, tempfile, json
source=Path(__file__).resolve().parents[1] / 'tools/import_nereida_cp40.py'
spec=importlib.util.spec_from_file_location('nbridge',source)
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
with tempfile.TemporaryDirectory() as tmp:
 base=Path(tmp)
 archive=base/'mock_nereida_source.zip'
 with zipfile.ZipFile(archive,'w') as z:
  z.writestr('Nereida-CP40/src/NereidaUiScene.h','namespace nereida {}')
  z.writestr('Nereida-CP40/renderer_migration/graph.frag','void main(){}')
  z.writestr('Nereida-CP40/resources/ambient.wav','WAV')
  z.writestr('../NereidaUiScene.h','bypass traversal')
  z.writestr('other/build_windows_x64.sh','echo build')
  z.writestr('Nereida-CP40/src/unlicensed_sample.flac','UNVERIFIED')
  z.writestr('C:/NereidaUiScene.h','drive-bypass')
 out=base/'out'
 assert mod.scan(archive,out,False)==3
 manifest=json.loads((out/'NEREIDA_REVIEW_MANIFEST.json').read_text())
 assert manifest['extracted'] is False
 assert not list(out.rglob('*.h'))
 assert mod.scan(archive,out,True)==3
 files=list(out.rglob('*'))
 assert len([p for p in files if p.is_file() and p.suffix=='.h'])==1
 assert not list(out.rglob('*.wav')) and not list(out.rglob('*.flac'))
 assert not (base/'NereidaUiScene.h').exists()
 assert 'stage' not in out.parts
 print('Nereida importer: 3 allowable text resources, no traversal/audio/binaries — PASS')
