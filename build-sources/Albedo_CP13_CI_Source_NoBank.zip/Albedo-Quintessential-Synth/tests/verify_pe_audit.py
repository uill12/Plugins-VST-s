"""Unit fixtures for CP11 raw-PE export gate. Not a substitute for actual Windows build."""
import importlib.util
import struct
from pathlib import Path

MODULE=Path(__file__).resolve().parents[1]/'tools'/'verify_pe_exports.py'
spec=importlib.util.spec_from_file_location('pecheck',MODULE)
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

def fixture(names, is_dll=True):
    raw=bytearray(2048)
    raw[:2]=b'MZ'
    struct.pack_into('<I',raw,0x3c,0x80)
    raw[0x80:0x84]=b'PE\x00\x00'
    struct.pack_into('<HHIIIHH',raw,0x84,0x8664,1,0,0,0,0xf0,0x2022 if is_dll else 0x0022)
    opt=0x84+20
    struct.pack_into('<H',raw,opt,0x20b)
    struct.pack_into('<I',raw,opt+108,16)
    struct.pack_into('<II',raw,opt+112,0x1000,0x180)
    sh=opt+0xf0
    struct.pack_into('<IIII',raw,sh+8,0x400,0x1000,0x400,0x200)
    entries=len(names)
    struct.pack_into('<IIHHIIIIIII',raw,0x200,0,0,0,0,0x1030,1,entries,entries,0x1080,0x1090,0x10b0)
    for i,name in enumerate(names):
        pos=0x300+i*40
        encoded=name.encode('ascii')+b'\0'
        assert len(encoded)<=40
        raw[pos:pos+len(encoded)]=encoded
        struct.pack_into('<I',raw,0x290+4*i,0x1100+i*40)
        struct.pack_into('<H',raw,0x2b0+2*i,i)
    return bytes(raw)

def test():
    p=module.inspect(fixture(['clap_entry']))
    assert p['architecture']=='x86_64' and p['exports']==['clap_entry']
    names=['GetPluginFactory','InitDll','ExitDll']
    p=module.inspect(fixture(names))
    assert sorted(p['exports'])==sorted(names)
    for raw in [b'ELF'*100,fixture(['clap_entry'],False)]:
        try:module.inspect(raw)
        except module.PEError:pass
        else:raise AssertionError('Invalid PE should fail')
    print('CP11 PE export parser: PASS (CLAP, VST3 names, non-DLL, non-PE)')

if __name__=='__main__':test()
