#include "albedo_ui_dirty.hpp"
#include "vitriol_params.hpp"
#include <cassert>
#include <cmath>
#include <cstdio>
int main(){
 using namespace vitriol;
 UiDirtyTracker t;
 // First exposure always renders; tiny normalized jitter does not.
 assert(t.observe(2000,50.0,false,0,100));
 for(int i=0;i<20000;i++)assert(!t.observe(2000,50.0+std::sin(i*0.1)*0.20,false,0,100));
 assert(t.observe(2000,50.4,false,0,100));
 assert(!t.observe(2000,50.45,false,0,100));
 assert(t.observe(2000,51.0,false,0,100));
 // Stepped values are quantized and never suppressed on actual change.
 assert(t.observe(3010,0,true,0,4));
 assert(!t.observe(3010,0.2,true,0,4));
 assert(t.observe(3010,1,true,0,4));
 assert(!t.observe(3010,1.2,true,0,4));
 assert(t.observe(3010,2,true,0,4));
 assert(!t.observe(3010,NAN,true,0,4));
 auto params=defineParams();assert(params.size()==197);
 for(const auto& p:params){assert(!t.observe(p.id,NAN,p.stepped,p.min,p.max));}
 t.clear();assert(t.size()==0);
 printf("CP09 Nereida-inspired dirty filter: PASS; 20k subpixel updates suppressed; 197 parameter IDs intact\n");
}
