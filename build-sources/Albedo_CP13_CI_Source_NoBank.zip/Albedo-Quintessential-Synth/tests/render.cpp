#include "vitriol_dsp.hpp"
#include <vector>
#include <fstream>
#include <iostream>
#include <cmath>
#include <memory>
#include <cstring>
#include <cstdint>
#include <algorithm>
static void writeWav(const char* filename, const std::vector<float>& l, const std::vector<float>& r, int rate){
 auto out=std::ofstream(filename,std::ios::binary);auto u16=[&](uint16_t x){out.put(char(x&255));out.put(char((x>>8)&255));};auto u32=[&](uint32_t x){for(int i=0;i<4;i++)out.put(char((x>>(8*i))&255));};
 out.write("RIFF",4);u32(36+uint32_t(l.size()*8));out.write("WAVEfmt ",8);u32(16);u16(3);u16(2);u32(rate);u32(rate*8);u16(8);u16(32);out.write("data",4);u32(uint32_t(l.size()*8));for(size_t i=0;i<l.size();i++){out.write(reinterpret_cast<const char*>(&l[i]),4);out.write(reinterpret_cast<const char*>(&r[i]),4);}}
int main(int argc,char**argv){auto s=std::make_unique<vitriol::Synth>();int rate=argc>1?atoi(argv[1]):48000;int method=argc>2?atoi(argv[2]):1;int note=argc>4?atoi(argv[4]):60;int os=argc>5?atoi(argv[5]):0;double seconds=argc>6?std::clamp(atof(argv[6]),.06,4.):3.0;
 s->setParam(1000,method);s->setParam(1032+1,0);s->setParam(1064+1,0);s->setParam(1096+1,0);s->setParam(9000,-1);s->setParam(5005,0);s->setParam(5003,0);s->setParam(9002,os);
 s->prepare(rate);
 std::vector<float> l(size_t(rate*seconds)),r(l.size());s->noteOn(note,.85);
 const size_t block=512;bool released=false;
 for(size_t pos=0;pos<l.size();pos+=block){if(!released&&pos>l.size()*2/3){s->noteOff(note);released=true;}
  uint32_t n=uint32_t(std::min(block,l.size()-pos));s->process(l.data()+pos,r.data()+pos,n);}
 double peak=0,rms=0;bool finite=true;for(size_t i=0;i<l.size();i++){peak=std::max(peak,double(std::max(std::abs(l[i]),std::abs(r[i]))));rms+=(l[i]*l[i]+r[i]*r[i])/2.;finite &= std::isfinite(l[i])&&std::isfinite(r[i]);}rms=sqrt(rms/l.size());std::cout<<"sr="<<rate<<" method="<<method<<" note="<<note<<" OS="<<s->oversamplingFactor()<<" peak="<<peak<<" rms="<<rms<<" finite="<<finite<<"\n";
 if(argc>3)writeWav(argv[3],l,r,rate);return finite&&peak<1.001&&rms>.00002?0:1;}
