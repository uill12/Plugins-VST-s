// CP08 Windows-only native-GDI editor interaction and responsive-geometry smoke test.
// This does not replace visual review/Bitwig host QA; it verifies that Win32
// mouse input routes to the same parameter IDs that the CLAP/VST3 wrappers expose.
#if defined(_WIN32)
#include "editor_native_win.hpp"
#include <windows.h>
#include <windowsx.h>
#include <cmath>
#include <cstdio>
#include <cstdint>
#include <unordered_map>
#include <vector>

int main(){
 using namespace vitriol;
 std::unordered_map<uint32_t,double> values;
 for(const auto&p:defineParams())values[p.id]=p.def;
 std::vector<uint32_t> writes;
 int begins=0,ends=0;
 auto editor=NativeEditor(
  [&](uint32_t id,double v){values[id]=v;writes.push_back(id);},
  [&](uint32_t id)->double{auto it=values.find(id);return it==values.end()?0.0:it->second;},
  [&](uint32_t){++begins;},[&](uint32_t){++ends;});
 HINSTANCE inst=GetModuleHandleW(nullptr);
 HWND parent=CreateWindowExW(0,L"STATIC",L"CP08_UI_QA",WS_OVERLAPPEDWINDOW,
    0,0,1920,1366,nullptr,nullptr,inst,nullptr);
 if(!parent||!editor.attach(parent,1920,1366)){std::fprintf(stderr,"Could not create editor HWND\n");return 1;}
 HWND child=editor.hwnd();
 auto send=[&](UINT msg,int x,int y,WPARAM w=0){SendMessageW(child,msg,w,MAKELPARAM(x,y));};
 auto require=[&](bool condition,const char*why)->bool{if(!condition)std::fprintf(stderr,"UI QA: %s\n",why);return condition;};
 bool ok=true;
 // Center of first source's Character Shape knob, followed by vertical drag.
 const double before=values[1006];
 send(WM_LBUTTONDOWN,86,452,MK_LBUTTON);
 send(WM_MOUSEMOVE,86,392,MK_LBUTTON);
 send(WM_LBUTTONUP,86,392,0);
 ok&=require(std::abs(values[1006]-before)>0.1,"Dial drag must change source-A character parameter 1006");
 // HTML equivalent: double-click resets to parameter registry default.
 send(WM_LBUTTONDBLCLK,86,452,MK_LBUTTON);
 ok&=require(std::abs(values[1006]-before)<1e-6,"Dial double-click should restore default");
 // Source C selection must redirect source-relative dial edits to its own ID.
 const double sourceA=values[1006];
 send(WM_LBUTTONDOWN,1200,171,MK_LBUTTON);send(WM_LBUTTONUP,1200,171);
 const double beforeC=values[1070];
 send(WM_LBUTTONDOWN,86,452,MK_LBUTTON);
 send(WM_MOUSEMOVE,86,390,MK_LBUTTON);send(WM_LBUTTONUP,86,390);
 ok&=require(std::abs(values[1070]-beforeC)>.1,"Selected source C should receive relative Character Shape edits");
 ok&=require(std::abs(values[1006]-sourceA)<1e-6,"Unselected source A must remain unchanged");
 // Return to source A so later GUI checks retain their intended context.
 send(WM_LBUTTONDOWN,100,171,MK_LBUTTON);send(WM_LBUTTONUP,100,171);
 // Toggle output protection; real host parameter write (9001), not fake visual switch.
 const auto guard=values[9001];send(WM_LBUTTONDOWN,1847,1301,MK_LBUTTON);send(WM_LBUTTONUP,1847,1301);
 ok&=require(values[9001]!=guard,"Output guard hitbox must toggle host parameter 9001");
 // XY should generate both automation values from one gesture.
 send(WM_LBUTTONDOWN,949,439,MK_LBUTTON);send(WM_MOUSEMOVE,996,480,MK_LBUTTON);send(WM_LBUTTONUP,996,480);
 ok&=require(values[2100]>70&&values[2101]>80,"XY should update X(2100) and Y(2101)");
 // A resized native editor must map the same virtual-space hit region.
 editor.resize(1280,910);
 const double prev=values[2000];
 // geometry=1280/1920=2/3 with 1366*2/3=911 (within rounding)
 send(WM_LBUTTONDOWN,382,420,MK_LBUTTON);
 send(WM_MOUSEMOVE,382,370,MK_LBUTTON);
 send(WM_LBUTTONUP,382,370);
 ok&=require(std::abs(values[2000]-prev)>0.1,"Resized macro control should remain interactive");
 ok&=require(begins>0&&begins==ends,"Parameter gesture pairing must be balanced");
 ok&=require(writes.size()>=5,"Expected host parameter callbacks from inputs");
 // Verify native editor shortcut-mode transitions are safe (F3 Synthesis Lab,
 // F2 Parameter Atlas); focus movement should not alter host parameters.
 send(WM_KEYDOWN,0,0,VK_F3);send(WM_KEYDOWN,0,0,VK_ESCAPE);
 send(WM_KEYDOWN,0,0,VK_F2);send(WM_KEYDOWN,0,0,VK_ESCAPE);
 editor.detach();DestroyWindow(parent);
 std::printf("CP08 Win32 editor smoke: %s; host writes=%zu, gestures=%d/%d\n",ok?"PASS":"FAIL",writes.size(),begins,ends);
 return ok?0:2;
}
#else
int main(){return 0;}
#endif
