#!/usr/bin/env python3
"""Auditable offline smoke QA. This does NOT claim to prove final hi-fi quality."""
from pathlib import Path
import csv, subprocess, sys, json
from math import isfinite
root=Path(__file__).resolve().parent.parent
bin=root/'build'/'vitriol_render'
rows=[];fails=[]
for rate in (44100,48000,88200,96000,192000):
 for method in range(10):
  res=subprocess.run([str(bin),str(rate),str(method),"", "60", "0", "0.25"],text=True,capture_output=True)
  if res.returncode: fails.append(dict(rate=rate,method=method,error=res.stderr or res.stdout))
  fields={part.split('=')[0]:part.split('=')[1] for part in res.stdout.strip().split(' ') if '=' in part}
  rows.append({'sample_rate':rate,'method':method,'passed':res.returncode==0,'rms':fields.get('rms'),'peak':fields.get('peak')})
with open(root/'QA_50_RENDER_RESULTS.csv','w',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
print(json.dumps({'render_tests':len(rows),'passed':sum(r['passed'] for r in rows),'failed':fails},indent=2))
sys.exit(1 if fails else 0)
