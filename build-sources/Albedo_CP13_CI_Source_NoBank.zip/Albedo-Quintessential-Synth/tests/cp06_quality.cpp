// CP06 targeted regression checks: preserve 197 parameter IDs and verify
// click-free amplitude pulse and actual B->A filter order.
// Numerical smoke criteria are NOT a perceptual hi-fi certification.
#include "vitriol_dsp.hpp"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <vector>
#include <numeric>
using namespace vitriol;
static void configure(Synth& s) {
 s.prepare(48000);
 for(int e=0;e<4;e++){s.setParam(1001+32*e,e==0?1:0);}
 s.setParam(1000,0);s.setParam(1002,100);s.setParam(1006,75);s.setParam(1007,15);s.setParam(1008,40);
 s.setParam(2100,5);s.setParam(2101,5);
 s.setParam(2200,0);s.setParam(2201,0);s.setParam(2202,0);s.setParam(2203,0);s.setParam(2204,0);s.setParam(2205,0);
 s.setParam(3100,.001);s.setParam(3101,.01);s.setParam(3102,100);s.setParam(3103,.1);
 s.setParam(5001,0);s.setParam(5003,0);s.setParam(5005,0);s.setParam(5007,0);
 s.setParam(9001,0);s.setParam(9000,-12);s.setParam(9002,1);
 s.setParam(3000,13000);s.setParam(3003,13000);s.setParam(3001,2);s.setParam(3004,2);
 s.setParam(8300,0);
}
static std::vector<float> render(Synth& s,int count){
 std::vector<float> x(count);float a[128]{},b[128]{};
 for(int i=0;i<count;i+=128){int n=std::min(128,count-i);s.process(a,b,n);for(int j=0;j<n;j++){
  if(!std::isfinite(a[j])||!std::isfinite(b[j])){std::fprintf(stderr,"non-finite sample %d\n",i+j);return {};}
  x[i+j]=a[j];
 }}return x;
}
static double rms(const std::vector<float>&a,int start,int end){double q=0;for(int i=start;i<end;i++)q+=double(a[i])*a[i];return std::sqrt(q/(end-start));}
int main(){
 Synth s;
 if(s.descriptors().size()!=197){std::fprintf(stderr,"parameter registry size changed: %zu\n",s.descriptors().size());return 1;}
 // Click-free pulse: source sustains while 0.05s gate switches on->off->on.
 configure(s);s.setParam(6020,1);s.setParam(6021,.05);s.setParam(6022,100);s.setParam(6023,100);
 for(int i=0;i<16;i++)s.setParam(6000+i,i%2==0?1:0);
 s.noteOn(36,1);auto x=render(s,12000);if(x.empty())return 2;
 double boundary1=std::abs(x[2400]-x[2399]);double boundary2=std::abs(x[4800]-x[4799]);
 double on=rms(x,1200,2200),off=rms(x,3500,4500),back=rms(x,6000,7000);
 std::printf("CP06 pulse: on=%.6f off=%.6f onAgain=%.6f jumps=[%.6f,%.6f]\n",on,off,back,boundary1,boundary2);
 if(!(on>.004&&off<on*.17&&back>.004&&boundary1<.055&&boundary2<.055))return 3;
 // Bypass while the pulse is closed should release smoothly as well;
 // CP05 jumped straight to unity when toggling the module off.
 configure(s);s.setParam(6020,1);s.setParam(6021,.05);
 s.setParam(6022,100);s.setParam(6023,100);
 for(int i=0;i<16;i++)s.setParam(6000+i,i%2==0?1:0);
 s.noteOn(36,1);auto beforeBypass=render(s,4200);
 s.setParam(6020,0);auto afterBypass=render(s,1200);
 double bypassJump=std::abs(afterBypass.front()-beforeBypass.back());
 double bypassRecovered=rms(afterBypass,700,1100);
 std::printf("CP06 pulse bypass: immediate jump=%.6f recoveredRMS=%.6f\n",bypassJump,bypassRecovered);
 if(!(bypassJump<.055&&bypassRecovered>.004))return 9;
 // Output gain automation fades: a sudden -30 dB edit takes milliseconds,
 // not an instantaneous 30 dB jump. Uses a fresh oscillator and sustained note.
 configure(s);s.noteOn(36,1);auto baseline=render(s,4800);
 s.setParam(9000,-36);auto after=render(s,4800);
 double early=rms(after,0,240),late=rms(after,3600,4600);
 std::printf("CP06 gain ramp: early=%.6f late=%.6f\n",early,late);
 if(!(early>late*2.0&&late>0&&std::isfinite(late)))return 4;
 // Actual filter B->A is distinguishable from A->B with nonlinear
 // series topologies (not a disguised parallel blend).
 std::vector<float> routing[3];
 for(int route=0;route<3;route++){
  configure(s);s.setParam(6020,0);s.setParam(3010,1);s.setParam(3011,0);
  s.setParam(3000,700);s.setParam(3003,5900);s.setParam(3001,57);s.setParam(3004,20);
  s.setParam(3002,13);s.setParam(3005,7);s.setParam(3012,route);
  s.noteOn(48,.9);routing[route]=render(s,6500);if(routing[route].empty())return 5;
 }
 double err12=0,err02=0;for(int i=2400;i<6500;i++){
  err12+=std::pow(double(routing[1][i]-routing[2][i]),2);
  err02+=std::pow(double(routing[0][i]-routing[2][i]),2);
 }
 err12=std::sqrt(err12/4100);err02=std::sqrt(err02/4100);
 std::printf("CP06 routing: RMS difference A->B/B->A=%.8f, parallel/B->A=%.8f\n",err12,err02);
 if(!(err12>.0001&&err02>.0001))return 6;
 // Multi-rate, multi-oversampling path, and finite bounded output. Note this
 // is a DSP smoke test, not a proof of alias-free audio or high fidelity.
 for(double sr:{44100.,48000.,88200.,96000.,192000.})for(int q=1;q<=4;q++){
  s.prepare(sr);s.setParam(9002,q);s.setParam(6020,0);
  s.noteOn(64,.7);int n=int(sr*.008);auto sample=render(s,n);
  if(sample.empty())return 7;
  for(float f:sample)if(!std::isfinite(f)||std::abs(f)>1.0001)return 8;
 }
 std::puts("CP06 DSP regression checks PASS");return 0;
}
