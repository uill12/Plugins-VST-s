# Albedo Quintessential Synth — Windows x64 Build Kit CP13

The source bundle contains **full Albedo source, native Win32/GDI interface, 32 PCM materials, 64 factory patches, CLAP and VST3 entry points**. The official **Steinberg VST3 SDK 3.8.1** is downloaded by `Build_Windows_x64.ps1` and pinned to commit `3cdf9ca5d1f5b1b21e0a86832aa4abe55607bd96`.

## Executar no Windows

1. Extraia o ZIP **inteiro**, preservando os subdiretórios.
2. Instale o **Visual Studio 2022 Build Tools** com Desktop development with C++, **Windows SDK**, **CMake**, **Git**, e **Python 3** (adicionados ao PATH).
3. Clique duas vezes em `00_BUILD_WINDOWS_CLAP_AND_VST3.cmd`.
4. Se todas as etapas passarem, será produzido `Albedo_Quintessential_Synth_Windows_x64_CP12.zip`. Instale os arquivos `.clap` e `.vst3` desse ZIP e escaneie os plugins no Bitwig.

## Compilação e validação

O processo baixa o SDK oficial, compila x64 com MSVC 2022/CMake, executa CTest, verifica cabeçalhos de PE32+ AMD64 e exports CLAP/VST3, e verifica o ZIP final. Não há dependência de WebView2.

`WINDOWS_BUILD_LOG.txt` conterá o transcript de sucesso ou erro. A presença dos arquivos somente é aceita se a auditoria passar. Depois da compilação, ainda são obrigatórios os testes reais no Bitwig de desenho, resposta a DPI, gestos de automação, carregamento de patches e recuperação do estado.

### Honesty / status

Este kit foi preparado e testado estaticamente **em Linux**; os binários Windows não estão incluídos e **a compilação Windows ainda não ocorreu neste ambiente**. Não se deve distribuir resultados como 'compilados' sem executar o fluxo acima em um runner Windows. O script emite erros em vez de gerar um falso plugin.
