# Albedo Quintessential Synth — CP07

**Windows-oriented CLAP / VST3 synthesizer source, horizontal native GDI editor, 64 rebuilt factory patches, original 32-resource PCM24/96kHz soundbank, and Linux CLAP QA build.**

## New in CP07

- Public product identity: **Albedo Quintessential Synth** (v1.0.0-cp07). The horizontal alchemical GUI is preserved and relabeled with conventional synthesis terms alongside the original symbolism.
- Removed the FM/phase-modulation algorithm from method slot 2. This slot now runs a **band-limited additive/harmonic oscillator**, with 24 available partials, harmonic spectral tilt and odd/even balance. Operator-specific parameters 1016, 1017, 1048, 1049, 1080, 1081, 1112 and 1113 are remapped to additive controls. Their numeric IDs are preserved.
- Rebuilt the *Quintessential Collection*: **64 completely parameterized `.albp` factory presets** (8 material characters × 8 musical functions), using all **32 original PCM material resources**. 24 old developmental sketches are archived in `Presets/Archives/CP05_Starter_Morphologies`.
- Windows GUI now contains all 64 presets in a family/role submenu and reads them from its compiled-in factory table. The `.albp` files are additionally useful for importing/exporting individual patches; no external sample installation is needed after compiling the Windows resource bundle.
- Added a new `ALBEDO_NATIVE_PATCH 1` format; the native editor can also open **legacy** `VITRIOL_NATIVE_PATCH 1` files with `.vtrp` extension. Existing sessions using method slot 2 now sound additive rather than FM; old FM timbres cannot sound identical after removal.
- Kept the historical CLAP plugin ID `org.vitriol.opussonorum` and the preexisting VST3 class UIDs for host session compatibility. Source symbol names may retain `vitriol`; the **displayed plugin name and output files** are now Albedo.
- CPP synth core includes real A→B / B→A filter routing, smoothed automated filter/gain/pulse transitions, and 1×/2×/4×/8× quality modes (CP06); CP07 adds a 128-step cached harmonic spectral-tilt lookup to reduce real-time additive CPU consumption.

## Windows 10/11 x64 build

Requires Visual Studio 2022 with Desktop C++, CMake and Git. Network access is needed to obtain the **official Steinberg VST3 SDK** unless it is already available locally. From the source root:

```powershell
powershell -ExecutionPolicy Bypass -File .\Build_Windows_x64.ps1 -Configuration Release
```

Use `-ClapOnly` for native CLAP without SDK download or `-VST3Sdk "C:\path\to\vst3sdk"` to specify an existing official SDK. Successful builds are copied to `dist_windows_CP07` and packed into `Albedo_Quintessential_Synth_Windows_x64.zip`. The source also includes `.github/workflows/albedo-windows-x64.yml`, a manually triggered GitHub Actions build definition for `windows-2022`.

**Windows build status in this delivery: NOT BUILT or tested.** No Windows toolchain, SDK, Windows host, or network-enabled package download was available in the local container. The ZIP provided with this checkpoint contains reproducible Windows source and QA evidence, **not** a claimed Windows binary.

After a successful Windows build, copy `Albedo_Quintessential_Synth.clap` to `C:\Program Files\Common Files\CLAP\`, and the VST3 bundle into `C:\Program Files\Common Files\VST3\`. Remove duplicate previous binaries with the same plugin identity, rescan Bitwig, and test an empty project before migrating existing sessions.

## Local Linux test build

```bash
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build -j4
ctest --test-dir build --output-on-failure
```

A Linux `Albedo_Quintessential_Synth.clap` has been compiled and smoke-tested. The Linux binary **will not run on Windows**. QA covers 11 tests, including all 64 patch states and a 32-material bank integration test. Details: `QA_CP07.md`.

## Files

- `resources/Albedo_CP07_Horizontal.html`: interactive HTML GUI design reference, with 64 matching factory names, methods and macros. This HTML is an **interactive control prototype**, not a real-time audio synthesizer.
- `resources/Albedo_Horizontal_Light.bmp`, `Albedo_Horizontal_Nigredo.bmp`: 1920×1366 Win32/GDI GUI backgrounds generated from the horizontal HTML and overlaid with native parameter controls; plugin needs no WebView2.
- `resources/Albedo_Materia32_PCM24_96k.vtrb`: original dry mono PCM24/96k bank (32 materials), embedded as a Windows resource.
- `Presets/CP07_Quintessential_Collection/`: 64 new `.albp` factory patches and JSON manifest with roles, 32 material assignments and checksums.
- `include/albedo_factory_patches.hpp`: 64 × 197 embedded native factory snapshots.
- `tools/generate_cp07_factory.py`: reproducible patch/header generator (requires the local registry executable built by CMake).
- `tools/sync_gui_factory.py`: synchronizes the HTML patch list and host-parameter metadata.
- `src/`: native CLAP/VST3 wrappers, Win32 editor and DSP engine.
- `tests/`: source-level voice, audio, plugin ABI, resource, patch and Win32-layout regression tests.

## Audio quality scope

The goal is hi-fi timbral diversity for broad electronica and experimental sound design. Source render tests validate finite audio, no sample clipping, readable patches, material coverage and distinct digital render fingerprints. They do **not** certify perceptual sound quality, host stability on Windows, CPU/latency at high polyphony, spectral alias rejection, or equality of perceived loudness across presets. Further Bitwig audition and performance profiling are still required.
