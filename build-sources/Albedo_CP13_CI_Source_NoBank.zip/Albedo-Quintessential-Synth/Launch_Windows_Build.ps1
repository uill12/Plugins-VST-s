# Windows-only launcher — preserve an inspectable build log even on failure.
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$log = Join-Path $PSScriptRoot 'WINDOWS_BUILD_LOG.txt'
Start-Transcript -LiteralPath $log -Force | Out-Null
$exitCode = 1
try {
    & (Join-Path $PSScriptRoot 'Build_Windows_x64.ps1') -Configuration Release
    if (-not $?) { throw 'Native build script returned failure.' }
    $zip = Join-Path $PSScriptRoot 'Albedo_Quintessential_Synth_Windows_x64_CP12.zip'
    if (!(Test-Path -LiteralPath $zip -PathType Leaf)) { throw 'Native output archive missing after build.' }
    if (-not (Get-Command python.exe -ErrorAction SilentlyContinue)) { throw 'Python is required for the final distribution integrity gate.' }
    & python.exe (Join-Path $PSScriptRoot 'tools\validate_windows_release.py') $zip
    if ($LASTEXITCODE -ne 0) { throw 'Windows release verification failed.' }
    $exitCode = 0
} catch {
    Write-Error "Windows build failed: $_" -ErrorAction Continue
} finally {
    Stop-Transcript | Out-Null
}
exit $exitCode
