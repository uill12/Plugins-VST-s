#include "vitriol_dsp.hpp"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <limits>
#include <numbers>
#include <bit>
#include <fstream>
#include <cstdlib>
#include <iterator>
#if defined(_WIN32)
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#endif
namespace vitriol {
static constexpr double PI=3.1415926535897932384626433832795029, TAU=2*PI;
static inline double clamp(double x,double lo,double hi){return std::clamp(x,lo,hi);}
static inline double fract(double x){return x-std::floor(x);}
static inline double lerp(double a,double b,double t){return a+(b-a)*t;}
static inline double db(double d){return std::pow(10.0,d/20.0);}
static inline double polyblep(double t,double dt){ if(t<dt){t/=dt;return t+t-t*t-1;} if(t>1.0-dt){t=(t-1.0)/dt;return t*t+t+t+1.0;} return 0;}
static inline double cubic(double y0,double y1,double y2,double y3,double mu){double a0=y3-y2-y0+y1, a1=y0-y1-a0, a2=y2-y0, a3=y1;return ((a0*mu+a1)*mu+a2)*mu+a3;}
#if defined(_WIN32)
static void moduleAnchor(){}
#endif
Synth::Synth():defs_(defineParams()){
 for(const auto& p:defs_){values_[p.id].store(p.def,std::memory_order_relaxed);hasParam_[p.id]=true;}
 prepare(48000.0);
#if defined(_WIN32)
 HMODULE mod=nullptr;
 // Reference the current module by the constructor's text address, avoiding
 // host EXE resource lookup. Resource 102 is a true PCM24 sound bank, not filler.
 if(GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
   reinterpret_cast<LPCWSTR>(&moduleAnchor),&mod)){
   // RT_RCDATA is the numeric resource type 10; use the wide MAKEINTRESOURCE for FindResourceW.
   HRSRC r=FindResourceW(mod,MAKEINTRESOURCEW(102),MAKEINTRESOURCEW(10));
   if(r){HGLOBAL h=LoadResource(mod,r);if(h)loadResourceBankBytes(static_cast<const unsigned char*>(LockResource(h)),SizeofResource(mod,r));}
 }
#endif
 if(!bankReady_){if(const char* f=std::getenv("ALBEDO_BANK_PATH"))loadResourceBank(f);}
 if(!bankReady_){if(const char* f=std::getenv("VITRIOL_BANK_PATH"))loadResourceBank(f);}
}
bool Synth::loadResourceBank(const std::string& filename){
 std::ifstream f(filename,std::ios::binary);if(!f)return false;
 std::vector<unsigned char> data((std::istreambuf_iterator<char>(f)),{});
 return loadResourceBankBytes(data.data(),data.size());
}
bool Synth::loadResourceBankBytes(const unsigned char* bytes,size_t length){
 if(!bytes||length<20||std::memcmp(bytes,"VTRB1\0\0\0",8)!=0)return false;
 auto u32=[&](size_t p){return uint32_t(bytes[p])|(uint32_t(bytes[p+1])<<8)|(uint32_t(bytes[p+2])<<16)|(uint32_t(bytes[p+3])<<24);};
 uint32_t count=u32(8),sr=u32(12),n=u32(16);
 if(count!=32||sr!=96000||n<96000||n>480000||length!=20ull+3ull*count*n)return false;
 std::array<std::vector<float>,32> staging;
 size_t offset=20;
 for(uint32_t i=0;i<count;i++){
  staging[i].resize(n);
  for(uint32_t j=0;j<n;j++){
   int32_t x=int32_t(uint32_t(bytes[offset])|(uint32_t(bytes[offset+1])<<8)|(uint32_t(bytes[offset+2])<<16));
   if(x&0x800000)x-=0x1000000;
   staging[i][j]=float(double(x)/8388608.0);offset+=3;
  }
 }
 materialBank_.swap(staging);materialFrames_=n;materialSampleRate_=sr;bankReady_=true;
 return true;
}
double Synth::materialSample(int index,double phase)const{
 if(!bankReady_||materialFrames_<4)return 0;
 index=std::clamp(index,0,31);
 const auto& v=materialBank_[index];
 double x=fract(phase)*v.size();int i=int(x);double t=x-i;
 auto at=[&](int j){return double(v[(j+int(v.size()))%int(v.size())]);};
 return cubic(at(i-1),at(i),at(i+1),at(i+2),t);
}
double Synth::lfoShape(double phase,int shape){
 phase=fract(phase);
 switch(shape){
 case 1:return 1-4*std::abs(phase-.5);case 2:return 2*phase-1;
 case 3:return phase<.5?1:-1;case 4:return std::sin(TAU*phase*4.)*.4+std::sin(TAU*phase*9.)*.6;
 default:return std::sin(TAU*phase);
 }
}
void Synth::Delay::sizeTo(size_t n){buf.assign(std::max(size_t(16),n),0.0);pos=0;}
void Synth::Delay::clear(){std::fill(buf.begin(),buf.end(),0.0);pos=0;}
double Synth::Delay::read(double lag)const{if(buf.empty())return 0;double x=(double)pos-lag;while(x<0)x+=buf.size();x=std::fmod(x,double(buf.size()));size_t i=size_t(x),j=(i+1)%buf.size();return lerp(buf[i],buf[j],x-i);}
double Synth::Delay::tick(double x){if(buf.empty())return 0;buf[pos]=x;pos=(pos+1)%buf.size();return x;}
void Synth::Filter::clear(){ic1=ic2=combLP=0;std::fill(std::begin(ladder),std::end(ladder),0);comb.fill(0);combPos=0;}
double Synth::Filter::run(double x,double cut,double res,double drive,int type,double fs){
 cut=clamp(cut,18.0,fs*.43); res=clamp(res/100.0,0,.94);
 if(type==3){int del=std::max(2,std::min(4094,int(fs/std::max(cut,70.0))));int read=(combPos-del+4096)%4096;double old=comb[read];double y=x+old*(.10+.68*res);comb[combPos]=std::tanh(y*.8);combPos=(combPos+1)%4096;return clamp(y,-4,4)*.7;}
 // tanh nonlinearity occurs in oversampled domain
 x=std::tanh(x*db(drive));
 if(type==1){double g=1-std::exp(-TAU*cut/fs);double fb=2.0*res;double t=std::tanh(x-ladder[3]*fb);for(double& y:ladder){y+=g*(t-y);t=y;}return clamp(ladder[3]*1.28,-2,2);}
 double g=std::tan(PI*cut/fs);double Q=.55+res*11.;double k=1/Q;
 double a1=1/(1+g*(g+k)), a2=g*a1,a3=g*a2;
 double v3=x-ic2;double v1=a1*ic1+a2*v3;double v2=ic2+a2*ic1+a3*v3;
 ic1=2*v1-ic1;ic2=2*v2-ic2;
 if(type==0){double morph=res*.25;return clamp(lerp(v2,v1*1.8,morph),-3,3);}
 if(type==2){ // dual vocal peaks: vocal formant second resonant bank is approximated by a moving bandpass
  double comb=std::sin(2*PI*clamp(cut/9500,0,1))*0.2;return clamp((v1*(3.+res)+v2*.3)*(1+comb),-3,3);
 }
 return clamp(x-k*v1,-3,3); // notch
}
void Synth::prepare(double fs){fs_=clamp(fs,8000.0,384000.0);
 for(int t=0;t<128;t++){double slope=.45+double(t)/127.*(4.5-.45);for(int h=1;h<=24;h++)harmonicTilt_[t][h-1]=std::pow(double(h),-slope);}
 for(int h=0;h<11;h++){int partial=std::max(1,1024>>h);for(int j=0;j<2048;j++){double x=double(j)/2048.*TAU;double v=0;for(int k=1;k<=partial;k++)v+=std::sin(k*x)/k;wavetable_[h][j]=v*(2.0/PI);}}
 proceduralSample_.assign(32768,0);for(int i=0;i<int(proceduralSample_.size());i++){double t=i/double(proceduralSample_.size()),fade=std::exp(-t*7); proceduralSample_[i]=(std::sin(TAU*(62*t+17*t*t))*.62+std::sin(TAU*(181*t+3*t*t))*.2+std::sin(TAU*49*t)*.08)*fade;}
 for(int c=0;c<2;c++){auto& f=fx_[c];f.chorus.sizeTo(size_t(fs_*.075)+8);for(int j=0;j<4;j++)f.reverb[j].sizeTo(size_t(fs_*.115)+8);for(int j=0;j<2;j++)f.ap[j].sizeTo(size_t(fs_*.018)+8);f.diffuse.sizeTo(size_t(fs_*.11)+8);}
 prevOS_=0;setupDecimator(oversamplingFactor());reset();}
void Synth::setupDecimator(int os){if(prevOS_==os)return;prevOS_=os;cutoffSmoothAlpha_=1.-std::exp(-1./(.003*fs_*os));decimLen_=32;const double fc=.44/os;double sum=0;for(int i=0;i<decimLen_;i++){double m=i-(decimLen_-1)/2.;double v=2*fc*(std::abs(m)<1e-12?1:std::sin(TAU*fc*m)/(TAU*fc*m));double window=.42-.5*std::cos(TAU*i/(decimLen_-1))+.08*std::cos(2*TAU*i/(decimLen_-1));v*=window;decimCoeffs_[i]=v;sum+=v;}for(int i=0;i<decimLen_;i++)decimCoeffs_[i]/=sum;for(auto& h:decimHist_)h.fill(0);decimPos_=0;}
void Synth::reset(){for(auto& v:voices_)v=Voice{};for(auto& f:filters_)for(auto& channel:f)channel.clear();for(auto& c:fx_){c.chorus.clear();for(auto& x:c.reverb)x.clear();for(auto& x:c.ap)x.clear();c.diffuse.clear();std::fill(std::begin(c.reverbLP),std::end(c.reverbLP),0);c.diffLP=0;}clock_=0;ageCounter_=0;lfoPhase_=lfo2Phase_=lfoSlew_=motion_=0;meterL_=meterR_=0;
 cutoffLogSmooth_[0]=std::log2(std::max(20.0,get(3000)));
 cutoffLogSmooth_[1]=std::log2(std::max(20.0,get(3003)));
 pulseGain_=1.0;outputGainSmooth_=db(get(9000));
 for(auto& h:decimHist_)h.fill(0);}
bool Synth::setParam(uint32_t id,double v){if(id>=kParamStorage||!hasParam_[id]||!std::isfinite(v))return false;for(const auto& d:defs_)if(d.id==id){values_[id].store(d.stepped?std::round(clamp(v,d.min,d.max)):clamp(v,d.min,d.max),std::memory_order_relaxed);return true;}return false;}
double Synth::getParam(uint32_t id)const{return (id<kParamStorage&&hasParam_[id])?get(id):0;}
int Synth::oversamplingFactor()const{int opt=int(get(9002));return opt==0?4:opt==1?1:opt==2?2:opt==3?4:8;}
uint32_t Synth::noise(Voice& v){uint32_t x=v.random;x^=x<<13;x^=x>>17;x^=x<<5;return v.random=x?x:0x87654321u;}
double Synth::noteHz(int note)const {
 const int tuning=int(get(3112));
 if(tuning==1||tuning==2){ // Twelve-note octave-based just or Pythagorean intervals
  static constexpr double just[]={1.,16./15.,9./8.,6./5.,5./4.,4./3.,45./32.,3./2.,8./5.,5./3.,9./5.,15./8.};
  static constexpr double pyth[]={1.,256./243.,9./8.,32./27.,81./64.,4./3.,729./512.,3./2.,128./81.,27./16.,16./9.,243./128.};
  const int d=note-60,oct=int(std::floor(double(d)/12.)),idx=((d%12)+12)%12;
  return 261.6255653005986*std::pow(2.,oct)*(tuning==1?just[idx]:pyth[idx]);
 }
 if(tuning==3)return 440.*std::pow(2.,(note-69.)/19.); // 19-EDO: MIDI step mapped to one 19-EDO degree
 if(tuning==4)return 440.*std::pow(2.,(note-69.)/24.); // 24-EDO: MIDI step mapped to one quarter tone
 return 440.*std::pow(2.,(note-69.)/12.);
}

void Synth::noteOn(int n,double vel,int channel){n=std::clamp(n,0,127);vel=clamp(vel,0,1);int mode=int(get(3111));
 if((mode==1||mode==2)&&mode==2&&voices_[0].active){auto& v=voices_[0];v.note=n;v.velocity=vel;v.released=false;return;}
 int subvoices=mode==3?3:1;
 for(int k=0;k<subvoices;k++){
 Voice* voice=(mode==1||mode==2)?&voices_[0]:nullptr;
 if(!voice)for(auto& v:voices_)if(!v.active){voice=&v;break;}
 if(!voice)voice=&*std::min_element(voices_.begin(),voices_.end(),[](const Voice&a,const Voice&b){return a.age<b.age;});
 // Audio-thread-safe: reset only scalar state, not the 256 KB fixed resonator storage.
 voice->active=true;voice->released=false;voice->envStage=0;voice->env=0;voice->filterStage=0;voice->filterEnv=0;voice->cellClock=0;voice->caBits=1u<<16;voice->cellValue=.0;
 std::fill(std::begin(voice->phase),std::end(voice->phase),0);for(int e=0;e<4;e++){
  const double amount=get(1000+e*32+20)*.01;
  voice->phase[e]=amount*(double(noise(*voice))/4294967295.0);
  for(int u=0;u<8;u++)voice->unisonPhase[e][u]=fract(.17*u+e*.11+amount*.29*double(noise(*voice))/4294967295.0);
 }
 std::fill(std::begin(voice->subphase),std::end(voice->subphase),0);
 std::fill(std::begin(voice->colorLP),std::end(voice->colorLP),0);
 std::fill(std::begin(voice->grainPhase),std::end(voice->grainPhase),0);
 std::fill(std::begin(voice->samplePos),std::end(voice->samplePos),0);
 std::fill(std::begin(voice->stringPos),std::end(voice->stringPos),0);
 voice->note=n;voice->ch=channel;voice->velocity=vel/(subvoices==3?1.4:1);voice->age=++ageCounter_;
 voice->detuneCents=subvoices==3?(k-1)*7.:0.;voice->panOffset=subvoices==3?(k-1)*22.:0.;
 voice->freq=noteHz(n)*std::pow(2.,bend_*2/12);
 voice->random=0x19827361u+uint32_t(n*768457+ageCounter_*193);
 for(int e=0;e<4;e++)if(int(get(1000+32*e))==5){
   int period=int(clamp(fs_*oversamplingFactor()/std::max(10.,voice->freq),4,8190));
   for(int j=0;j<period;j++){double z=(double(noise(*voice))/4294967295.0)*2.0-1.0;voice->strings[e][j]=z*.40;}
 }
 }
}
void Synth::noteOff(int note,int channel){for(auto& v:voices_)if(v.active&&v.note==note&&v.ch==channel){v.released=true;v.envStage=3;}}
void Synth::allNotesOff(){for(auto& v:voices_)if(v.active){v.released=true;v.envStage=3;}}
void Synth::midiCC(int cc,int val){if(cc==1)modwheel_=clamp(val/127.,0,1);if(cc==123||cc==120)allNotesOff();}
void Synth::bend(int value14){bend_=clamp((value14-8192)/8192.,-1,1);for(auto& v:voices_)if(v.active)v.freq=noteHz(v.note)*std::pow(2.,bend_*2/12);}
void Synth::aftertouch(double v){aftertouch_=clamp(v,0,1);}
int Synth::activeVoices()const{int n=0;for(auto& v:voices_)n+=v.active?1:0;return n;}
double Synth::voiceEnvelope(Voice& v,double fsInternal){double a=std::max(.001,get(3100)),d=std::max(.01,get(3101)),s=get(3102)*.01,r=std::max(.01,get(3103));
 if(v.released&&v.envStage!=3)v.envStage=3;
 switch(v.envStage){case 0:v.env+=1./(a*fsInternal);if(v.env>=1){v.env=1;v.envStage=1;}break;
 case 1:v.env+=(s-v.env)*(1-std::exp(-5/(d*fsInternal)));if(std::abs(v.env-s)<.001)v.envStage=2;break;
 case 2:v.env=s;break;
 case 3:v.env*=std::exp(-7/(r*fsInternal));if(v.env<.000035){v.active=false;v.env=0;}break;}
 return clamp(v.env,0,1);}
void Synth::runCells(Voice& v,int rule,double rate,double fsInternal){int steps=int(clamp(fsInternal/clamp(rate,.02,24),1,1e7));if(++v.cellClock<uint32_t(steps))return;v.cellClock=0;uint32_t next=0;for(int i=0;i<32;i++){int pattern=((v.caBits>>((i+31)%32))&1u)*4+((v.caBits>>i)&1u)*2+((v.caBits>>((i+1)%32))&1u);next|=uint32_t((rule>>pattern)&1)<<i;}v.caBits=next?next:1u<<((v.note+int(clock_/512))%32);v.cellValue=double(std::popcount(v.caBits))/32.;}
double Synth::routeSource(int src,const Voice& v,double lfo1,double lfo2,double follower)const{switch(src){case 0:return lfo1;case 1:return lfo2;case 2:return v.env*2-1;case 3:return v.env*2-1;case 4:return v.cellValue*2-1;case 5:return v.velocity*2-1;case 6:return modwheel_*2-1;case 7:return aftertouch_*2-1;case 8:return get(2100)/50.-1;case 9:return get(2101)/50.-1;case 10:return (v.note-60)/60.;case 11:return follower*2-1;default:return 0;}}
double Synth::soft(double x){return std::tanh(x);}
double Synth::limit(double x){return x/(1+std::abs(x));}
double Synth::sourceSample(Voice& v,int e,int method,double freq,double a,double b,double c,double d,double fsInt){
 freq=clamp(freq,12.,fsInt*.44);double dt=freq/fsInt,phase=v.phase[e],sub=v.subphase[e];double y=0;
 auto advance=[&](double p,double speed){return fract(p+speed);};
 switch(method){
 case 0:{ // polyBLEP analog: saw/pulse blend with suboscillator
  double width=clamp(.08+.84*c,.08,.92);double saw=2*phase-1-polyblep(phase,dt);double pulse=(phase<width?1.:-1.)+polyblep(phase,dt)-polyblep(fract(phase-width),dt);double tri=(4*std::abs(phase-.5)-1);double character=lerp(saw,pulse,a);y=lerp(character,tri,b*.22)+.30*d*std::sin(TAU*sub);break;}
 case 1:{ // bandlimited mipmapped wavetable with color warp and fold
  double desired=clamp(freq,16,fsInt*.25);int allowed=std::max(1,int(fsInt*.44/desired));int mip=0;while(mip<10 && (1024>>mip)>allowed)mip++;double warped=fract(phase+b*.25*std::sin(TAU*phase));double x=warped*2048.;int ix=int(x);double mu=x-ix;
  auto sample=[&](int idx){return wavetable_[mip][(idx+2048)&2047];};
  double saw=cubic(sample(ix-1),sample(ix),sample(ix+1),sample(ix+2),mu);double sine=std::sin(TAU*warped);double shape=lerp(sine,saw,a);y=std::tanh(shape*(1+c*2.5))/(1+.2*c)+.15*d*std::sin(TAU*sub);break;}
 case 2:{ // hi-fi harmonic additive oscillator: no FM/PM operators or feedback
  const int requested=std::clamp(int(get(1000+e*32+16)),1,24);
  const double tilt=std::clamp(get(1000+e*32+17)+(.5-b)*1.6,.45,4.5);
  const double oddEven=(c-.5)*1.5;
  const int harmonics=std::min(requested,std::max(1,int(std::floor(fsInt*.44/std::max(1.,freq)))));
  // Trigonometric recurrence avoids dozens of sin() calls per sample.
  const double angle=TAU*phase,si=std::sin(angle),co=std::cos(angle);
  double sk=si,ck=co,sum=0,norm=0;
  const double index=(tilt-.45)/(4.5-.45)*127.;
  const int ix=std::clamp(int(index),0,126);
  const double mu=std::clamp(index-ix,0.,1.);
  for(int h=1;h<=harmonics;h++){
   const double eo=(h&1)?(1.+oddEven*.28):(1.-oddEven*.28);
   const double weight=eo*lerp(harmonicTilt_[ix][h-1],harmonicTilt_[ix+1][h-1],mu);
   sum+=sk*weight;norm+=weight;
   const double ns=sk*co+ck*si,nc=ck*co-sk*si;sk=ns;ck=nc;
  }
  const double harmonic=sum/std::max(.001,norm);
  const double material=bankReady_?materialSample(int(get(1000+e*32+10)),phase):0.;
  y=(harmonic*(.82+.18*a)+material*.15*d)*1.6;
  break;}
 case 3:{ // procedural Hann-windowed particle cloud; deterministic embedded source, no licensed samples
  double speed=.28+b*4,position=fract(v.samplePos[e]+d*.18);int n=int(proceduralSample_.size());
  double k=position*n;int idx=int(k);double f=k-idx;
  auto samp=[&](int shift){return proceduralSample_[(idx+shift+n)%n];};
  double sample=bankReady_?materialSample(int(get(1000+e*32+10)),position):cubic(samp(-1),samp(0),samp(1),samp(2),f);
  double gp=v.grainPhase[e];int winType=int(get(1000+e*32+15));
  double win=winType==1?std::sin(PI*gp):winType==2?std::min(1.0,std::min(gp,1-gp)*7):winType==3?std::exp(-18*std::pow(gp-.5,2)):.5-.5*std::cos(TAU*gp);
  y=sample*win*2.0+(c*.25)*std::sin(TAU*phase);
  v.samplePos[e]=fract(v.samplePos[e]+speed/(fsInt*(.03+.15*a)));
  v.grainPhase[e]=fract(v.grainPhase[e]+(2.+28*b)/fsInt);break;}
 case 4:{ // additive spectral generator / freeze-like partial map (not audio-input resynthesis)
  double frozen=lerp(lfoSlew_,v.cellValue,a);double spectrumTilt=clamp(.4+b*2,.4,2.4);double sum=0,norm=0;
  for(int k=1;k<=20;k++){double amp=1/std::pow(k,spectrumTilt);double shift=1.+c*.025*std::sin(k*.6+frozen*9);sum+=amp*std::sin(TAU*phase*k*shift+d*k*.32);norm+=amp;}y=sum/std::max(norm,.01)*1.55;break;}
 case 5:{ // Karplus-Strong physical/modal resonator with envelope excitation
  int period=int(clamp(fsInt/freq,4,8190));int pos=v.stringPos[e];double prev=v.strings[e][(pos+1)%period];double now=v.strings[e][pos];
  double damping=.981+.0186*(1.-b);double next=(prev+now)*.5*damping;
  v.strings[e][pos]=next;
  v.stringPos[e]=(pos+1)%period;
  y=lerp(next,now,c*.7)*(0.8+a*.8);break;}
 case 6:{ // white / brown / highpass stochastic color
  double n=(double(noise(v))/4294967295.0)*2.-1.;double alpha=.003+.28*clamp(.5*b+.5*get(1000+e*32+18)*.01,0,1);v.colorLP[e]+=alpha*(n-v.colorLP[e]);y=lerp(v.colorLP[e]*4.,n-v.colorLP[e],a);y+=(c*.45)*std::sin(TAU*phase*2);y*=.45+.7*d;break;}
 case 7:{ // timewarp / procedural one-shot sample; editable start and time-stretch surrogate
  int N=int(proceduralSample_.size());double speed=lerp(.20,2.2,b);double pos=fract(v.samplePos[e]+a*.8);double k=pos*N;int ix=int(k);double f=k-ix;
  auto samp=[&](int shift){return proceduralSample_[(ix+shift+N)%N];};
  y=(bankReady_?materialSample(int(get(1000+e*32+10)),pos):cubic(samp(-1),samp(0),samp(1),samp(2),f))+c*.18*std::sin(TAU*phase*(1+d*.6));v.samplePos[e]=fract(v.samplePos[e]+(bankReady_?speed*(freq/261.625565)*materialSampleRate_/(fsInt*materialFrames_):(speed*freq/180)/fsInt));break;}
 case 8:{ // phase distortion / Casio-like phase warp with band-limited oversampled output
  double split=clamp(.07+.86*a,.07,.93);double pd=phase<split?phase*.5/split:.5+(phase-split)*.5/(1-split);pd=fract(pd+b*.12*std::sin(TAU*phase));double v0=std::sin(TAU*pd);y=std::tanh(v0*(1+3*c))*(.8+.2*d);break;}
 case 9:{ // cellular timbral motion; no MIDI pitch generation
  double cells=v.cellValue;double jitter=std::sin(TAU*(phase+(cells-.5)*b*.5));double p2=std::sin(TAU*sub*(1.+a*3.));y=lerp(jitter,p2,c)*(.75+.35*d)+.25*cells*std::sin(TAU*phase*3);break;}
 default:y=std::sin(TAU*phase);break;
 }
 v.phase[e]=advance(phase,dt);v.subphase[e]=advance(sub,(freq*(method==0?.5:1.5))/fsInt);
 if(!std::isfinite(y))y=0;
 return clamp(y,-4,4);
}
double Synth::filterEnvelope(Voice& v,double fsInternal){
 double a=get(3122),d=get(3123),s=get(3124)*.01,r=get(3125);
 if(v.released)v.filterStage=3;
 if(v.filterStage==0){v.filterEnv+=1./std::max(1.,a*fsInternal);if(v.filterEnv>=1){v.filterEnv=1;v.filterStage=1;}}
 else if(v.filterStage==1){v.filterEnv+=(s-v.filterEnv)*(1.-std::exp(-1./std::max(1.,d*fsInternal)));if(std::abs(v.filterEnv-s)<.0001)v.filterStage=2;}
 else if(v.filterStage==2)v.filterEnv=s;
 else v.filterEnv*=std::exp(-1./std::max(1.,r*fsInternal));
 return clamp(v.filterEnv,0,1);
}
void Synth::sampleVoice(Voice& v,int os,double& vl,double& vr){const double sr=fs_*os;double env=voiceEnvelope(v,sr);if(!v.active)return;double fe=filterEnvelope(v,sr);filterEnvFrame_+=fe*env;
 const double targetHz=noteHz(v.note)*std::pow(2.,bend_*2./12.);double glideMs=get(3130);v.freq+=(targetHz-v.freq)*(glideMs<=.01?1.0:(1.-std::exp(-1000./(sr*glideMs))));
 const double rate=get(4000),depth=get(4001)*.01;const int rules[]={30,90,110,150};int rule=rules[std::clamp(int(get(4003)),0,3)];runCells(v,rule,rate,sr);
 double lfo1=lfoShape(lfoPhase_,int(get(4011)))*get(4013)*.01,lfo2=lfoShape(lfo2Phase_,int(get(4012)))*get(4014)*.01;
 double mod[12]{};int active=std::clamp(int(get(8300)),0,8);
 for(int i=0;i<active;i++){int id=8000+i*3;int src=std::clamp(int(get(id)),0,11),dst=std::clamp(int(get(id+1)),0,11);double amt=get(id+2)*.01;mod[dst]+=routeSource(src,v,lfo1,lfo2,v.env)*amt;}
 double brightness=clamp((get(2000)/100.+.22*mod[6]),0,1),exchange=clamp((get(2001)/100.+.3*mod[7]),0,1);
 double xyx=get(2100)*.01,xyy=get(2101)*.01;
 double w[]={ (1-xyx)*(1-xyy),xyx*(1-xyy),(1-xyx)*xyy,xyx*xyy };
 double base[4]{};double unisonSide[4]{};double gainNorm=0;
 for(int e=0;e<4;e++){
  if(get(1000+32*e+1)<.5)continue;
  double a=clamp((get(1000+e*32+6)+20*(e==0?mod[2]:e==1?mod[3]:e==2?mod[4]:mod[5]))/100. + (brightness-.5)*.25,0,1);
  double b=get(1000+e*32+7)*.01,c=get(1000+e*32+8)*.01,d=get(1000+e*32+9)*.01;
  double tune=get(1000+32*e+3);double track=get(1000+32*e+5)>=.5?1:0;
  double pitchLab=int(get(3110))==1?mod[11]*5.0:int(get(3110))==2?mod[11]*2.0:0;
  double micro=get(1000+32*e+21)/100.+get(3131)/100.*(v.cellValue-.5);
  double freq=(track?v.freq:noteHz(60))*std::pow(2.,(tune+pitchLab+v.detuneCents/100.+micro)/12.);
  double noiseDepth=(v.cellValue-.5)*depth*.24*(.3+get(2005)/100.);
  int m=int(get(1000+32*e));base[e]=sourceSample(v,e,m,freq,a,clamp(b+noiseDepth,0,1),clamp(c+mod[10]*.08,0,1),d,sr);
  int uni=std::clamp(int(get(1000+32*e+11)),1,8);
  if(uni>1&&(m==0||m==1||m==2||m==8||m==9)){
   double detune=get(1000+e*32+12),spread=get(1000+e*32+13)*.01,side=0,sides=0;
   for(int u=1;u<uni;u++){
    double shift=(double(u)/(uni-1)-.5)*2.*detune/1200.;
    double f=freq*std::pow(2.,shift);
    double& ph=v.unisonPhase[e][u];ph=fract(ph+f/sr);
    double sample=std::sin(TAU*ph);side+=sample;sides+=sample*shift/40.*spread;
   }
   base[e]=(base[e]+side*.80)/std::sqrt(double(uni));
   unisonSide[e]=sides*.4/std::sqrt(double(uni));
  }
  double transient=clamp(get(1000+e*32+14)/100.,0,1);
  base[e]*=1.+(transient-.5)*.9*(1.-std::min(1.,env*5.));
  base[e]+=std::sin(TAU*v.subphase[e])*.25*get(1000+e*32+19)*.01;
  double level=get(1000+32*e+2)*.01;
  w[e]=(0.24+.76*w[e])*level;gainNorm+=w[e];
 }
 // Each pair is independent, reciprocal and strictly bounded; zero is a true bypass.
 constexpr int pairs[6][2]={{0,1},{0,2},{0,3},{1,2},{1,3},{2,3}};
 double coupled[4];std::copy(std::begin(base),std::end(base),coupled);
 for(int i=0;i<6;i++){int a=pairs[i][0],b=pairs[i][1];if(!(w[a]>0&&w[b]>0))continue;double amount=get(2200+i)*.01*exchange*.24;if(amount<=0)continue;double cross=std::tanh(base[a]*base[b]);coupled[a]+=amount*cross;coupled[b]+=amount*cross;}
 double yL=0,yR=0;for(int e=0;e<4;e++){if(w[e]<=0)continue;double pan=clamp((get(1000+e*32+4)+v.panOffset+mod[9]*30)/100.,-1,1);double angle=(pan+1)*PI*.25;double scale=coupled[e]*w[e],st=unisonSide[e]*w[e];yL+=(scale-st)*std::cos(angle);yR+=(scale+st)*std::sin(angle);}
 const double inverse=1./std::max(.6,gainNorm);
 double impact=get(2003)*.01,contour=get(2002)*.01;
 double gain=env*std::pow(v.velocity,.55+contour*.6)*(.68+impact*.35)*(1.+depth*.12*(v.cellValue-.5))*inverse*1.4142;
 vl+=clamp(yL*gain,-8,8);vr+=clamp(yR*gain,-8,8);
 for(int i=0;i<12;i++)modFrame_[i]+=mod[i]*env;
 modWeight_+=env;
}
void Synth::nextInternal(double& l,double& r,int os){l=r=0;double xL=0,xR=0;std::fill(std::begin(modFrame_),std::end(modFrame_),0.);modWeight_=0;filterEnvFrame_=0;for(auto& v:voices_)if(v.active)sampleVoice(v,os,xL,xR);xL*=.42;xR*=.42;
 double normMod=1./std::max(1.,modWeight_);for(double& m:modFrame_)m*=normMod;
 // filter pair A/B with independently selectable topologies and serial/parallel routing
 double envF=filterEnvFrame_/std::max(1.,modWeight_);
 double targetA=std::clamp(std::log2(std::clamp(get(3000)*std::pow(2.,modFrame_[0]*3+envF*get(3120)*.045),20.,fs_*os*.42)),4.3,18.0);
 double targetB=std::clamp(std::log2(std::clamp(get(3003)*std::pow(2.,modFrame_[1]*3+envF*get(3121)*.045),20.,fs_*os*.42)),4.3,18.0);
 // 3 ms exponential ramp measured in INTERNAL samples. Filter cutoff automation
 // remains consistent at 44.1–192 kHz and in 1×–8× quality modes.
 cutoffLogSmooth_[0]+=(targetA-cutoffLogSmooth_[0])*cutoffSmoothAlpha_;
 cutoffLogSmooth_[1]+=(targetB-cutoffLogSmooth_[1])*cutoffSmoothAlpha_;
 double cutA=std::exp2(cutoffLogSmooth_[0]),cutB=std::exp2(cutoffLogSmooth_[1]);
 double resA=get(3001),resB=get(3004),drA=get(3002),drB=get(3005);
 int typeA=int(get(3010)),bmap[]={2,0,1,3,4},typeB=bmap[std::clamp(int(get(3011)),0,4)],routing=std::clamp(int(get(3012)),0,2);
 // True B→A series must feed filter B into filter A. CP05 mislabeled
 // an ordinary parallel blend as B→A. Parallel and A→B are preserved.
 if(routing==2){
  double bL=filters_[1][0].run(xL,cutB,resB,drB,typeB,fs_*os);
  double bR=filters_[1][1].run(xR,cutB,resB,drB,typeB,fs_*os);
  l=filters_[0][0].run(bL,cutA,resA,drA,typeA,fs_*os)*.9;
  r=filters_[0][1].run(bR,cutA,resA,drA,typeA,fs_*os)*.9;
 }else{
  double aL=filters_[0][0].run(xL,cutA,resA,drA,typeA,fs_*os);
  double aR=filters_[0][1].run(xR,cutA,resA,drA,typeA,fs_*os);
  double bL=filters_[1][0].run(routing==1?aL:xL,cutB,resB,drB,typeB,fs_*os);
  double bR=filters_[1][1].run(routing==1?aR:xR,cutB,resB,drB,typeB,fs_*os);
  l=(routing==1?bL:(aL+bL)*.5)*.9;
  r=(routing==1?bR:(aR+bR)*.5)*.9;
 }
 double width=clamp(get(2004)*.01+modFrame_[9]*.22,0,1.5);
 double mid=(l+r)*.5,side=(l-r)*.5*(.15+width*1.25);
 l=mid+side;r=mid-side;
 l=std::tanh(l*1.0);r=std::tanh(r*1.0);
 double lf1=get(4000),lf2=get(4010);
 lfoPhase_=fract(lfoPhase_+lf1/(fs_*os));lfo2Phase_=fract(lfo2Phase_+lf2/(fs_*os));
 double slew=get(4002)*.01;lfoSlew_+= (1.-slew*.9995)*(std::sin(lfoPhase_*TAU)-lfoSlew_);
}
void Synth::processEffects(double& l,double& r){
 for(int c=0;c<2;c++){
  double x=c? r:l;auto& fx=fx_[c];
  if(get(5001)>.5){double wet=get(5000)*.01;double bias=get(5012)*.003;double y=(std::tanh((x+bias)*2.)-std::tanh(bias*2.))*.58;x=lerp(x,y,wet);}
  if(get(5003)>.5){double wet=get(5002)*.01;double t=double(clock_)/fs_;double lag=fs_*(.014+.008*std::sin(TAU*(get(5008)*t+c*(.05+get(5009)*.002))));
    double y=fx.chorus.read(lag);fx.chorus.tick(x);x=lerp(x,(x+y*.7)*.84,wet);}
  if(get(5005)>.5){double wet=clamp((get(5004)+modFrame_[8]*20)*.01,0,1);const double lengths[]={.0297,.0371,.0411,.0437};double reverb=0;
   for(int i=0;i<4;i++){double delayed=fx.reverb[i].read(fs_*lengths[i]*(c?1.035:1)*get(5011)*.01);fx.reverbLP[i]+=(.06+.54*(1.-get(5010)*.01))*(delayed-fx.reverbLP[i]);fx.reverb[i].tick(x*.16+std::tanh(fx.reverbLP[i]*(.58+get(2006)*.003)));reverb+=delayed;}
   reverb=std::tanh(reverb*.45);x=lerp(x,reverb,wet*.62);}
  if(get(5007)>.5){double wet=get(5006)*.01;double delay=fx.diffuse.read(fs_*(c?.037:.051));fx.diffuse.tick(x*.35+delay*.42);fx.diffLP+=.06*(delay-fx.diffLP);x=lerp(x,fx.diffLP,wet*.55);}
  if(c)r=x;else l=x;
 }
}
void Synth::process(float* l,float* r,uint32_t n){
 int os=oversamplingFactor();if(os!=prevOS_)setupDecimator(os);
 const double pulseAttack=1.-std::exp(-1./(fs_*.003));
 const double pulseRelease=1.-std::exp(-1./(fs_*.006));
 const double gainAlpha=1.-std::exp(-1./(fs_*.008));
 for(uint32_t i=0;i<n;i++){
   for(int sub=0;sub<os;sub++){double x=0,y=0;nextInternal(x,y,os);decimPos_=(decimPos_+1)%64;decimHist_[0][decimPos_]=x;decimHist_[1][decimPos_]=y;}
   double x=0,y=0;for(int k=0;k<decimLen_;k++){int idx=(decimPos_-k+64)%64;x+=decimCoeffs_[k]*decimHist_[0][idx];y+=decimCoeffs_[k]*decimHist_[1][idx];}
   processEffects(x,y);
   // CP06: amplitude pulse remains a musical modulation device, never MIDI
   // note generation. Its gate and enable changes get attack/release ramps
   // instead of the old discontinuous end-of-step jump (audible clicks).
   double targetPulse=1.;double depth=0.;
   if(get(6020)>.5){
    const double duration=std::max(.01,get(6021));
    const double t=double(clock_)/fs_;
    const int step=int(std::fmod(std::floor(t/duration),16.));
    const double phase=std::fmod(t,duration)/duration;
    targetPulse=(get(6000+step)>.5&&phase<get(6023)*.01)?1.:0.;
    depth=get(6022)*.01;
   }
   const double targetAmp=1.-depth+depth*targetPulse;
   pulseGain_+=(targetAmp-pulseGain_)*(targetAmp>pulseGain_?pulseAttack:pulseRelease);
   x*=pulseGain_;y*=pulseGain_;
   // 8 ms gain smoothing covers host automation, patch changes and mutations.
   outputGainSmooth_+=(db(get(9000))-outputGainSmooth_)*gainAlpha;
   x*=outputGainSmooth_;y*=outputGainSmooth_;
   if(get(9001)>.5){x=limit(x*.86)*1.05;y=limit(y*.86)*1.05;}
   if(!std::isfinite(x)||!std::isfinite(y))x=y=0;
   l[i]=float(clamp(x,-1,1));r[i]=float(clamp(y,-1,1));clock_++;
 }}
void Synth::process64(double* l,double* r,uint32_t n){std::array<float,256> a{},b{};uint32_t i=0;while(i<n){uint32_t sz=std::min(uint32_t(a.size()),n-i);process(a.data(),b.data(),sz);for(uint32_t k=0;k<sz;k++){l[i+k]=a[k];r[i+k]=b[k];}i+=sz;}}
}
