// Requires the official Steinberg VST3 SDK (not vendored in this source archive).
// The same stable parameter IDs and Synth DSP are shared with the CLAP plugin.
#include "vitriol_dsp.hpp"
#include "public.sdk/source/vst/vstaudioeffect.h"
#include "public.sdk/source/vst/vsteditcontroller.h"
#include "public.sdk/source/main/pluginfactory.h"
#include "pluginterfaces/base/ustring.h"
#include "pluginterfaces/base/ibstream.h"
#include "pluginterfaces/vst/ivstparameterchanges.h"
#include "pluginterfaces/vst/ivstevents.h"
#include <array>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <vector>
#if defined(_WIN32) && defined(VITRIOL_NATIVE_WIN)
#include "editor_native_win.hpp"
#include "public.sdk/source/common/pluginview.h"
#include <windows.h>
#endif

using namespace Steinberg;
using namespace Steinberg::Vst;
namespace vitriol_vst3 {
static const FUID ProcessorUID(0xF379A344,0x0A0E41C9,0xA7B6E0AA,0x1E849920);
static const FUID ControllerUID(0xAE90F8C6,0x6E114C82,0x8C6B9292,0x109974B9);

static double fromNormalized(const vitriol::ParamDef& d,double v) {
 v=std::clamp(v,0.0,1.0);
 bool log=(d.unit=="Hz"&&(d.name=="A Cutoff"||d.name=="B Cutoff"||d.name=="Motion Rate"))||
          (d.unit=="s"&&d.min>0&&d.max/d.min>60);
 double x=log?d.min*std::pow(d.max/d.min,v):d.min+(d.max-d.min)*v;
 return d.stepped?std::round(x):x;
}
static double normalized(const vitriol::ParamDef& d,double v){
 bool log=(d.unit=="Hz"&&(d.name=="A Cutoff"||d.name=="B Cutoff"||d.name=="Motion Rate"))||
          (d.unit=="s"&&d.min>0&&d.max/d.min>60);
 v=std::clamp(v,d.min,d.max);
 return log?std::log(v/d.min)/std::log(d.max/d.min):(v-d.min)/(d.max-d.min);
}
struct TimedEvent {int offset=0,type=0;uint32_t id=0;double value=0;int note=60,chan=0;};
class Processor final:public AudioEffect {
public:
 Processor():engine_(std::make_unique<vitriol::Synth>()), defs_(vitriol::defineParams()) {setControllerClass(ControllerUID);}
 static FUnknown* create(void*){return static_cast<IAudioProcessor*>(new Processor());}
 tresult PLUGIN_API initialize(FUnknown* ctx) override {
  tresult ret=AudioEffect::initialize(ctx);if(ret!=kResultOk)return ret;
  addAudioOutput(STR16("Stereo Output"),SpeakerArr::kStereo);
  addEventInput(STR16("MIDI Notes"),1);return kResultOk;
 }
 tresult PLUGIN_API setBusArrangements(SpeakerArrangement*inputs,int32 inCount,SpeakerArrangement*outputs,int32 outCount)override{
  if(inCount!=0||outCount!=1||outputs[0]!=SpeakerArr::kStereo)return kResultFalse;
  return AudioEffect::setBusArrangements(inputs,inCount,outputs,outCount);
 }
 tresult PLUGIN_API setupProcessing(ProcessSetup& setup) override {engine_->prepare(setup.sampleRate);return AudioEffect::setupProcessing(setup);}
 tresult PLUGIN_API setActive(TBool active) override {if(active)engine_->reset();return AudioEffect::setActive(active);}
 tresult PLUGIN_API process(ProcessData& data) override {
  std::array<TimedEvent,1024> ev{};size_t count=0;
  if(data.inputParameterChanges)for(int32 i=0;i<data.inputParameterChanges->getParameterCount();i++){
   IParamValueQueue* q=data.inputParameterChanges->getParameterData(i);if(!q)continue;
   auto it=std::find_if(defs_.begin(),defs_.end(),[&](const auto& p){return p.id==q->getParameterId();});if(it==defs_.end())continue;
   for(int32 k=0;k<q->getPointCount()&&count<ev.size();k++){
    int32 offset=0;ParamValue val=0;if(q->getPoint(k,offset,val)==kResultOk)
     ev[count++]={std::max(0,offset),0,q->getParameterId(),fromNormalized(*it,val),0,0};
   }
  }
  if(data.inputEvents)for(int32 i=0;i<data.inputEvents->getEventCount()&&count<ev.size();i++){
   Event event{};if(data.inputEvents->getEvent(i,event)!=kResultOk)continue;
   if(event.type==Event::kNoteOnEvent)ev[count++]={event.sampleOffset,1,0,event.noteOn.velocity,event.noteOn.pitch,event.noteOn.channel};
   else if(event.type==Event::kNoteOffEvent)ev[count++]={event.sampleOffset,2,0,0,event.noteOff.pitch,event.noteOff.channel};
  }
  std::sort(ev.begin(),ev.begin()+count,[](const TimedEvent&a,const TimedEvent&b){return a.offset<b.offset;});
  std::array<float,256> L{},R{};size_t cursor=0;int done=0;
  while(done<data.numSamples){while(cursor<count&&ev[cursor].offset<=done){const auto&x=ev[cursor++];if(x.type==0)engine_->setParam(x.id,x.value);else if(x.type==1)engine_->noteOn(x.note,x.value,x.chan);else engine_->noteOff(x.note,x.chan);}
   int limit=std::min<int>(data.numSamples,done+int(L.size()));if(cursor<count)limit=std::min(limit,std::max(done+1,ev[cursor].offset));int n=limit-done;
   engine_->process(L.data(),R.data(),uint32_t(n));
   if(data.numOutputs>0&&data.outputs&&data.outputs[0].numChannels>=2){
    if(data.symbolicSampleSize==kSample64){auto* c0=data.outputs[0].channelBuffers64[0];auto* c1=data.outputs[0].channelBuffers64[1];for(int j=0;j<n;j++){c0[done+j]=L[j];c1[done+j]=R[j];}}
    else{auto*c0=data.outputs[0].channelBuffers32[0];auto*c1=data.outputs[0].channelBuffers32[1];std::copy_n(L.data(),n,c0+done);std::copy_n(R.data(),n,c1+done);}
   }done+=n;
  }
  return kResultOk;
 }
 tresult PLUGIN_API getState(IBStream*stream)override {if(!stream)return kInvalidArgument;
  uint32_t magic=0x5654524c,version=1,count=uint32_t(defs_.size());int32 done=0;
  if(stream->write(&magic,sizeof(magic),&done)!=kResultOk||done!=sizeof(magic))return kResultFalse;
  if(stream->write(&version,sizeof(version),&done)!=kResultOk||done!=sizeof(version))return kResultFalse;
  if(stream->write(&count,sizeof(count),&done)!=kResultOk||done!=sizeof(count))return kResultFalse;
  for(const auto& d:defs_){double v=engine_->getParam(d.id);uint32_t id=d.id;
   if(stream->write(&id,sizeof(id),&done)!=kResultOk||done!=sizeof(id))return kResultFalse;
   if(stream->write(&v,sizeof(v),&done)!=kResultOk||done!=sizeof(v))return kResultFalse;}
  return kResultOk;}
 tresult PLUGIN_API setState(IBStream*stream)override {if(!stream)return kInvalidArgument;
  uint32_t magic=0,version=0,count=0;int32 done=0;
  if(stream->read(&magic,sizeof(magic),&done)!=kResultOk||done!=sizeof(magic)||magic!=0x5654524c)return kResultFalse;
  if(stream->read(&version,sizeof(version),&done)!=kResultOk||done!=sizeof(version)||version!=1)return kResultFalse;
  if(stream->read(&count,sizeof(count),&done)!=kResultOk||done!=sizeof(count)||count>1000)return kResultFalse;
  for(uint32_t i=0;i<count;i++){uint32_t id;double val;
   if(stream->read(&id,sizeof(id),&done)!=kResultOk||done!=sizeof(id))return kResultFalse;
   if(stream->read(&val,sizeof(val),&done)!=kResultOk||done!=sizeof(val))return kResultFalse;
   engine_->setParam(id,val);}
  return kResultOk;}
private:
 std::unique_ptr<vitriol::Synth> engine_;
 std::vector<vitriol::ParamDef> defs_;
};
#if defined(_WIN32) && defined(VITRIOL_NATIVE_WIN)
class NativeView;
#endif
class Controller final:public EditController {
public:
 static FUnknown* create(void*){return static_cast<IEditController*>(new Controller());}
 tresult PLUGIN_API initialize(FUnknown* ctx)override{
  tresult ret=EditController::initialize(ctx);if(ret!=kResultOk)return ret;
  for(const auto& p:vitriol::defineParams()){
   String128 name={},unit={};UString(name,128).fromAscii(p.name.c_str());UString(unit,128).fromAscii(p.unit.c_str());
   auto flags=ParameterInfo::kCanAutomate;
   parameters.addParameter(name,unit,p.stepped?int32(p.max-p.min):0,normalized(p,p.def),flags,p.id);
  }
  return kResultOk;
 }
 tresult PLUGIN_API setComponentState(IBStream*stream)override {
  if(!stream)return kResultFalse;uint32_t magic=0,version=0,count=0;int32 done=0;
  if(stream->read(&magic,sizeof(magic),&done)!=kResultOk||magic!=0x5654524c)return kResultFalse;
  if(stream->read(&version,sizeof(version),&done)!=kResultOk||version!=1)return kResultFalse;
  if(stream->read(&count,sizeof(count),&done)!=kResultOk||count>1000)return kResultFalse;
  const auto defs=vitriol::defineParams();for(uint32_t i=0;i<count;i++){
   uint32_t id=0;double val=0;stream->read(&id,sizeof(id),&done);stream->read(&val,sizeof(val),&done);
   auto it=std::find_if(defs.begin(),defs.end(),[id](auto&d){return d.id==id;});if(it!=defs.end())setParamNormalized(id,normalized(*it,val));
  }return kResultOk;
 }
 IPlugView* PLUGIN_API createView(FIDString name) override;
#if defined(_WIN32) && defined(VITRIOL_NATIVE_WIN)
 tresult PLUGIN_API setParamNormalized(ParamID id,ParamValue value) override;
 void fromGui(uint32_t id,double real){auto defs=vitriol::defineParams();auto it=std::find_if(defs.begin(),defs.end(),[id](const auto&p){return p.id==id;});
  if(it==defs.end())return;
  ParamValue v=normalized(*it,real);performEdit(id,v);setParamNormalized(id,v);
 }
 void beginFromGui(uint32_t id){beginEdit(id);}
 void endFromGui(uint32_t id){endEdit(id);}
 void attachView(NativeView* view){view_=view;}
 std::vector<std::pair<uint32_t,double>> parameterValues() {auto defs=vitriol::defineParams();std::vector<std::pair<uint32_t,double>> r;
  r.reserve(defs.size());for(const auto&d:defs)r.emplace_back(d.id,fromNormalized(d,getParamNormalized(d.id)));return r;}
private:
 NativeView*view_=nullptr;
#endif
};
#if defined(_WIN32) && defined(VITRIOL_NATIVE_WIN)
// Native GDI controls drawn over embedded approved HTML raster; no WebView2/browser.
static void editorModuleAnchor(){}
class NativeView final:public CPluginView {
public:
 explicit NativeView(Controller*c):controller_(c){ViewRect r{0,0,1600,1138};setRect(r);}
 tresult PLUGIN_API isPlatformTypeSupported(FIDString type)override{
  return type&&std::strcmp(type,kPlatformTypeHWND)==0?kResultTrue:kResultFalse;
 }
 tresult PLUGIN_API attached(void*parent,FIDString type)override{
  if(isPlatformTypeSupported(type)!=kResultTrue||!parent)return kResultFalse;
  tresult result=CPluginView::attached(parent,type);if(result!=kResultOk)return result;
  controller_->attachView(this);
  view_=std::make_shared<vitriol::NativeEditor>(
   [this](uint32_t id,double val){if(controller_)controller_->fromGui(id,val);},
   [this](uint32_t id){if(!controller_)return 0.0;
    auto defs=vitriol::defineParams();auto it=std::find_if(defs.begin(),defs.end(),[id](const auto&d){return d.id==id;});
    return it==defs.end()?0.0:fromNormalized(*it,controller_->getParamNormalized(id));},
   [this](uint32_t id){if(controller_)controller_->beginFromGui(id);},
   [this](uint32_t id){if(controller_)controller_->endFromGui(id);});
  auto rect=getRect();
  if(view_->attach(static_cast<HWND>(parent),rect.getWidth(),rect.getHeight()))return kResultOk;
  view_.reset();controller_->attachView(nullptr);CPluginView::removed();return kResultFalse;
 }
 tresult PLUGIN_API removed()override{view_.reset();if(controller_)controller_->attachView(nullptr);return CPluginView::removed();}
 tresult PLUGIN_API onSize(ViewRect*r)override{if(!r)return kInvalidArgument;setRect(*r);if(view_)view_->resize(r->getWidth(),r->getHeight());return kResultTrue;}
 tresult PLUGIN_API canResize()override{return kResultTrue;}
 tresult PLUGIN_API checkSizeConstraint(ViewRect*r)override{if(!r)return kInvalidArgument;
  if(r->getWidth()<800)r->right=r->left+800;if(r->getHeight()<600)r->bottom=r->top+600;return kResultTrue;}
 void update(uint32_t id,double value){if(view_)view_->updateParam(id,value);}
private: Controller*controller_=nullptr;std::shared_ptr<vitriol::NativeEditor>view_;
};
tresult PLUGIN_API Controller::setParamNormalized(ParamID id,ParamValue val){
 tresult r=EditController::setParamNormalized(id,val);
 if(r==kResultOk&&view_){auto defs=vitriol::defineParams();auto it=std::find_if(defs.begin(),defs.end(),[id](const auto&p){return p.id==id;});
  if(it!=defs.end())view_->update(id,fromNormalized(*it,val));}
 return r;
}
#endif
IPlugView* PLUGIN_API Controller::createView(FIDString name){
#if defined(_WIN32) && defined(VITRIOL_NATIVE_WIN)
 if(name&&std::strcmp(name,ViewType::kEditor)==0)return new NativeView(this);
#else
 (void)name;
#endif
 return nullptr;
}

} // namespace vitriol_vst3
BEGIN_FACTORY_DEF("Albedo", "", "")
 DEF_CLASS2(INLINE_UID_FROM_FUID(vitriol_vst3::ProcessorUID),PClassInfo::kManyInstances,kVstAudioEffectClass,
   "Albedo Quintessential Synth",Vst::kDistributable,"Instrument|Synth",FULL_VERSION_STR,kVstVersionString,vitriol_vst3::Processor::create)
 DEF_CLASS2(INLINE_UID_FROM_FUID(vitriol_vst3::ControllerUID),PClassInfo::kManyInstances,kVstComponentControllerClass,
   "Albedo Controller",0,"",FULL_VERSION_STR,kVstVersionString,vitriol_vst3::Controller::create)
END_FACTORY
