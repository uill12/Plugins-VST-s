#include "clap_abi_min.h"
#include "vitriol_dsp.hpp"
#include "vitriol_ui_events.hpp"
#if defined(_WIN32) && defined(VITRIOL_NATIVE_WIN)
#include "editor_native_win.hpp"
#include <windows.h>
#endif
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <cinttypes>
#include <memory>
#include <algorithm>
#include <array>
#include <vector>
#include <string>
#include <atomic>
#include <cmath>

#if defined(_WIN32)
#define CLAP_EXPORT __declspec(dllexport)
#else
#define CLAP_EXPORT __attribute__((visibility("default")))
#endif
extern "C" CLAP_EXPORT const clap_plugin_entry_t clap_entry;
namespace {
struct Instance {clap_plugin_t plugin{};std::unique_ptr<vitriol::Synth> synth;const clap_host_t* host=nullptr;bool active=false;
#if defined(_WIN32) && defined(VITRIOL_NATIVE_WIN)
 std::shared_ptr<vitriol::NativeEditor> editor;
 std::array<std::atomic<double>,10000> uiValue{},hostValue{},mirror{};
 std::array<std::atomic<bool>,10000> uiDirty{},hostDirty{};
 vitriol::UiEventQueue<4096> uiEvents;
 std::atomic<uint32_t> uiQueueOverflow{0};
 uint32_t guiWidth=1600,guiHeight=1138;
#endif
 Instance():synth(std::make_unique<vitriol::Synth>()){
#if defined(_WIN32) && defined(VITRIOL_NATIVE_WIN)
  for(const auto&d:synth->descriptors())if(d.id<10000)mirror[d.id].store(d.def,std::memory_order_relaxed);
#endif
 } };
Instance* get(const clap_plugin_t* p){return static_cast<Instance*>(p->plugin_data);}
const char* features[]={"instrument","synthesizer","stereo",nullptr};
const clap_plugin_descriptor_t description={{1,2,0},"org.vitriol.opussonorum","Albedo Quintessential Synth","Albedo","","","","1.0.0-cp12-horizontal+20261115","Multi-engine experimental hi-fi synthesizer with additive, wavetable, granular and spectral sources",features};
static bool plugin_init(const clap_plugin_t*){return true;}
static void plugin_destroy(const clap_plugin_t*p){delete get(p);}
static bool activate(const clap_plugin_t*p,double sr,uint32_t,uint32_t){auto*x=get(p);x->synth->prepare(sr);x->active=true;return true;}
static void deactivate(const clap_plugin_t*p){get(p)->active=false;}
static bool start(const clap_plugin_t*){return true;}
static void stop(const clap_plugin_t*){}
static void reset(const clap_plugin_t*p){get(p)->synth->reset();}
#if defined(_WIN32) && defined(VITRIOL_NATIVE_WIN)
// GUI gesture/value event ordering follows Rubedo CP09's GUI->audio queue principle.
// The UI never mutates DSP state or reads voices. The host's process/flush consumer
// applies a bounded number of messages without allocating memory or taking locks.
static void requestUiFlush(Instance* x){
 if(!x->host)return;
 auto*hp=x->host->get_extension?static_cast<const clap_host_params_t*>(x->host->get_extension(x->host,CLAP_EXT_PARAMS)):nullptr;
 if(hp&&hp->request_flush)hp->request_flush(x->host);
 else if(x->host->request_process)x->host->request_process(x->host);
}
static void enqueueUi(Instance* x,vitriol::UiEventKind kind,uint32_t id,double val=0){
 if(id>=10000)return;
 if(kind==vitriol::UiEventKind::Value)x->mirror[id].store(val,std::memory_order_release);
 if(!x->uiEvents.push({id,val,kind})){
  x->uiQueueOverflow.fetch_add(1,std::memory_order_relaxed);
  if(kind==vitriol::UiEventKind::Value){
   x->uiValue[id].store(val,std::memory_order_relaxed);
   x->uiDirty[id].store(true,std::memory_order_release);
  }
 }
 requestUiFlush(x);
}
static void outputUiValue(const clap_output_events_t* out,uint32_t id,double val){
 if(!out||!out->try_push)return;
 clap_event_param_value_t event{};
 event.header={uint32_t(sizeof(event)),0,CLAP_CORE_EVENT_SPACE_ID,CLAP_EVENT_PARAM_VALUE,0};
 event.param_id=id;event.value=val;event.note_id=-1;event.port_index=event.channel=event.key=-1;
 out->try_push(out,&event.header);
}
static void applyUiParams(Instance* x,const clap_output_events_t* out){
 vitriol::UiEvent ui;
 for(uint32_t i=0;i<512&&x->uiEvents.pop(ui);i++){
  if(ui.kind==vitriol::UiEventKind::Value){
   x->synth->setParam(ui.param,ui.value);
   outputUiValue(out,ui.param,ui.value);
  }else if(out&&out->try_push){
   struct Gesture {clap_event_header_t header;clap_id param_id;} ev{};
   ev.header={uint32_t(sizeof(ev)),0,CLAP_CORE_EVENT_SPACE_ID,
     uint16_t(ui.kind==vitriol::UiEventKind::GestureBegin?CLAP_EVENT_PARAM_GESTURE_BEGIN:CLAP_EVENT_PARAM_GESTURE_END),0};
   ev.param_id=ui.param;
   out->try_push(out,&ev.header);
  }
 }
 // Defensive latest-value fallback if an unusually long GUI gesture filled
 // the queue. The queue still orders ordinary gestures and values precisely.
 for(const auto& d:x->synth->descriptors()){auto id=d.id;
  if(x->uiDirty[id].exchange(false,std::memory_order_acq_rel)){
   double val=x->uiValue[id].load(std::memory_order_relaxed);
   x->synth->setParam(id,val);outputUiValue(out,id,val);
  }
 }
}
#endif
static void handle(const clap_plugin_t*p,const clap_event_header_t* h){if(!h||h->space_id!=CLAP_CORE_EVENT_SPACE_ID)return;auto& synth=*get(p)->synth;
 if((h->type==CLAP_EVENT_NOTE_ON||h->type==CLAP_EVENT_NOTE_OFF||h->type==CLAP_EVENT_NOTE_CHOKE)&&h->size>=sizeof(clap_event_note_t)){auto* n=reinterpret_cast<const clap_event_note_t*>(h);if(h->type==CLAP_EVENT_NOTE_ON&&n->velocity>0)synth.noteOn(n->key,n->velocity,n->channel);else synth.noteOff(n->key,n->channel);}
 else if(h->type==CLAP_EVENT_PARAM_VALUE&&h->size>=sizeof(clap_event_param_value_t)){auto*v=reinterpret_cast<const clap_event_param_value_t*>(h);synth.setParam(v->param_id,v->value);
#if defined(_WIN32) && defined(VITRIOL_NATIVE_WIN)
 if(v->param_id<10000){auto* x=get(p);x->mirror[v->param_id].store(v->value,std::memory_order_release);x->hostValue[v->param_id].store(v->value,std::memory_order_relaxed);x->hostDirty[v->param_id].store(true,std::memory_order_release);if(x->host&&x->host->request_callback)x->host->request_callback(x->host);}
#endif
 }
 else if(h->type==CLAP_EVENT_MIDI&&h->size>=sizeof(clap_event_midi_t)){auto*m=reinterpret_cast<const clap_event_midi_t*>(h);int st=m->data[0]&0xF0,ch=m->data[0]&15;int a=m->data[1],b=m->data[2];if(st==0x90&&b)synth.noteOn(a,b/127.,ch);else if(st==0x80||(st==0x90&&!b))synth.noteOff(a,ch);else if(st==0xB0)synth.midiCC(a,b);else if(st==0xE0)synth.bend(a+(b<<7));else if(st==0xD0)synth.aftertouch(a/127.);}
}
static int32_t process(const clap_plugin_t*p,const clap_process_t*pr){if(!pr)return CLAP_PROCESS_CONTINUE;auto& synth=*get(p)->synth;
#if defined(_WIN32) && defined(VITRIOL_NATIVE_WIN)
 applyUiParams(get(p),pr->out_events);
#endif
 auto* ev=pr->in_events;uint32_t count=ev&&ev->size?ev->size(ev):0,ei=0;uint32_t done=0;
 auto* output=(pr->audio_outputs_count>0&&pr->audio_outputs)?&pr->audio_outputs[0]:nullptr;
 // A bounded fixed temporary buffer avoids realtime allocation and supports both 32/64-bit host buffers.
 std::array<float,128> l{},r{};
 while(done<pr->frames_count){while(ei<count){auto*h=ev->get?ev->get(ev,ei):nullptr;if(!h){ei++;continue;}if(h->time>done)break;handle(p,h);ei++;}
  uint32_t next=pr->frames_count; if(ei<count){auto*h=ev->get?ev->get(ev,ei):nullptr;if(h)next=std::min(next,std::max(done+1,h->time));}
  uint32_t n=std::min<uint32_t>(128,next-done);if(n==0)n=1;
  synth.process(l.data(),r.data(),n);
  if(output&&output->channel_count>=1){for(uint32_t c=0;c<std::min<uint32_t>(output->channel_count,2);c++){
     const auto& src=c?r:l;
     if(output->data32&&output->data32[c])std::copy_n(src.data(),n,output->data32[c]+done);
     else if(output->data64&&output->data64[c])for(uint32_t i=0;i<n;i++)output->data64[c][done+i]=src[i];
   }}done+=n;
 }
 while(ei<count){auto*h=ev->get?ev->get(ev,ei):nullptr;if(h)handle(p,h);ei++;}
 return CLAP_PROCESS_CONTINUE;}
static uint32_t audio_count(const clap_plugin_t*,bool input){return input?0:1;}
static bool audio_get(const clap_plugin_t*,uint32_t i,bool input,clap_audio_port_info_t* v){if(input||i||!v)return false;std::memset(v,0,sizeof(*v));v->id=0;std::snprintf(v->name,sizeof(v->name),"Stereo Output");v->channel_count=2;v->port_type=CLAP_AUDIO_PORT_STEREO;v->in_place_pair=CLAP_INVALID_ID;return true;}
static const clap_plugin_audio_ports_t audioports={audio_count,audio_get};
static uint32_t note_count(const clap_plugin_t*,bool input){return input?1:0;}
static bool note_get(const clap_plugin_t*,uint32_t i,bool input,clap_note_port_info_t*v){if(!input||i||!v)return false;std::memset(v,0,sizeof(*v));v->id=0;v->supported_dialects=CLAP_NOTE_DIALECT_CLAP|CLAP_NOTE_DIALECT_MIDI;v->preferred_dialect=CLAP_NOTE_DIALECT_CLAP;std::snprintf(v->name,sizeof(v->name),"MIDI / Notes");return true;}
static const clap_plugin_note_ports_t noteports={note_count,note_get};
static uint32_t params_count(const clap_plugin_t*p){return uint32_t(get(p)->synth->descriptors().size());}
static bool params_get(const clap_plugin_t*p,uint32_t i,clap_param_info_t* v){if(!v)return false;const auto& defs=get(p)->synth->descriptors();if(i>=defs.size())return false;auto& def=defs[i];std::memset(v,0,sizeof(*v));v->id=def.id;v->flags=CLAP_PARAM_IS_AUTOMATABLE|(def.stepped?CLAP_PARAM_IS_STEPPED:0);v->min_value=def.min;v->max_value=def.max;v->default_value=def.def;std::snprintf(v->name,sizeof(v->name),"%s",def.name.c_str());std::snprintf(v->module,sizeof(v->module),"%s",def.group.c_str());return true;}
static bool params_value(const clap_plugin_t*p,clap_id id,double* v){if(!v)return false;for(auto& d:get(p)->synth->descriptors())if(d.id==id){
#if defined(_WIN32) && defined(VITRIOL_NATIVE_WIN)
 *v=get(p)->mirror[id].load(std::memory_order_acquire);
#else
 *v=get(p)->synth->getParam(id);
#endif
 return true;}return false;}
static bool params_text(const clap_plugin_t*p,clap_id id,double value,char*buf,uint32_t capacity){if(!buf||!capacity)return false;for(auto& d:get(p)->synth->descriptors())if(d.id==id){std::snprintf(buf,capacity,"%.4g %s",value,d.unit.c_str());return true;}return false;}
static bool params_parse(const clap_plugin_t*p,clap_id id,const char* s,double*value){if(!s||!value)return false;for(auto& d:get(p)->synth->descriptors())if(d.id==id){char* end=nullptr;double x=std::strtod(s,&end);if(end==s)return false;*value=std::clamp(x,d.min,d.max);return true;}return false;}
static void params_flush(const clap_plugin_t*p,const clap_input_events_t*in,const clap_output_events_t*output){
#if defined(_WIN32) && defined(VITRIOL_NATIVE_WIN)
 applyUiParams(get(p),output);
#else
 (void)output;
#endif
 if(!in)return;uint32_t n=in->size(in);for(uint32_t i=0;i<n;i++)handle(p,in->get(in,i));}
static const clap_plugin_params_t params={params_count,params_get,params_value,params_text,params_parse,params_flush};
static bool state_save(const clap_plugin_t*p,const clap_ostream_t*out){if(!out||!out->write)return false;const auto& defs=get(p)->synth->descriptors();std::string data="VITRIOL_CP01 1\n";for(auto& d:defs){char row[80];std::snprintf(row,sizeof(row),"%u %.17g\n",d.id,
#if defined(_WIN32) && defined(VITRIOL_NATIVE_WIN)
 get(p)->mirror[d.id].load(std::memory_order_acquire)
#else
 get(p)->synth->getParam(d.id)
#endif
 );data+=row;}uint64_t offset=0;while(offset<data.size()){int64_t n=out->write(out,data.data()+offset,data.size()-offset);if(n<=0)return false;offset+=uint64_t(n);}return true;}
static bool state_load(const clap_plugin_t*p,const clap_istream_t*in){if(!in||!in->read)return false;std::string data;char chunk[1024];for(;;){int64_t n=in->read(in,chunk,sizeof(chunk));if(n<0||data.size()>500000)return false;if(n==0)break;data.append(chunk,n);}if(data.rfind("VITRIOL_CP01 1\n",0)!=0)return false;
#if defined(_WIN32) && defined(VITRIOL_NATIVE_WIN)
 // State.load is a host-controlled non-processing operation. A queued GUI
 // edit from the previous patch must not overwrite the just-loaded patch.
 get(p)->uiEvents.resetInactive();
 for(const auto&d:get(p)->synth->descriptors())get(p)->uiDirty[d.id].store(false,std::memory_order_relaxed);
#endif
 size_t offset=data.find('\n')+1;while(offset<data.size()){auto stop=data.find('\n',offset);if(stop==std::string::npos)break;unsigned id=0;double v=0;if(std::sscanf(data.c_str()+offset,"%u %lf",&id,&v)==2){get(p)->synth->setParam(id,v);
#if defined(_WIN32) && defined(VITRIOL_NATIVE_WIN)
 if(id<10000)get(p)->mirror[id].store(get(p)->synth->getParam(id),std::memory_order_release);
#endif
 }offset=stop+1;}
#if defined(_WIN32) && defined(VITRIOL_NATIVE_WIN)
 if(get(p)->editor)get(p)->editor->invalidate();
#endif
 return true;}
static const clap_plugin_state_t states={state_save,state_load};
static uint32_t latency(const clap_plugin_t*p){int os=get(p)->synth->oversamplingFactor();return uint32_t(16/os+1);}
static const clap_plugin_latency_t latencies={latency};

#if defined(_WIN32) && defined(VITRIOL_NATIVE_WIN)
static bool gui_api(const clap_plugin_t*,const char*api,bool floating){return !floating&&api&&!std::strcmp(api,"win32");}
static bool gui_prefer(const clap_plugin_t*,const char**api,bool*floating){if(!api||!floating)return false;*api="win32";*floating=false;return true;}
static bool gui_create(const clap_plugin_t*p,const char*api,bool floating){if(!gui_api(p,api,floating))return false;auto*x=get(p);if(!x->editor){x->editor=std::make_shared<vitriol::NativeEditor>(
  [x](uint32_t id,double val){enqueueUi(x,vitriol::UiEventKind::Value,id,val);},
  [x](uint32_t id){return id<10000?x->mirror[id].load(std::memory_order_acquire):0.0;},
  [x](uint32_t id){enqueueUi(x,vitriol::UiEventKind::GestureBegin,id);},
  [x](uint32_t id){enqueueUi(x,vitriol::UiEventKind::GestureEnd,id);}
 );}return true;}
static void gui_destroy(const clap_plugin_t*p){get(p)->editor.reset();}
static bool gui_scale(const clap_plugin_t*,double scale){
 // The bitmap-based native editor does not implement independent CSS-like DPI
 // zoom. Report unsupported non-unit scales so the host can handle scaling.
 return std::isfinite(scale)&&std::abs(scale-1.0)<0.001;
}
static bool gui_size(const clap_plugin_t*p,uint32_t*w,uint32_t*h){if(!w||!h)return false;*w=get(p)->guiWidth;*h=get(p)->guiHeight;return true;}
static bool gui_resizable(const clap_plugin_t*){return true;}
static bool gui_hints(const clap_plugin_t*,clap_gui_resize_hints_t*h){if(!h)return false;h->can_resize_horizontally=true;h->can_resize_vertically=true;h->preserve_aspect_ratio=false;h->aspect_ratio_width=h->aspect_ratio_height=0;return true;}
static bool gui_adjust(const clap_plugin_t*,uint32_t*w,uint32_t*h){if(!w||!h)return false;*w=std::clamp(*w,800u,2500u);*h=std::clamp(*h,600u,1700u);return true;}
static bool gui_set_size(const clap_plugin_t*p,uint32_t w,uint32_t h){auto*x=get(p);x->guiWidth=w;x->guiHeight=h;if(x->editor)x->editor->resize(int(w),int(h));return true;}
static bool gui_parent(const clap_plugin_t*p,const clap_window_t*window){
 if(!window||!window->win32||!gui_api(p,window->api,false))return false;
 auto*x=get(p);if(!x->editor)return false;
 return x->editor->attach(static_cast<HWND>(window->win32),int(x->guiWidth),int(x->guiHeight));
}
static bool gui_transient(const clap_plugin_t*,const clap_window_t*){return false;}
static void gui_title(const clap_plugin_t*,const char*){}
static bool gui_show(const clap_plugin_t*p){auto*e=get(p)->editor.get();if(!e)return false;e->show(true);return true;}
static bool gui_hide(const clap_plugin_t*p){auto*e=get(p)->editor.get();if(!e)return false;e->show(false);return true;}
static const clap_plugin_gui_t gui={gui_api,gui_prefer,gui_create,gui_destroy,gui_scale,gui_size,gui_resizable,gui_hints,gui_adjust,gui_set_size,gui_parent,gui_transient,gui_title,gui_show,gui_hide};
#endif
static const void* ext(const clap_plugin_t*,const char* id){if(!id)return nullptr;if(!std::strcmp(id,CLAP_EXT_AUDIO_PORTS))return &audioports;if(!std::strcmp(id,CLAP_EXT_NOTE_PORTS))return &noteports;if(!std::strcmp(id,CLAP_EXT_PARAMS))return &params;if(!std::strcmp(id,CLAP_EXT_STATE))return &states;if(!std::strcmp(id,CLAP_EXT_LATENCY))return &latencies;
#if defined(_WIN32) && defined(VITRIOL_NATIVE_WIN)
 if(!std::strcmp(id,CLAP_EXT_GUI))return &gui;
#endif
 return nullptr;}
static void on_main_thread(const clap_plugin_t*p){
#if defined(_WIN32) && defined(VITRIOL_NATIVE_WIN)
 auto*x=get(p);if(!x->editor)return;
 for(const auto& d:x->synth->descriptors())if(x->hostDirty[d.id].exchange(false,std::memory_order_acq_rel)){
  x->editor->updateParam(d.id,x->hostValue[d.id].load(std::memory_order_relaxed));
 }
#else
 (void)p;
#endif
}
static uint32_t factory_count(const clap_plugin_factory_t*){return 1;}
static const clap_plugin_descriptor_t* factory_desc(const clap_plugin_factory_t*,uint32_t i){return i==0?&description:nullptr;}
static const clap_plugin_t* factory_create(const clap_plugin_factory_t*,const clap_host_t* host,const char* id){if(!id||std::strcmp(id,description.id))return nullptr;auto*x=new Instance;x->host=host;x->plugin={&description,x,plugin_init,plugin_destroy,activate,deactivate,start,stop,reset,process,ext,on_main_thread};return &x->plugin;}
static const clap_plugin_factory_t factory={factory_count,factory_desc,factory_create};
static bool entry_init(const char*){return true;}static void entry_deinit(){}
static const void* entry_factory(const char*id){return id&&!std::strcmp(id,CLAP_PLUGIN_FACTORY_ID)?&factory:nullptr;}
}
extern "C" CLAP_EXPORT const clap_plugin_entry_t clap_entry={{1,2,0},entry_init,entry_deinit,entry_factory};
