#include "albedo_factory_patches.hpp"
#include "albedo_gui_semantics.hpp"
#include "albedo_waveform_visuals.hpp"
#if defined(_WIN32)
#include "editor_native_win.hpp"
#include <windowsx.h>
#include <cmath>
#include <cstdio>
#include <algorithm>
#include <utility>
#include <initializer_list>
#include <string>
#include <sstream>
#include <commdlg.h>
#include <fstream>
#include <filesystem>
#include <iomanip>
#include <random>
namespace vitriol {
namespace {
constexpr wchar_t kClassName[]=L"Albedo.Quintessential.NativeEditor.CP09";
constexpr COLORREF ink=RGB(43,62,55),sea=RGB(77,116,107),gold=RGB(180,139,83),paper=RGB(236,237,225);
std::wstring wide(const std::string& s){int n=MultiByteToWideChar(CP_UTF8,0,s.data(),int(s.size()),nullptr,0);if(n<1)return L"";std::wstring w(size_t(n),L' ');MultiByteToWideChar(CP_UTF8,0,s.data(),int(s.size()),w.data(),n);return w;}
void fill(HDC dc,int x,int y,int w,int h,COLORREF color){RECT r{x,y,x+w,y+h};HBRUSH b=CreateSolidBrush(color);FillRect(dc,&r,b);DeleteObject(b);}
void frame(HDC dc,int x,int y,int w,int h,COLORREF color,int thickness=2){HPEN p=CreatePen(PS_SOLID,thickness,color);auto old=SelectObject(dc,p);auto br=SelectObject(dc,GetStockObject(HOLLOW_BRUSH));Rectangle(dc,x,y,x+w,y+h);SelectObject(dc,br);SelectObject(dc,old);DeleteObject(p);}
void circ(HDC dc,int x,int y,int r,COLORREF color,COLORREF outline){HBRUSH b=CreateSolidBrush(color);HPEN p=CreatePen(PS_SOLID,2,outline);auto ob=SelectObject(dc,b);auto op=SelectObject(dc,p);Ellipse(dc,x-r,y-r,x+r,y+r);SelectObject(dc,op);SelectObject(dc,ob);DeleteObject(p);DeleteObject(b);}
// RGNES CP10: a font is constructed once per editor and font size/weight,
// not once per label and repaint. Nested paints restore their prior cache.
thread_local std::map<int,HFONT>* gCurrentFontCache=nullptr;
struct FontCacheScope {
 std::map<int,HFONT>* previous;
 explicit FontCacheScope(std::map<int,HFONT>& cache):previous(gCurrentFontCache){gCurrentFontCache=&cache;}
 ~FontCacheScope(){gCurrentFontCache=previous;}
};
void text(HDC dc,int x,int y,int w,int h,const std::wstring& t,int pts=13,COLORREF color=ink,bool bold=false,int flags=DT_CENTER|DT_SINGLELINE|DT_VCENTER){
 const int key=pts*2+(bold?1:0);
 HFONT font=nullptr;
 bool temporary=false;
 if(gCurrentFontCache){
  auto& cached=(*gCurrentFontCache)[key];
  if(!cached)cached=CreateFontW(-pts,0,0,0,bold?FW_BOLD:FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH|FF_SWISS,L"Segoe UI");
  font=cached;
 }else{
  font=CreateFontW(-pts,0,0,0,bold?FW_BOLD:FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH|FF_SWISS,L"Segoe UI");
  temporary=true;
 }
 if(!font)return;
 const auto old=SelectObject(dc,font);
 SetTextColor(dc,color);SetBkMode(dc,TRANSPARENT);
 RECT rect{x,y,x+w,y+h};DrawTextW(dc,t.c_str(),int(t.size()),&rect,flags|DT_END_ELLIPSIS);
 SelectObject(dc,old);
 if(temporary)DeleteObject(font);
}
void line(HDC dc,int x1,int y1,int x2,int y2,COLORREF c,int width=2){HPEN p=CreatePen(PS_SOLID,width,c);auto old=SelectObject(dc,p);MoveToEx(dc,x1,y1,nullptr);LineTo(dc,x2,y2);SelectObject(dc,old);DeleteObject(p);}
std::wstring controlName(const NativeControl&c,double val){
 if(c.id>=1000&&c.id<1128&&((c.id-1000)%32)==0){int n=std::clamp(int(std::round(val)),0,9);return wide(kMethods[n]);}
 if(c.id==3000||c.id==3003||c.id==3001||c.id==3004)return L"";
 if(c.sourceRelative&&c.id==1010){return wide(kMaterialNames[std::clamp(int(std::round(val)),0,31)]);}
 if(c.sourceRelative&&c.id==1011){return std::to_wstring(std::clamp(int(std::round(val)),1,8))+L" VOICES";}
 if(c.sourceRelative&&c.id==1015){const wchar_t* n[]={L"HANN",L"SINE",L"TRAPEZOID",L"GAUSSIAN"};return n[std::clamp(int(std::round(val)),0,3)];}
 if(c.id==4011||c.id==4012){const wchar_t* n[]={L"SINE",L"TRIANGLE",L"RAMP",L"SQUARE",L"COMPLEX"};return n[std::clamp(int(std::round(val)),0,4)];}
 if(c.id==3010||c.id==3011){const wchar_t *s[]={L"SVF Morph",L"Ladder",L"Comb",L"Bandpass",L"Notch"};return s[std::clamp(int(std::round(val)),0,4)];}
 if(c.id==3012){const wchar_t*s[]={L"PARALLEL",L"SERIAL A-B",L"SERIAL B-A"};return s[std::clamp(int(std::round(val)),0,2)];}
 if(c.id==3110){const wchar_t*s[]={L"LOCK",L"EXPERIMENTAL",L"LEGATO"};return s[std::clamp(int(std::round(val)),0,2)];}
 if(c.id==3111){const wchar_t*s[]={L"POLY",L"MONO",L"LEGATO",L"UNISON"};return s[std::clamp(int(std::round(val)),0,3)];}
 if(c.id==3112){const wchar_t*s[]={L"12-TET",L"JUST",L"PYTHAGOREAN",L"19-TET",L"24-TET"};return s[std::clamp(int(std::round(val)),0,4)];}
 if(c.id==4003){const wchar_t*s[]={L"RULE 30",L"RULE 90",L"RULE 110",L"RULE 150"};return s[std::clamp(int(std::round(val)),0,3)];}
 if(c.id==9002){const wchar_t*s[]={L"AUTO",L"1X",L"2X",L"4X",L"8X"};return s[std::clamp(int(std::round(val)),0,4)];}
 if(c.id>=8000&&c.id<8024){int n=int((c.id-8000)%3);int idx=std::clamp(int(std::round(val)),0,11);if(n==0)return wide(kSources[idx]);if(n==1)return wide(kTargets[idx]);}
 wchar_t out[70];swprintf(out,70,L"%.3g",val);return out;
}
} // namespace
NativeEditor::NativeEditor(WriteFn onChange,ReadFn read,GestureFn onBegin,GestureFn onEnd):controls_(makeNativeControls()),labControls_(makeLabControls()),parameters_(defineParams()),write_(std::move(onChange)),read_(std::move(read)),begin_(std::move(onBegin)),end_(std::move(onEnd)){}
NativeEditor::~NativeEditor(){detach();}
bool NativeEditor::attach(HWND parent,int width,int height){
 if(!parent)return false;detach();
 HMODULE mod=nullptr;GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,reinterpret_cast<LPCWSTR>(&NativeEditor::wndproc),&mod);
 module_=mod;
 WNDCLASSEXW wc{};wc.cbSize=sizeof(wc);wc.lpfnWndProc=&NativeEditor::wndproc;wc.hInstance=mod;wc.lpszClassName=kClassName;wc.hCursor=LoadCursor(nullptr,IDC_ARROW);wc.style=CS_DBLCLKS;
 if(!RegisterClassExW(&wc)&&GetLastError()!=ERROR_CLASS_ALREADY_EXISTS)return false;
 width_=std::max(width,900);height_=std::max(height,620);
 // Rubedo CP08R2: pass stable editor pointer through CREATESTRUCT.lpCreateParams at offset zero.
 HWND child=CreateWindowExW(0,kClassName,L"Albedo Quintessential Synth",WS_CHILD|WS_VISIBLE|WS_CLIPSIBLINGS|WS_CLIPCHILDREN,0,0,width_,height_,parent,nullptr,mod,this);
 if(!child)return false;
 hwnd_=child;dirty_.clear();artwork_=(HBITMAP)LoadImageW(mod,MAKEINTRESOURCEW(101),IMAGE_BITMAP,0,0,LR_CREATEDIBSECTION);
 artworkDark_=(HBITMAP)LoadImageW(mod,MAKEINTRESOURCEW(103),IMAGE_BITMAP,0,0,LR_CREATEDIBSECTION);
 invalidate();return true;
}
void NativeEditor::detach(){endGesture();HWND w=hwnd_;hwnd_=nullptr;if(w)DestroyWindow(w);
 if(backingDC_){SelectObject(backingDC_,backingOriginal_);DeleteObject(backingBitmap_);DeleteDC(backingDC_);backingDC_=nullptr;backingBitmap_=nullptr;backingOriginal_=nullptr;}
 if(artwork_){DeleteObject(artwork_);artwork_=nullptr;}
 if(artworkDark_){DeleteObject(artworkDark_);artworkDark_=nullptr;}
 for(auto& item:fontCache_)if(item.second)DeleteObject(item.second);
 fontCache_.clear();}
void NativeEditor::resize(int w,int h){width_=std::max(320,w);height_=std::max(300,h);if(hwnd_)SetWindowPos(hwnd_,nullptr,0,0,width_,height_,SWP_NOMOVE|SWP_NOZORDER|SWP_NOACTIVATE);invalidate();}
void NativeEditor::show(bool visible){if(hwnd_)ShowWindow(hwnd_,visible?SW_SHOW:SW_HIDE);}
void NativeEditor::invalidate(){if(hwnd_)InvalidateRect(hwnd_,nullptr,FALSE);}
void NativeEditor::updateParam(uint32_t id,double paramValue){
 // Only called on the GUI thread (CLAP on_main_thread / VST3 controller).
 // Don't recompose the full 1920px editor for subpixel automation jitter.
 auto it=std::find_if(parameters_.begin(),parameters_.end(),[id](const ParamDef&p){return p.id==id;});
 if(it!=parameters_.end()&&dirty_.observe(id,paramValue,it->stepped,it->min,it->max))invalidate();
}
void NativeEditor::beginGesture(uint32_t primary,bool xy){
 endGesture();
 if(primary==UINT32_MAX)return;
 gesturePrimary_=primary;gestureXY_=xy;
 if(begin_){begin_(primary);if(xy)begin_(2101);}
}
void NativeEditor::endGesture(){
 if(gesturePrimary_==UINT32_MAX)return;
 if(end_){end_(gesturePrimary_);if(gestureXY_)end_(2101);}
 gesturePrimary_=UINT32_MAX;gestureXY_=false;
}

void NativeEditor::geometry(int&sx,int&sy,int&ox,int&oy)const{
 double f=std::min(double(width_)/kArtWidth,double(height_)/kArtHeight);
 sx=std::max(1,int(std::lround(kArtWidth*f)));sy=std::max(1,int(std::lround(kArtHeight*f)));
 ox=(width_-sx)/2;oy=(height_-sy)/2;
}
int NativeEditor::ix(int x)const{int sx,sy,ox,oy;geometry(sx,sy,ox,oy);return int(std::floor((x-ox)*double(kArtWidth)/sx));}
int NativeEditor::iy(int y)const{int sx,sy,ox,oy;geometry(sx,sy,ox,oy);return int(std::floor((y-oy)*double(kArtHeight)/sy));}
uint32_t NativeEditor::resolve(const NativeControl&c)const{return resolvedParam(c,selected_);}
double NativeEditor::value(uint32_t id)const{return read_?read_(id):0.0;}
void NativeEditor::change(uint32_t id,double v){auto it=std::find_if(parameters_.begin(),parameters_.end(),[id](const ParamDef&p){return p.id==id;});if(it==parameters_.end())return;
 double clamped=std::clamp(v,it->min,it->max);if(it->stepped)clamped=std::round(clamped);
 if(write_)write_(id,clamped);if(!applyingFactory_)selectedPreset_=-1;invalidate();}
void NativeEditor::modify(uint32_t id,double delta){auto it=std::find_if(parameters_.begin(),parameters_.end(),[id](const ParamDef&p){return p.id==id;});if(it==parameters_.end())return;
 double old=value(id),span=it->max-it->min,step=it->stepped?1.0:span*delta;
 if(it->stepped)step=std::abs(delta)>=1.0?std::round(delta):(delta>=0.0?1.0:-1.0);
 if(!std::isfinite(step)||step==0.0)return;
 change(id,old+step);
}
void NativeEditor::edit(const NativeControl&c,int x,int y,int delta,bool coarse){
 if(c.kind==ControlKind::Source){selected_=int(c.id-0xFFF00000u);invalidate();return;}
 uint32_t id=resolve(c);
 auto it=std::find_if(parameters_.begin(),parameters_.end(),[id](const ParamDef&p){return p.id==id;});if(it==parameters_.end())return;
 const double span=it->max-it->min;
 if(c.kind==ControlKind::Toggle||c.kind==ControlKind::Step){change(id,value(id)>.5?0:1);return;}
 if(c.kind==ControlKind::Choice){modify(id,delta<0?-1.0:1.0);return;}
 if(c.kind==ControlKind::XY){
  change(2100,std::clamp((x-c.x)*100.0/std::max(1,c.w),0.0,100.0));
  change(2101,std::clamp((y-c.y)*100.0/std::max(1,c.h),0.0,100.0));return;
 }
 if(c.kind==ControlKind::Slider){double n=std::clamp((x-c.x)*1.0/std::max(1,c.w),0.0,1.0);change(id,it->min+span*n);return;}
 if(c.kind==ControlKind::Dial){double scale=coarse?0.00045:0.002;change(id,startValue_+(startY_-y)*span*scale+(x-startX_)*span*scale*0.15);return;}
}
void NativeEditor::drawControl(HDC dc,const NativeControl&c,bool highlighted){
 if(c.kind==ControlKind::Source){
  int source=std::clamp(int(c.id-0xFFF00000u),0,3);
  const int m=std::clamp(int(std::round(value(1000+source*32))),0,9);
  const bool on=value(1001+source*32)>.5;
  // Rubedo-style dynamic overlays mask stale text from the approved raster backdrop.
  fill(dc,c.x+43,c.y+24,std::min(200,c.w-100),24,dark_?RGB(53,72,65):(on?RGB(237,240,227):RGB(212,216,208)));
  text(dc,c.x+48,c.y+24,std::min(190,c.w-104),23,wide(kMethods[m]),15,dark_?paper:(on?ink:RGB(126,132,126)),true,DT_LEFT|DT_VCENTER);
  fill(dc,c.x+c.w-42,c.y+c.h-31,36,19,dark_?RGB(53,72,65):RGB(232,235,221));
  wchar_t pct[16];swprintf(pct,16,L"%.0f%%",value(1002+source*32));
  text(dc,c.x+c.w-42,c.y+c.h-31,36,18,pct,11,dark_?paper:sea,true);
  if(selected_==source)frame(dc,c.x,c.y,c.w,c.h,gold,3);
  return;
 }
 if(c.id==0xffe00007u){
  fill(dc,c.x,c.y,c.w,c.h,dark_?RGB(53,72,65):RGB(242,238,224));frame(dc,c.x,c.y,c.w,c.h,RGB(132,151,134),1);
  text(dc,c.x+6,c.y,c.w-21,c.h,(selectedPreset_>=0&&selectedPreset_<int(albedo_factory::patches.size()))?albedo_factory::patches[selectedPreset_].name:L"UNSAVED / MODIFIED",13,dark_?paper:ink,false,DT_LEFT|DT_VCENTER);
  text(dc,c.x+c.w-18,c.y,14,c.h,L"⌄",15,dark_?gold:sea);return;
 }
 if(c.kind==ControlKind::Button){
  if(c.id==6020u){fill(dc,c.x,c.y,c.w,c.h,value(6020)>.5?RGB(79,119,101):RGB(227,229,217));frame(dc,c.x,c.y,c.w,c.h,gold,1);
   text(dc,c.x,c.y,c.w,c.h,value(6020)>.5?L"PULSE ON":L"PULSE OFF",11,ink,true);}
  return;
 }
 uint32_t id=resolve(c);double v=value(id);
 auto it=std::find_if(parameters_.begin(),parameters_.end(),[id](const ParamDef&p){return p.id==id;});if(it==parameters_.end())return;
 double n=(v-it->min)/std::max(1e-9,it->max-it->min);n=std::clamp(n,0.0,1.0);
 if(c.kind==ControlKind::Dial){
  const char* label=c.label;
  if(c.sourceRelative&&c.id>=1006&&c.id<=1009){

   int method=std::clamp(int(std::round(value(1000+selected_*32))),0,9);
   label=kMethodCharacterLabels[method][int(c.id-1006)];
  }
  const bool compact=c.w<75;
  int cx=c.x+c.w/2,cy=c.y+(compact?c.h/2:26),r=compact?std::max(8,c.w/2-6):std::min(26,c.w/2-5);
  fill(dc,c.x+1,c.y+1,c.w-2,c.h-2,dark_?RGB(49,62,59):RGB(230,233,221));
  circ(dc,cx,cy,r,dark_?RGB(83,103,91):RGB(212,222,205),gold);
  circ(dc,cx,cy,r-4,dark_?RGB(58,78,72):RGB(235,234,216),sea);
  double a=(140.0+n*260.0)*3.141592653589793/180.0;
  line(dc,cx,cy,cx+int(std::cos(a)*r*.72),cy+int(std::sin(a)*r*.72),ink,3);
  wchar_t buf[50];swprintf(buf,50,L"%.3g",v);
  if(compact){
   // These label/value regions are dynamic HTML slots, not extra native click targets.
   int labelWidth=std::max(73,c.w+33);int lx=c.x+(c.w-labelWidth)/2;
   fill(dc,lx,c.y+c.h+2,labelWidth,29,dark_?RGB(49,62,59):RGB(231,234,221));
   text(dc,lx,c.y+c.h+2,labelWidth,14,wide(label),9,dark_?paper:ink,true);
   text(dc,lx,c.y+c.h+15,labelWidth,14,buf,11,dark_?paper:ink);
  }else{
   text(dc,c.x,c.y+50,c.w,15,wide(label),10,dark_?paper:ink,true);
   text(dc,c.x,c.y+65,c.w,16,buf,12,dark_?paper:ink);
  }
  if(highlighted)frame(dc,c.x,c.y,c.w,c.h,gold,1);return;
 }
 if(c.kind==ControlKind::Slider){
  fill(dc,c.x,c.y,c.w,c.h,dark_?RGB(62,81,75):RGB(232,234,220));int yy=c.y+c.h/2;
  line(dc,c.x+7,yy,c.x+c.w-8,yy,RGB(166,174,156),5);
  line(dc,c.x+7,yy,c.x+7+int((c.w-15)*n),yy,RGB(119,163,151),5);
  circ(dc,c.x+7+int((c.w-15)*n),yy,9,RGB(165,117,93),RGB(113,88,69));
  if(highlighted)frame(dc,c.x,c.y,c.w,c.h,gold,1);return;
 }
 if(c.kind==ControlKind::Choice){
  fill(dc,c.x,c.y,c.w,c.h,dark_?RGB(63,80,75):RGB(238,238,221));frame(dc,c.x,c.y,c.w,c.h,highlighted?gold:RGB(150,158,143),1);
  text(dc,c.x+3,c.y+1,c.w-17,c.h-2,controlName(c,v),c.w<105?11:12,dark_?paper:ink,false,DT_LEFT|DT_SINGLELINE|DT_VCENTER);text(dc,c.x+c.w-16,c.y,15,c.h,L"⌄",15,dark_?gold:sea);return;
 }
 if(c.kind==ControlKind::Toggle||c.kind==ControlKind::Step){
  COLORREF color=n>.5?sea:RGB(183,189,178);fill(dc,c.x,c.y,c.w,c.h,color);
  frame(dc,c.x,c.y,c.w,c.h,highlighted?gold:RGB(117,140,124),1);
  if(c.kind==ControlKind::Toggle)text(dc,c.x,c.y,c.w,c.h,n>.5?L"ON":L"OFF",std::min(12,c.h-6),RGB(254,250,226),true);
  return;
 }
 if(c.kind==ControlKind::XY){
  int px=c.x+int(c.w*std::clamp(value(2100)/100.0,0.0,1.0));int py=c.y+int(c.h*std::clamp(value(2101)/100.0,0.0,1.0));
  circ(dc,px,py,10,RGB(198,105,80),RGB(82,58,48));
  if(highlighted)frame(dc,c.x,c.y,c.w,c.h,gold,1);return;
 }
}
void NativeEditor::drawLab(HDC dc){
 const int x=126,y=108,w=1668,h=1136;
 fill(dc,x,y,w,h,dark_?RGB(35,52,49):RGB(228,231,217));frame(dc,x,y,w,h,RGB(67,97,88),4);
 fill(dc,x+3,y+3,w-6,93,RGB(45,72,67));
 text(dc,x+30,y+10,w-60,42,L"ALBEDO · SYNTHESIS LAB",32,RGB(244,231,192),true,DT_LEFT|DT_VCENTER);
 text(dc,x+30,y+58,w-70,25,L"MATERIAL / MORPHOLOGY / MODULATION   ·   F3 to return",15,RGB(217,226,209),false,DT_LEFT|DT_VCENTER);
 text(dc,x+35,183,w-70,25,L"SOURCE CHAMBERS  ·  SELECT ENGINE",15,sea,true,DT_LEFT|DT_VCENTER);
 for(int i=0;i<4;i++){
  const auto &tab=labControls_[i];bool selected=i==selected_;
  fill(dc,tab.x,tab.y,tab.w,tab.h,selected?RGB(101,139,121):RGB(205,214,193));
  frame(dc,tab.x,tab.y,tab.w,tab.h,selected?gold:sea,selected?3:1);
  text(dc,tab.x+12,tab.y+2,tab.w-24,tab.h-4,wide(std::string("SOURCE ")+char('A'+i)+" / "+tab.label),19,selected?RGB(251,246,228):ink,true);
 }
 text(dc,x+36,275,w-70,26,L"I.  OSCILLATOR / PARTICLE / RESONANT MATERIAL",16,sea,true,DT_LEFT|DT_VCENTER);
 line(dc,x+35,597,x+w-35,597,RGB(155,173,153),2);
 text(dc,x+36,664,w-70,26,L"II. FILTER ENVELOPE   ·   VOICE   ·   TWO LFOS   ·   SPACE",16,sea,true,DT_LEFT|DT_VCENTER);
 for(size_t i=4;i<labControls_.size();++i){
  const auto &c=labControls_[i];
  if(c.kind==ControlKind::Choice)text(dc,c.x,c.y-18,c.w,15,wide(c.label),11,ink,true);
  drawControl(dc,c,hover_==int(i)+65536);
 }
 line(dc,x+35,1108,x+w-35,1108,RGB(155,173,153),2);
 text(dc,x+34,1111,w-64,28,L"32 ORIGINAL MATERIALS  ·  PCM24 96kHz  ·  DRY MONO  ·  CHOOSE MATERIAL PER ENGINE  ·  PARAMS STORED IN HOST",14,ink,true,DT_LEFT|DT_VCENTER);
 text(dc,x+35,1145,w-70,22,L"Click a selector to open the full list • wheel to adjust • Shift+drag for fine control • F2 opens complete parameter atlas",13,sea);
}
void NativeEditor::drawInspector(HDC dc){
 const int x=240,y=124,w=1440,h=1130;
 fill(dc,x,y,w,h,dark_?RGB(35,52,49):RGB(231,234,219));frame(dc,x,y,w,h,RGB(87,120,112),4);
 fill(dc,x+3,y+3,w-6,65,RGB(61,91,84));
 text(dc,x+18,y+9,w-50,45,L"PARAMETER ATLAS · NATIVE EDITOR",25,RGB(241,232,201),true,DT_LEFT|DT_VCENTER|DT_SINGLELINE);
 text(dc,x+14,y+71,w-28,40,L"Click a row to select; drag horizontally or use ← / →. Mouse wheel scrolls. Press F2 to close.",14,ink);
 int count=int(parameters_.size());inspectorOffset_=std::clamp(inspectorOffset_,0,std::max(0,count-17));
 for(int row=0;row<17;row++){
  int i=inspectorOffset_+row;if(i>=count)break;const auto &p=parameters_[i];int yy=y+117+row*54;
  if(i==inspectorSelected_)fill(dc,x+9,yy-2,w-18,52,dark_?RGB(65,88,78):RGB(202,217,193));
  text(dc,x+20,yy,60,40,std::to_wstring(p.id),14,(dark_?RGB(182,207,193):sea),true,DT_LEFT|DT_VCENTER);
  text(dc,x+80,yy,450,40,wide(p.name),15,(dark_?paper:ink),true,DT_LEFT|DT_VCENTER);
  text(dc,x+555,yy,350,40,wide(p.group),11,(dark_?RGB(174,192,174):RGB(94,107,94)),false,DT_LEFT|DT_VCENTER);
  double n=std::clamp((value(p.id)-p.min)/std::max(1e-9,p.max-p.min),0.0,1.0);
  fill(dc,x+955,yy+14,260,12,RGB(181,195,177));fill(dc,x+955,yy+14,int(260*n),12,RGB(92,147,131));
  wchar_t val[64];swprintf(val,64,L"%.3g",value(p.id));text(dc,x+1240,yy,150,38,val,15,(dark_?paper:ink),true);
  line(dc,x+12,yy+48,x+w-12,yy+48,RGB(192,200,184),1);
 }
 text(dc,x+22,y+h-62,w-40,29,L"All exposed CLAP/VST3 parameters can be adjusted here, including secondary routes and quality controls.",14,ink,false,DT_LEFT|DT_VCENTER);
 text(dc,x+20,y+h-32,w-40,25,L"Albedo Quintessential Synth · native GDI · no WebView2",12,sea,false);
}

// CP05: native patch archive independent of WebView2. Host state saving also remains available.
void NativeEditor::exportPatch(){
 wchar_t path[MAX_PATH]=L"Albedo_Quintessential_Synth.albp";
 OPENFILENAMEW dialog{};dialog.lStructSize=sizeof(dialog);dialog.hwndOwner=hwnd_;
 dialog.lpstrFile=path;dialog.nMaxFile=MAX_PATH;
 dialog.lpstrFilter=L"Albedo Patch (*.albp)\0*.albp\0Legacy Patch (*.vtrp)\0*.vtrp\0All Files (*.*)\0*.*\0";
 dialog.lpstrDefExt=L"albp";dialog.Flags=OFN_OVERWRITEPROMPT|OFN_PATHMUSTEXIST;
 if(!GetSaveFileNameW(&dialog))return;
 std::ofstream out(std::filesystem::path(path),std::ios::binary);
 if(!out){MessageBoxW(hwnd_,L"Unable to write patch file.",L"Albedo",MB_ICONWARNING);return;}
 out<<"ALBEDO_NATIVE_PATCH 1\n";
 for(const auto& par:parameters_)out<<par.id<<' '<<std::setprecision(17)<<value(par.id)<<'\n';
 if(!out.good())MessageBoxW(hwnd_,L"Patch write failed.",L"Albedo",MB_ICONWARNING);
}
void NativeEditor::importPatch(){
 wchar_t path[MAX_PATH]{};
 OPENFILENAMEW dialog{};dialog.lStructSize=sizeof(dialog);dialog.hwndOwner=hwnd_;
 dialog.lpstrFile=path;dialog.nMaxFile=MAX_PATH;
 dialog.lpstrFilter=L"Albedo Patch (*.albp)\0*.albp\0Legacy Patch (*.vtrp)\0*.vtrp\0All Files (*.*)\0*.*\0";
 dialog.Flags=OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST;
 if(!GetOpenFileNameW(&dialog))return;
 std::ifstream in(std::filesystem::path(path),std::ios::binary);
 std::string magic;int version=0;
 if(!(in>>magic>>version)||(magic!="VITRIOL_NATIVE_PATCH"&&magic!="ALBEDO_NATIVE_PATCH")||version!=1){
  MessageBoxW(hwnd_,L"Expected ALBEDO or legacy VITRIOL native patch v1 (HTML JSON is not supported).",L"Albedo",MB_ICONWARNING);return;}
 std::vector<std::pair<uint32_t,double>> next;
 uint32_t id=0;double v=0;
 while(in>>id>>v){
  if(!std::isfinite(v))continue;
  auto it=std::find_if(parameters_.begin(),parameters_.end(),[id](const ParamDef&p){return p.id==id;});
  if(it!=parameters_.end())next.emplace_back(id,v);
 }
 if(next.empty()){MessageBoxW(hwnd_,L"Patch contains no valid parameters.",L"Albedo",MB_ICONWARNING);return;}
 for(const auto &[param,val]:next){beginGesture(param);change(param,val);endGesture();}
 selectedPreset_=-1;invalidate();
}
void NativeEditor::mutatePatch(){
 std::mt19937 rng{static_cast<uint32_t>(GetTickCount64())};std::uniform_real_distribution<double> u(0.,1.);
 for(int e=0;e<4;e++){
  uint32_t base=1000+32u*uint32_t(e);
  beginGesture(base);change(base,std::floor(u(rng)*10.));endGesture();
  for(uint32_t i=6;i<10;i++){beginGesture(base+i);change(base+i,u(rng)*100.);endGesture();}
 }
 for(uint32_t i=0;i<7;i++){beginGesture(2000+i);change(2000+i,u(rng)*100.);endGesture();}
 selectedPreset_=-1;invalidate();
}

void NativeEditor::openChoiceMenu(const NativeControl&c){
 const uint32_t id=resolve(c);
 auto it=std::find_if(parameters_.begin(),parameters_.end(),[id](const ParamDef&p){return p.id==id;});
 if(it==parameters_.end())return;
 using Option=std::pair<std::wstring,double>;
 std::vector<Option> items;
 auto add=[&](const wchar_t*label,double v){items.emplace_back(label,v);};
 auto names=[&](const char* const*strings,int n){for(int i=0;i<n;i++)items.emplace_back(wide(strings[i]),double(i));};
 if(id>=1000&&id<1128&&((id-1000)%32)==0)names(kMethods,10);
 else if(id>=1000&&id<1128&&((id-1000)%32)==10)names(kMaterialNames,32);
 else if(id>=1000&&id<1128&&((id-1000)%32)==11)for(int i=1;i<=8;i++)items.emplace_back(std::to_wstring(i)+L" VOICES",double(i));
 else if(id>=1000&&id<1128&&((id-1000)%32)==15){for(auto*n:{L"HANN",L"SINE",L"TRAPEZOID",L"GAUSSIAN"})add(n,items.size());}
 else if(id==3010||id==3011){for(auto*n:{L"SVF MORPH",L"LADDER",L"COMB",L"BANDPASS",L"NOTCH"})add(n,items.size());}
 else if(id==3012){for(auto*n:{L"PARALLEL",L"SERIAL A → B",L"SERIAL B → A"})add(n,items.size());}
 else if(id==3110){for(auto*n:{L"LOCK",L"EXPERIMENTAL",L"LEGATO"})add(n,items.size());}
 else if(id==3111){for(auto*n:{L"POLY",L"MONO",L"LEGATO",L"UNISON"})add(n,items.size());}
 else if(id==3112){for(auto*n:{L"12-TET",L"JUST",L"PYTHAGOREAN",L"19-TET",L"24-TET"})add(n,items.size());}
 else if(id==4003){for(auto*n:{L"RULE 30",L"RULE 90",L"RULE 110",L"RULE 150"})add(n,items.size());}
 else if(id==4011||id==4012){for(auto*n:{L"SINE",L"TRIANGLE",L"RAMP",L"SQUARE",L"COMPLEX"})add(n,items.size());}
 else if(id==9002){for(auto*n:{L"AUTO",L"1×",L"2×",L"4×",L"8×"})add(n,items.size());}
 else if(id>=8000&&id<8024&&((id-8000)%3)==0)names(kSources,12);
 else if(id>=8000&&id<8024&&((id-8000)%3)==1)names(kTargets,12);
 else if(id==6021){for(auto x:std::initializer_list<double>{.0625,.125,.25,.5,1.0})items.emplace_back(std::to_wstring(x)+L" s",x);}
 else if(it->stepped){for(int n=int(it->min);n<=int(it->max)&&n<=100;n++)items.emplace_back(std::to_wstring(n),n);}
 if(items.empty())return;
 HMENU menu=CreatePopupMenu();if(!menu)return;
 for(size_t i=0;i<items.size();i++)AppendMenuW(menu,MF_STRING|(std::abs(value(id)-items[i].second)<1e-6?MF_CHECKED:0),UINT_PTR(i+1),items[i].first.c_str());
 POINT point{c.x,c.y+c.h};int sx,sy,ox,oy;geometry(sx,sy,ox,oy);
 point.x=ox+int(double(point.x)*sx/kArtWidth);point.y=oy+int(double(point.y)*sy/kArtHeight);
 ClientToScreen(hwnd_,&point);
 const int picked=TrackPopupMenu(menu,TPM_RETURNCMD|TPM_LEFTALIGN|TPM_TOPALIGN|TPM_NONOTIFY,point.x,point.y,0,hwnd_,nullptr);
 DestroyMenu(menu);
 if(picked>0&&picked<=int(items.size())){beginGesture(id);change(id,items[size_t(picked-1)].second);endGesture();selectedPreset_=-1;}
}

void NativeEditor::openFactoryMenu(){
 HMENU menu=CreatePopupMenu();if(!menu)return;
 const wchar_t* families[]={L"Vitreous",L"Organic",L"Metallic",L"Cellular",L"Nocturnal",L"Aerial",L"Kinetic",L"Chimeric"};
 HMENU subs[8]{};
 for(int fam=0;fam<8;fam++){
  subs[fam]=CreatePopupMenu();
  for(int role=0;role<8;role++){
   const auto&patch=albedo_factory::patches[fam*8+role];
   AppendMenuW(subs[fam],MF_STRING,UINT_PTR(fam*8+role+1),patch.name);
  }
  AppendMenuW(menu,MF_POPUP,reinterpret_cast<UINT_PTR>(subs[fam]),families[fam]);
 }
 POINT pt{};GetCursorPos(&pt);
 int pick=TrackPopupMenu(menu,TPM_RETURNCMD|TPM_LEFTALIGN|TPM_TOPALIGN,pt.x,pt.y,0,hwnd_,nullptr);
 DestroyMenu(menu);
 if(pick<1||pick>64)return;
 const auto&patch=albedo_factory::patches[pick-1];
 applyingFactory_=true;
 for(size_t i=0;i<albedo_factory::parameterIds.size();i++){
  const auto id=albedo_factory::parameterIds[i];
  if(std::abs(value(id)-patch.values[i])>1e-6){beginGesture(id);change(id,patch.values[i]);endGesture();}
 }
 applyingFactory_=false;selectedPreset_=pick-1;invalidate();
}


void NativeEditor::drawSourceWaveforms(HDC dc){
 // CP12: native parameter-driven redraw in the four DOM-matched waveform slots.
 // The approved light/Nigredo bitmap remains the only backdrop. These are
 // controls' transfer/shape *illustrations*, not live audio measurements.
 constexpr int xs[4]={39,508,977,1446};
 constexpr COLORREF colors[4]={RGB(182,106,84),RGB(193,148,76),RGB(105,155,181),RGB(113,147,109)};
 for(int source=0;source<4;source++){
  const uint32_t base=1000u+uint32_t(source)*32u;
  const bool on=value(base+1u)>.5;
  const int method=std::clamp(int(std::round(value(base))),0,9);
  const double shape=std::clamp(value(base+6u)/100.0,0.,1.);
  const double colour=std::clamp(value(base+7u)/100.0,0.,1.);
  const double motion=std::clamp(value(base+8u)/100.0,0.,1.);
  const int x=xs[source],y=198,w=333,h=27;
  COLORREF bg=dark_?RGB(43,60,57):RGB(230,239,223);
  fill(dc,x,y,w,h,bg);
  line(dc,x,y+h/2,x+w,y+h/2,dark_?RGB(89,107,97):RGB(175,192,175),1);
  const COLORREF wave=on?colors[source]:(dark_?RGB(95,111,104):RGB(160,170,158));
  int prev=x+h/2;
  for(int i=0;i<w;i+=2){
   double amp=albedo_visual::sourceWave(method,shape,colour,motion,source,i,w);
   amp=std::clamp(amp,-1.,1.);
   int yy=y+h/2-int((h/2-4)*amp);
   if(i>0)line(dc,x+i-2,prev,x+i,yy,wave,on?2:1);
   prev=yy;
  }
  // GDI displays a deterministic synth-domain transfer curve; DSP waveform
  // tracing and FFT remain intentionally separate future host features.
 }
}

void NativeEditor::drawDynamicGraphs(HDC dc){
 // Parameter-driven native vector overlays. These are control response diagrams,
 // NOT spectrum measurements from the DSP or a microphone.
 const double bright=value(2000)/100.,ex=value(2001)/100.;
 const int sx=523,sy=740,sw=411,sh=38;
 fill(dc,sx,sy,sw,sh,dark_?RGB(33,60,57):RGB(225,235,224));
 for(int i=1;i<5;i++)line(dc,sx,sy+i*sh/5,sx+sw,sy+i*sh/5,(dark_?RGB(65,91,84):RGB(203,218,206)),1);
 for(int i=0;i<100;i++){
  double t=double(i)/99,amp=1.0-0.6*t+0.18*bright;
  double osc=(std::sin(i*(0.57+ex*0.5))*0.25+std::sin(i*2.9)*0.12)*std::exp(-t*0.9);
  int yy=sy+int(sh*(0.50-(amp*0.35+osc)*0.62));
  if(i>0){double q=double(i-1)/99,a=1.-.6*q+.18*bright;
   double osc0=(std::sin((i-1)*(.57+ex*.5))*.25+std::sin((i-1)*2.9)*.12)*std::exp(-q*.9);
   int y0=sy+int(sh*(.5-(a*.35+osc0)*.62));line(dc,sx+(i-1)*sw/99,y0,sx+i*sw/99,yy,RGB(88,150,140),2);}
 }
 const int ex0=964,ey0=740,ew=411,eh=38;
 fill(dc,ex0,ey0,ew,eh,dark_?RGB(33,60,57):RGB(226,235,225));
 const double attack=std::log1p(value(3100)*2)/std::log(17.);
 const double decay=std::log1p(value(3101))/std::log(11.);
 const double sustain=std::clamp(value(3102)/100.,0.,1.);
 const double release=std::log1p(value(3103))/std::log(19.);
 int p0=ex0+13,p1=p0+int(55*attack)+10,p2=p1+int(55*decay)+25,p3=ex0+ew-65-int(release*38),p4=ex0+ew-8;
 p3=std::max(p2+10,p3);int top=ey0+8,mid=ey0+eh-7-int(sustain*(eh-22)),bot=ey0+eh-7;
 line(dc,p0,bot,p1,top,RGB(171,110,79),4);line(dc,p1,top,p2,mid,RGB(171,110,79),4);
 line(dc,p2,mid,p3,mid,RGB(171,110,79),4);line(dc,p3,mid,p4,bot,RGB(171,110,79),4);
 for(auto v:std::initializer_list<std::pair<int,int>>{{p0,bot},{p1,top},{p2,mid},{p3,mid},{p4,bot}})circ(dc,v.first,v.second,4,RGB(219,180,101),RGB(161,112,62));
 for(int index=0;index<2;index++){
  int x=index?1420:1420,y=index?523:351,w=469,h=35;
  fill(dc,x,y,w,h,dark_?RGB(24,48,46):RGB(31,62,59));
  double cutoff=std::max(20.0,value(3000+3*index)),res=std::clamp(value(3001+3*index)/100.,0.,1.);
  double n=std::log(cutoff/20.)/std::log(1000.);
  int peak=x+int(w*std::clamp(n,0.,1.)),py=y+int(20-res*17);
  int previousY=y+11;
  for(int i=1;i<w;i+=3){int xx=x+i;
   double t=double(i)/w;
   int yy=y+7+int((h-11)*std::clamp((t-n)*6.,0.,1.));
   yy-=int(19*res*std::exp(-((t-n)*(t-n))/.0015));
   if(i>1)line(dc,xx-3,previousY,xx,yy,RGB(163,213,195),2);
   previousY=yy;
  }
  circ(dc,peak,py,4,RGB(236,205,130),RGB(190,154,84));
 }
 // Cellular automata pattern is a structural/morphological indicator.
 const int cx=603,cy=1034,cellw=12,cellh=11;
 int rules[]={30,90,110,150};int rule=rules[std::clamp(int(value(4003)),0,3)];
 unsigned row=1u<<16;
 for(int y=0;y<7;y++){
  for(int i=0;i<32;i++){
   bool active=(row>>(31-i))&1u;
   fill(dc,cx+i*cellw,cy+y*cellh,cellw-1,cellh-1,active?RGB(224,186,111):RGB(61,93,84));
  }
  unsigned next=0;
  for(int i=0;i<32;i++){unsigned a=(row>>((i+31)%32))&1u,b=(row>>i)&1u,c=(row>>((i+1)%32))&1u;
   unsigned bit=(unsigned(rule)>>((a<<2)|(b<<1)|c))&1u;next|=bit<<i;}
  row=next;
 }
 // Source node activation and selection outlines communicate network topology.
 const int nx[]={786,786,1111,1111},ny[]={371,496,371,496};
 for(int i=0;i<4;i++){
  if(value(1001+i*32)<.5)circ(dc,nx[i],ny[i],35,RGB(73,80,78),RGB(99,111,107));
  if(selected_==i){HBRUSH hollow=(HBRUSH)GetStockObject(HOLLOW_BRUSH);HPEN pen=CreatePen(PS_SOLID,4,RGB(223,187,118));auto op=SelectObject(dc,pen),ob=SelectObject(dc,hollow);Ellipse(dc,nx[i]-39,ny[i]-39,nx[i]+39,ny[i]+39);SelectObject(dc,ob);SelectObject(dc,op);DeleteObject(pen);}
 }
}
void NativeEditor::paint(HDC dc){
 FontCacheScope fontCacheGuard(fontCache_);
 int sx,sy,ox,oy;geometry(sx,sy,ox,oy);
 fill(dc,0,0,width_,height_,RGB(36,49,46));
 // Keep one compatible bitmap across paints: no 1600x1576 allocation per
 // mouse movement (CP09 Rubedo's responsive editor principle).
 if(!backingDC_)backingDC_=CreateCompatibleDC(dc);
 if(backingDC_&&!backingBitmap_){backingBitmap_=CreateCompatibleBitmap(dc,kArtWidth,kArtHeight);
  if(backingBitmap_)backingOriginal_=SelectObject(backingDC_,backingBitmap_);}
 if(!backingDC_||!backingBitmap_){fill(dc,0,0,width_,height_,RGB(235,236,217));return;}
 HDC backing=backingDC_;
 HBITMAP currentArt=(dark_&&artworkDark_)?artworkDark_:artwork_;
 if(currentArt){HDC source=CreateCompatibleDC(dc);HGDIOBJ orig=SelectObject(source,currentArt);BitBlt(backing,0,0,kArtWidth,kArtHeight,source,0,0,SRCCOPY);SelectObject(source,orig);DeleteDC(source);}
 else fill(backing,0,0,kArtWidth,kArtHeight,RGB(235,236,217));
 drawDynamicGraphs(backing);
 drawSourceWaveforms(backing);
 for(int i=0;i<int(controls_.size());i++)drawControl(backing,controls_[i],hover_==i||keyboardControl_==i);
 if(lab_)drawLab(backing);
 if(inspector_)drawInspector(backing);
 SetStretchBltMode(dc,HALFTONE);SetBrushOrgEx(dc,0,0,nullptr);
 StretchBlt(dc,ox,oy,sx,sy,backing,0,0,kArtWidth,kArtHeight,SRCCOPY);
}


void NativeEditor::resetControl(const NativeControl&c){
 if(c.kind==ControlKind::Source||c.kind==ControlKind::Button)return;
 const uint32_t id=resolve(c);
 auto it=std::find_if(parameters_.begin(),parameters_.end(),[id](const ParamDef&p){return p.id==id;});
 if(it==parameters_.end())return;
 beginGesture(id,c.kind==ControlKind::XY);
 change(id,it->def);
 if(c.kind==ControlKind::XY){auto y=std::find_if(parameters_.begin(),parameters_.end(),[](const ParamDef&p){return p.id==2101;});if(y!=parameters_.end())change(2101,y->def);}
 endGesture();selectedPreset_=-1;
}

void NativeEditor::selectAt(int x,int y,bool pressed){
 if(lab_){
  int hit=-1;for(int i=0;i<int(labControls_.size());i++)if(labControls_[i].contains(x,y))hit=i;
  int nextHover=hit>=0?hit+65536:-1;
  if(hover_!=nextHover){hover_=nextHover;invalidate();}
  if(!pressed)return;
  if(hit<0)return;
  const auto &c=labControls_[hit];
  if(c.kind==ControlKind::Source){selected_=std::clamp(int(c.id-0xFFF00000u),0,3);invalidate();return;}
  if(c.kind==ControlKind::Dial){drag_=hit+65536;startY_=y;startX_=x;startValue_=value(resolve(c));beginGesture(resolve(c));}
  else if(c.kind==ControlKind::Slider){drag_=hit+65536;startY_=y;startX_=x;beginGesture(resolve(c));edit(c,x,y,0);}
  else if(c.kind==ControlKind::Choice)openChoiceMenu(c);
  else {beginGesture(resolve(c));edit(c,x,y,1);endGesture();}
  return;
 }

 if(inspector_){const int px=240,py=124;int index=(y-py-117)/54+inspectorOffset_;if(y>=py+117&&y<py+1035&&x>=px&&x<px+1440){inspectorSelected_=std::clamp(index,0,int(parameters_.size())-1);if(pressed){drag_=-2;startX_=x;startY_=y;startValue_=value(parameters_[inspectorSelected_].id);beginGesture(parameters_[inspectorSelected_].id);}}invalidate();return;}
 int hit=-1;for(int i=0;i<int(controls_.size());i++)if(controls_[i].contains(x,y))hit=i;
 if(hover_!=hit){hover_=hit;invalidate();}
 if(!pressed)return;
 if(hit<0)return;
 const NativeControl&c=controls_[hit];if(c.kind==ControlKind::Source){selected_=std::clamp(int(c.id-0xFFF00000u),0,3);invalidate();return;}
 if(c.id==0xffe00007u){openFactoryMenu();return;}
 if(c.kind==ControlKind::Button){
  if(c.id==0xffe00001u){inspector_=false;lab_=true;invalidate();return;}
  if(c.id==0xffe00002u){MessageBoxW(hwnd_,L"F3: Synthesis Lab\nF2: Parameter Atlas\nTab: select next control (Shift reverses)\nCtrl+Tab: next source\nClick dropdowns for complete options\nShift + drag / wheel: fine control\nDouble-click: reset parameter\nSave the plugin state through your DAW.",L"Albedo · Native Controls",MB_OK|MB_ICONINFORMATION);return;}
  if(c.id==0xffe00003u){mutatePatch();return;}
  if(c.id==0xffe00004u){importPatch();return;}
  if(c.id==0xffe00005u){exportPatch();return;}
  if(c.id==0xffe00006u){dark_=!dark_;invalidate();return;}
  if(c.id==6020u){beginGesture(6020);change(6020,value(6020)>.5?0:1);endGesture();return;}
  return;
 }
 if(c.kind==ControlKind::Dial){drag_=hit;startY_=y;startX_=x;startValue_=value(resolve(c));beginGesture(resolve(c));}
 else if(c.kind==ControlKind::Slider||c.kind==ControlKind::XY){drag_=hit;startY_=y;startX_=x;beginGesture(resolve(c),c.kind==ControlKind::XY);edit(c,x,y,0);}
 else if(c.kind==ControlKind::Choice)openChoiceMenu(c);
 else {beginGesture(resolve(c));edit(c,x,y,1);endGesture();}
}
LRESULT CALLBACK NativeEditor::wndproc(HWND hwnd,UINT m,WPARAM wp,LPARAM lp){
 if(m==WM_NCCREATE){auto*cs=reinterpret_cast<CREATESTRUCTW*>(lp);if(!cs||!cs->lpCreateParams)return FALSE;SetWindowLongPtrW(hwnd,GWLP_USERDATA,reinterpret_cast<LONG_PTR>(cs->lpCreateParams));return TRUE;}
 auto*self=reinterpret_cast<NativeEditor*>(GetWindowLongPtrW(hwnd,GWLP_USERDATA));
 if(m==WM_CREATE){if(!self)return -1;self->hwnd_=hwnd;return 0;}
 if(!self)return DefWindowProcW(hwnd,m,wp,lp);
 return self->message(hwnd,m,wp,lp);
}
LRESULT NativeEditor::message(HWND w,UINT m,WPARAM wp,LPARAM lp){
 switch(m){
  case WM_GETDLGCODE:
   // Hosts often embed this HWND in dialog-like parents. Request arrows,
   // Tab and character navigation instead of allowing the parent to steal them.
   return DLGC_WANTARROWS|DLGC_WANTTAB|DLGC_WANTCHARS;
  case WM_ERASEBKGND:return 1;
  case WM_PAINT:{PAINTSTRUCT ps;HDC dc=BeginPaint(w,&ps);if(dc){RECT rect{};GetClientRect(w,&rect);width_=rect.right;height_=rect.bottom;paint(dc);}EndPaint(w,&ps);return 0;}
  case WM_SIZE:width_=LOWORD(lp);height_=HIWORD(lp);invalidate();return 0;
  case WM_DPICHANGED_AFTERPARENT:
   // On Win10+ per-monitor-DPI transitions the parent controls the child size;
   // repaint using the current client rectangle, not stale cached dimensions.
   invalidate();return 0;
  case WM_LBUTTONDOWN:{SetFocus(w);selectAt(ix(GET_X_LPARAM(lp)),iy(GET_Y_LPARAM(lp)),true);
   if(drag_>=0||drag_==-2)SetCapture(w);return 0;}
  case WM_LBUTTONDBLCLK:{int px=ix(GET_X_LPARAM(lp)),py=iy(GET_Y_LPARAM(lp));
   if(!lab_&&!inspector_){for(int i=int(controls_.size())-1;i>=0;i--)if(controls_[i].contains(px,py)){
     resetControl(controls_[i]);return 0;}}
   if(lab_){for(int i=int(labControls_.size())-1;i>=0;i--)if(labControls_[i].contains(px,py)){
     resetControl(labControls_[i]);return 0;}}
   return 0;}
  case WM_LBUTTONUP:{endGesture();drag_=-1;if(GetCapture()==w)ReleaseCapture();invalidate();return 0;}
  case WM_CAPTURECHANGED:endGesture();drag_=-1;return 0;
  case WM_MOUSELEAVE:
   if(hover_!=-1){hover_=-1;invalidate();}
   return 0;
  case WM_MOUSEMOVE:{
   if(!(wp&MK_LBUTTON)){
    TRACKMOUSEEVENT tme{sizeof(tme),TME_LEAVE,w,0};TrackMouseEvent(&tme);
   }
   int x=ix(GET_X_LPARAM(lp)),y=iy(GET_Y_LPARAM(lp));
   if(drag_>=65536&&drag_<65536+int(labControls_.size()))edit(labControls_[drag_-65536],x,y,0,(wp&MK_SHIFT)!=0);
   else if(drag_>=0&&drag_<int(controls_.size()))edit(controls_[drag_],x,y,0,(wp&MK_SHIFT)!=0);
   else if(drag_==-2&&inspectorSelected_>=0&&inspectorSelected_<int(parameters_.size())){auto&p=parameters_[inspectorSelected_];change(p.id,startValue_+(x-startX_)*(p.max-p.min)*0.0016);}
   else if(!(wp&MK_LBUTTON))selectAt(x,y,false);return 0;}
  case WM_MOUSEWHEEL:{POINT pos{GET_X_LPARAM(lp),GET_Y_LPARAM(lp)};ScreenToClient(w,&pos);int x=ix(pos.x),y=iy(pos.y);
   const int delta=GET_WHEEL_DELTA_WPARAM(wp);
   if(lab_){
    for(int i=int(labControls_.size())-1;i>=0;i--)if(labControls_[i].contains(x,y)&&labControls_[i].kind!=ControlKind::Source){
      uint32_t id=resolve(labControls_[i]);auto it=std::find_if(parameters_.begin(),parameters_.end(),[id](auto&p){return p.id==id;});
      if(it==parameters_.end())return 0;
      int dir=delta>0?1:-1;beginGesture(id);
      modify(id,it->stepped?dir:dir*((GET_KEYSTATE_WPARAM(wp)&MK_SHIFT)?0.002:0.015));endGesture();return 0;
    }return 0;
   }
   if(inspector_){wheelAccumulator_+=delta;int steps=wheelAccumulator_/WHEEL_DELTA;wheelAccumulator_%=WHEEL_DELTA;
    if(steps){inspectorOffset_=std::clamp(inspectorOffset_-steps*3,0,std::max(0,int(parameters_.size())-17));invalidate();}return 0;}
   for(int i=int(controls_.size())-1;i>=0;i--)if(controls_[i].contains(x,y)&&controls_[i].kind!=ControlKind::Source){const auto &c=controls_[i];uint32_t id=resolve(c);auto it=std::find_if(parameters_.begin(),parameters_.end(),[id](auto&p){return p.id==id;});if(it!=parameters_.end()){
    const bool stepped=it->stepped;double amount=double(delta)/WHEEL_DELTA;
    if(stepped){wheelAccumulator_+=delta;int steps=wheelAccumulator_/WHEEL_DELTA;wheelAccumulator_%=WHEEL_DELTA;
      if(!steps)return 0;amount=double(steps);}
    else wheelAccumulator_=0;
    beginGesture(id);
    if(!stepped)modify(id,amount*((GET_KEYSTATE_WPARAM(wp)&MK_SHIFT)?0.002:0.015));
    else modify(id,amount);
    endGesture();return 0;}}
   return 0;}
  case WM_RBUTTONUP:endGesture();drag_=-1;lab_=false;inspector_=!inspector_;invalidate();return 0;
  case WM_KEYDOWN:{if(wp==VK_F2){lab_=false;inspector_=!inspector_;invalidate();return 0;}
   if(wp==VK_F3){inspector_=false;lab_=!lab_;invalidate();return 0;}
   if(wp==VK_ESCAPE){inspector_=false;lab_=false;invalidate();return 0;}
   if(lab_){if(wp==VK_TAB){selected_=(selected_+1)%4;invalidate();}return 0;}
   if(inspector_){if(wp==VK_UP)inspectorSelected_=std::max(0,inspectorSelected_-1);else if(wp==VK_DOWN)inspectorSelected_=std::min(int(parameters_.size())-1,inspectorSelected_+1);else if(wp==VK_PRIOR)inspectorSelected_=std::max(0,inspectorSelected_-16);else if(wp==VK_NEXT)inspectorSelected_=std::min(int(parameters_.size())-1,inspectorSelected_+16);else if(wp==VK_LEFT||wp==VK_RIGHT){uint32_t id=parameters_[inspectorSelected_].id;
     beginGesture(id);modify(id,(wp==VK_RIGHT?1:-1)*((GetKeyState(VK_SHIFT)&0x8000)?0.001:0.02));endGesture();return 0;}
    if(inspectorSelected_<inspectorOffset_)inspectorOffset_=inspectorSelected_;if(inspectorSelected_>=inspectorOffset_+17)inspectorOffset_=inspectorSelected_-16;invalidate();return 0;}
   if(wp==VK_TAB){
    if(GetKeyState(VK_CONTROL)&0x8000){selected_=(selected_+1)%4;}
    else if(!controls_.empty()){
     int sign=(GetKeyState(VK_SHIFT)&0x8000)?-1:1;
     keyboardControl_=(keyboardControl_+sign+int(controls_.size()))%int(controls_.size());
    }
    invalidate();return 0;
   }
   if(keyboardControl_>=0&&keyboardControl_<int(controls_.size())){
    const NativeControl&focus=controls_[keyboardControl_];
    if((wp==VK_RETURN||wp==VK_SPACE)&&(focus.kind==ControlKind::Button||focus.kind==ControlKind::Choice||focus.kind==ControlKind::Toggle||focus.kind==ControlKind::Step||focus.kind==ControlKind::Source)){
     const int px=focus.x+focus.w/2,py=focus.y+focus.h/2;
     selectAt(px,py,true);return 0;
    }
    if((wp==VK_HOME||wp==VK_END)&&(focus.kind==ControlKind::Dial||focus.kind==ControlKind::Slider||focus.kind==ControlKind::Choice)){
     uint32_t id=resolve(focus);
     auto match=std::find_if(parameters_.begin(),parameters_.end(),[id](const ParamDef&p){return p.id==id;});
     if(match!=parameters_.end()){beginGesture(id);change(id,wp==VK_HOME?match->min:match->max);endGesture();}
     return 0;
    }
    if(wp==VK_UP||wp==VK_DOWN||wp==VK_LEFT||wp==VK_RIGHT){
     if(focus.kind==ControlKind::Source){selected_=int(focus.id-0xfff00000u);invalidate();return 0;}
     if(focus.kind==ControlKind::Dial||focus.kind==ControlKind::Slider||focus.kind==ControlKind::Choice){
      const uint32_t id=resolve(focus);
      const int direction=(wp==VK_UP||wp==VK_RIGHT)?1:-1;
      const double step=(GetKeyState(VK_SHIFT)&0x8000)?0.002:0.018;
      beginGesture(id);modify(id,direction*step);endGesture();return 0;
     }
     if(focus.kind==ControlKind::XY){
      uint32_t id=(wp==VK_LEFT||wp==VK_RIGHT)?2100u:2101u;
      const int direction=(wp==VK_UP||wp==VK_RIGHT)?1:-1;
      beginGesture(id);modify(id,direction*((GetKeyState(VK_SHIFT)&0x8000)?0.001:0.01));endGesture();return 0;
     }
    }
   }
   break;}
  case WM_DESTROY:endGesture();if(hwnd_==w)hwnd_=nullptr;return 0;
 }
 return DefWindowProcW(w,m,wp,lp);
}
} // namespace vitriol
#endif
