cmake_minimum_required(VERSION 3.18)
project(ALBEDO VERSION 1.0.0 LANGUAGES CXX)
set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
add_library(vitriol_dsp STATIC src/vitriol_dsp.cpp)
set_target_properties(vitriol_dsp PROPERTIES POSITION_INDEPENDENT_CODE ON)
target_include_directories(vitriol_dsp PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
if(MSVC)
 target_compile_options(vitriol_dsp PRIVATE /W4 /utf-8 /EHsc)
else()
 target_compile_options(vitriol_dsp PRIVATE -Wall -Wextra -Wpedantic)
endif()
add_executable(vitriol_render tests/render.cpp)
target_link_libraries(vitriol_render PRIVATE vitriol_dsp)
enable_testing()
add_test(NAME vitriol_voice_render COMMAND vitriol_render 48000 0)
add_test(NAME vitriol_granular_render COMMAND vitriol_render 88200 3)
add_test(NAME vitriol_additive_render COMMAND vitriol_render 96000 2)
add_test(NAME vitriol_cellular_render COMMAND vitriol_render 96000 9)
add_library(VITRIOL_CLAP MODULE src/clap_plugin.cpp)
target_link_libraries(VITRIOL_CLAP PRIVATE vitriol_dsp)
target_include_directories(VITRIOL_CLAP PRIVATE include)
set_target_properties(VITRIOL_CLAP PROPERTIES PREFIX "" OUTPUT_NAME "Albedo_Quintessential_Synth" SUFFIX ".clap")
if(UNIX AND NOT APPLE)
add_executable(vitriol_clap_smoke tests/clap_smoke.cpp)
target_include_directories(vitriol_clap_smoke PRIVATE include)
target_link_libraries(vitriol_clap_smoke PRIVATE dl)
add_test(NAME clap_host_smoke COMMAND vitriol_clap_smoke $<TARGET_FILE:VITRIOL_CLAP>)
endif()
# Official Steinberg VST3 SDK is an external dependency. No fake VST3 binary is emitted.
option(VITRIOL_BUILD_VST3 "Build VST3 from official Steinberg SDK" OFF)
set(VST3_SDK_DIR "" CACHE PATH "Path to VST3 SDK checkout with submodules")
if(VITRIOL_BUILD_VST3)
 if(NOT EXISTS "${VST3_SDK_DIR}/public.sdk/source/vst/vstaudioeffect.h")
  message(FATAL_ERROR "VST3_SDK_DIR must point to Steinberg's full official VST3 SDK")
 endif()
 set(SMTG_ENABLE_VST3_PLUGIN_EXAMPLES OFF CACHE BOOL "" FORCE)
 set(SMTG_ENABLE_VST3_HOSTING_EXAMPLES OFF CACHE BOOL "" FORCE)
 set(SMTG_ENABLE_VSTGUI_SUPPORT OFF CACHE BOOL "" FORCE)
 set(SMTG_CREATE_PLUGIN_LINK OFF CACHE BOOL "" FORCE)
 add_subdirectory("${VST3_SDK_DIR}" "${CMAKE_BINARY_DIR}/vst3sdk" EXCLUDE_FROM_ALL)
 smtg_add_vst3plugin(VITRIOL_VST3 src/vst3_plugin.cpp)
 target_link_libraries(VITRIOL_VST3 PRIVATE sdk vitriol_dsp)
 set_target_properties(VITRIOL_VST3 PROPERTIES OUTPUT_NAME "Albedo_Quintessential_Synth")
 target_include_directories(VITRIOL_VST3 PRIVATE include)
 target_compile_definitions(VITRIOL_VST3 PRIVATE FULL_VERSION_STR="1.0.0-cp12")
endif()
# Win32 editor follows Rubedo CP09 safe-input lessons and CP08R2 child HWND,
# embedded GDI bitmap + parameter-aware overlay controls; no WebView2 or browser runtime.
if(WIN32)
 enable_language(RC)
 # Absolute image path generated at CMake configure time: MSVC resource compiler
 # can find the bitmap regardless of the build working directory.
 set(VITRIOL_ART_PATH "${CMAKE_CURRENT_SOURCE_DIR}/resources/Albedo_Horizontal_Light.bmp")
 set(VITRIOL_DARK_ART_PATH "${CMAKE_CURRENT_SOURCE_DIR}/resources/Albedo_Horizontal_Nigredo.bmp")
 set(VITRIOL_BANK_PATH "${CMAKE_CURRENT_SOURCE_DIR}/resources/Albedo_Materia32_PCM24_96k.vtrb")
 configure_file("${CMAKE_CURRENT_SOURCE_DIR}/resources/albedo_native_win.rc.in"
                "${CMAKE_CURRENT_BINARY_DIR}/albedo_native_win.rc" @ONLY)
 set(VITRIOL_UI_SOURCES src/editor_native_win.cpp "${CMAKE_CURRENT_BINARY_DIR}/albedo_native_win.rc")
 target_sources(VITRIOL_CLAP PRIVATE ${VITRIOL_UI_SOURCES})
 target_compile_definitions(VITRIOL_CLAP PRIVATE VITRIOL_NATIVE_WIN=1 NOMINMAX WIN32_LEAN_AND_MEAN)
 target_link_libraries(VITRIOL_CLAP PRIVATE user32 gdi32 comdlg32)
 if(VITRIOL_BUILD_VST3)
  target_sources(VITRIOL_VST3 PRIVATE ${VITRIOL_UI_SOURCES})
  target_compile_definitions(VITRIOL_VST3 PRIVATE VITRIOL_NATIVE_WIN=1 NOMINMAX WIN32_LEAN_AND_MEAN)
  target_link_libraries(VITRIOL_VST3 PRIVATE user32 gdi32 comdlg32)
 endif()
endif()
add_executable(vitriol_native_layout_check tests/native_layout_check.cpp)
target_include_directories(vitriol_native_layout_check PRIVATE include)
add_test(NAME native_editor_layout_mapping COMMAND vitriol_native_layout_check)

# Deterministic GUI/DSP bridge QA, including SPSC producer-consumer thread stress.
find_package(Threads REQUIRED)
add_executable(vitriol_ui_event_queue_check tests/ui_event_queue.cpp)
target_include_directories(vitriol_ui_event_queue_check PRIVATE include)
target_link_libraries(vitriol_ui_event_queue_check PRIVATE Threads::Threads)
add_test(NAME native_ui_event_queue COMMAND vitriol_ui_event_queue_check)

# CP04 material-bank verification: 32 independent resources at 48/96kHz.
add_executable(vitriol_bank_integration tests/bank_integration.cpp)
target_link_libraries(vitriol_bank_integration PRIVATE vitriol_dsp)
add_test(NAME 32_materials_render COMMAND vitriol_bank_integration "${CMAKE_CURRENT_SOURCE_DIR}/resources/Albedo_Materia32_PCM24_96k.vtrb")

add_executable(vitriol_registry_export tests/export_registry.cpp)
target_include_directories(vitriol_registry_export PRIVATE include)

# CP06: targeted high-fidelity safety regressions (not perceptual certification)
add_executable(vitriol_cp06_quality tests/cp06_quality.cpp)
target_link_libraries(vitriol_cp06_quality PRIVATE vitriol_dsp)
add_test(NAME cp06_clickfree_routing_multirate COMMAND vitriol_cp06_quality)

# Optional offline 24-bit audition renderer, does not run inside a DAW.
add_executable(vitriol_audition tools/render_audition.cpp)
target_link_libraries(vitriol_audition PRIVATE vitriol_dsp)

add_executable(albedo_factory_qa tests/factory_qa.cpp)
target_link_libraries(albedo_factory_qa PRIVATE vitriol_dsp)
add_test(NAME cp07_64_factory_patch_audio COMMAND albedo_factory_qa "${CMAKE_CURRENT_SOURCE_DIR}/Presets/CP07_Quintessential_Collection" "${CMAKE_CURRENT_SOURCE_DIR}/resources/Albedo_Materia32_PCM24_96k.vtrb")

# CP07 verification of the complete native embedded factory-preset table.
add_executable(albedo_factory_header_qa tests/factory_header_qa.cpp)
target_include_directories(albedo_factory_header_qa PRIVATE include)
add_test(NAME cp07_embedded_factory_header COMMAND albedo_factory_header_qa)
add_executable(albedo_factory_audition tools/render_factory_audition.cpp)
target_link_libraries(albedo_factory_audition PRIVATE vitriol_dsp)

# CP08: Windows-native child HWND, 1920px origin hit regions, drag/XY/reset, scaled layout.
if(WIN32)
 add_executable(albedo_win32_gui_smoke tests/win32_gui_smoke.cpp src/editor_native_win.cpp "${CMAKE_CURRENT_BINARY_DIR}/albedo_native_win.rc")
 target_include_directories(albedo_win32_gui_smoke PRIVATE include)
 target_compile_definitions(albedo_win32_gui_smoke PRIVATE NOMINMAX WIN32_LEAN_AND_MEAN)
 target_link_libraries(albedo_win32_gui_smoke PRIVATE user32 gdi32 comdlg32)
 add_test(NAME cp08_win32_gui_interaction COMMAND albedo_win32_gui_smoke)
endif()

# CP09: semantic parity of native labels and DSP method character controls.
add_executable(albedo_ui_semantics_check tests/semantic_ui_check.cpp)
target_include_directories(albedo_ui_semantics_check PRIVATE include)
add_test(NAME cp09_additive_native_labels COMMAND albedo_ui_semantics_check)

# CP09-Nereida GUI parity: normalized dirty-state detection and Nereida-informed
# redraw efficiency. This is independent code (no Nereida DSP merged).
add_executable(albedo_ui_dirty_check tests/ui_dirty_check.cpp)
target_include_directories(albedo_ui_dirty_check PRIVATE include)
add_test(NAME cp09_nereida_gui_dirty_filter COMMAND albedo_ui_dirty_check)

if(WIN32)
 # Real editor executable, with the same source/resources as the CLAP/VST3 DLLs.
 add_executable(albedo_native_gui_preview WIN32 tests/win32_gui_preview.cpp
   src/editor_native_win.cpp "${CMAKE_CURRENT_BINARY_DIR}/albedo_native_win.rc")
 target_include_directories(albedo_native_gui_preview PRIVATE include)
 target_compile_definitions(albedo_native_gui_preview PRIVATE NOMINMAX WIN32_LEAN_AND_MEAN)
 target_link_libraries(albedo_native_gui_preview PRIVATE user32 gdi32 comdlg32)
endif()

# RG​NES CP10 source contract. Windows compilation is separately gated by PE checks.
find_package(Python3 COMPONENTS Interpreter QUIET)
if(Python3_Interpreter_FOUND)
 add_test(NAME cp10_rgnes_source_gate COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tests/rgnes_cp10_source_gate.py")
endif()

# CP11: validate raw PE32+ AMD64 DLL export parser with synthetic CLAP/VST3
# export tables; real Win64 outputs are audited by Build_Windows_x64.ps1.
if(Python3_Interpreter_FOUND)
 add_test(NAME cp11_win64_pe_export_gate_unit
   COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tests/verify_pe_audit.py")
endif()

# CP11: immutable source-art/audio assets and 64 factory preset completeness.
if(Python3_Interpreter_FOUND)
 add_test(NAME cp12_source_assets_exact
  COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/verify_source_assets.py")
endif()

# CP12: visual source-domain response is pure C++ and validated without Win32.
add_executable(albedo_cp12_wave_qa tests/gui_waveform_qa.cpp)
target_include_directories(albedo_cp12_wave_qa PRIVATE include)
add_test(NAME cp12_native_dynamic_source_waves COMMAND albedo_cp12_wave_qa)
# CP12 proportional viewport hit-target regression (all mapped controls, 8 host sizes).
add_executable(albedo_cp12_viewport_qa tests/native_viewport_parity.cpp)
target_include_directories(albedo_cp12_viewport_qa PRIVATE include)
add_test(NAME cp12_native_viewport_hit_regions COMMAND albedo_cp12_viewport_qa)
