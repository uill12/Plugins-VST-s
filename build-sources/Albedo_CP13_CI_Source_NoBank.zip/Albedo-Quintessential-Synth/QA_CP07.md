# CP07 QA — Albedo Quintessential Synth

**Checkpoint:** CP07 · 2026-11-15 · v1.0.0-cp07-horizontal

## Completed and reproducible

- New product metadata: `Albedo Quintessential Synth` for CLAP and VST3 factory descriptors. The legacy CLAP ID and VST3 class UIDs remain for existing host sessions.
- FM synthesis removed from the DSP method 2, and the former operator controls relabeled/reused as additive harmonic partial count and spectral tilt. Not a bypass or hidden FM mode: the oscillator code is additive.
- 197 host IDs unchanged; 8 repurposed FM-operator numeric controls have new additive meaning, so historical FM sounds are not sonically backward-compatible.
- 64 new `.albp` presets, eight material families × eight functional roles; 32 unique PCM24/96k materials selected. Original 24 sketches archived for rollback.
- Native editor contains 64 statically embedded complete parameter snapshots; independent checks verify 64 × 197 values and bounds.
- GUI HTML renders with no JavaScript exceptions at 1920 px and displays 64 new entries plus one unsaved state. No WebView2 dependency for native Windows editor.
- No clips/nonfinite values in the 64-patch short audio QA; distinct PCM fingerprints across presets, and each patch has at least one active bank-based synth engine.
- Harmonic tilt tables computed during prepare, not recalculated via `pow()` in the audio callback.

## CTest results

| Test | Status |
|---|---|
| Voice 48 kHz | PASS |
| Granular 88.2 kHz | PASS |
| Additive 96 kHz | PASS |
| Cellular 96 kHz | PASS |
| CLAP host ABI smoke test (Linux) | PASS |
| Native editor coordinate registry | PASS |
| GUI parameter event queue | PASS |
| 32 PCM material resource render | PASS |
| Click-reduction, filter routing and multirate CP06 regressions | PASS |
| 64 factory patches: metadata, bank access, live audio, level limits, diversity | PASS |
| Embedded 64 factory snapshots × 197 IDs | PASS |

**Summary: 11/11 PASS on Linux.** These tests don't execute the Win32 editor or certify Windows CLAP/VST3 in Bitwig.

## Windows validation status

**Not compiled.** The execution environment has no MSVC/MinGW toolchain and cannot resolve public package hosts to download SDKs. `Build_Windows_x64.ps1` and GitHub Actions workflow source are included for a proper Windows build, but no Windows DLL, CLAP, or VST3 bundle is asserted to exist. Host automation, patch menu, native controls, CPU and memory usage must be tested in Bitwig for Windows.

## Demo render

The optional `albedo_factory_audition` tool renders 8 representative factory patches to 16.0 s stereo PCM24/48 kHz. This is a DSP render for comparison, not a mastering or subjective hi-fi certificate. The checkpoint delivery includes the separately linked audition WAV.
