# CP09 Nereida Bridge — Test report

## Actual source data acquired

No CP40 source bytes. Library metadata confirmed the existence of `Nereida_v0.40.1_CP40_Full_Source.zip` (29,592,126 bytes); two authorized materialization attempts failed with an inaccessible raw-byte path. Its contents and licenses were not inspected. The older Nereida checkpoint reports informed the design but their code was not copied.

## Implemented locally

- Independent normalized dirty-state tracker for Albedo editor parameter redraw (0.0025 tolerance, exact discrete values, invalid numerical input ignored).
- Native hover no-op repaint suppression and `WM_MOUSELEAVE` reset.
- Standalone Windows GUI preview target from the same source and bitmap resources as the actual plugin; F12 BMP capture.
- Safe staging script for the user's CP40 ZIP, with path checking, audio/binary exclusion, SHA-256 output and review-only status.
- Existing Albedo DSP/bank/preset data unchanged; 197 IDs, 64 factory patches, 32 PCM materials.

## Tests run here

- **13/13 ctest Linux PASS** (see `CTEST_NEREIDA_BRIDGE.txt`).
- **Synthetic ZIP importer safety PASS**: three staged mock text files; path traversal/audio/binaries omitted. **Not a test on CP40 itself**.
- **Native control registry static check PASS**: 102 hit regions, 8 intentional containment overlaps.
- **Windows DLL, VST3 bundle, interactive Win32 editor and Bitwig NOT run**. No claim of native screenshot parity or production-ready fidelity.

## Remaining dependency

Obtain an accessible local copy of the real CP40 source archive, execute the controlled scanner and review each candidate for reusability. Build Windows CLAP/VST3 from the official VST3 SDK; capture native GUI at multiple DPI/resize contexts and compare to HTML reference; run host automation/audio/preset QA in Bitwig.
