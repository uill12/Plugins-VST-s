# Albedo Quintessential Synth — CP09 Nereida Reference Bridge

**Purpose:** Continue Albedo's responsive/native GUI quality pass using established practices from the Nereida project, while preserving Albedo's synthesis architecture and artistically approved horizontal graphics.

## Source provenance and status

- Identified current Nereida source archive: `Nereida_v0.40.1_CP40_Full_Source.zip` in the user's ChatGPT Library, under `Nereida IntraSynth`.
- The Library exposed the file's metadata but denied exporting its binary bytes into this workspace. Accordingly **no Nereida CP40 code, shaders or audio resources were imported**.
- The present checkpoint includes an Albedo-authored compatible implementation of two Nereida-documented UI principles: normalized dirty-state handling and native GUI-only preview harness. The code is not copied from Nereida.

## Concrete implemented work

1. `include/albedo_ui_dirty.hpp` and `tests/ui_dirty_check.cpp`: normalized parameter invalidation threshold 0.0025, quantized values exact, non-finite protection and 20k jitter suppression.
2. `src/editor_native_win.cpp`: avoids continuously invalidating the full canvas under unchanged hover positions; clears hover state on mouse leave.
3. `tests/win32_gui_preview.cpp`: a **real Win32 native editor** executable with resizable parent and F12 bitmap screenshot. Same GUI source and GDI artwork resources as the CLAP and VST3 targets. Requires Windows compilation, not audio output.
4. `tools/import_nereida_cp40.py`: audited, source-only Nereida ZIP staging with SHA256 per file, path traversal defense, symlink/audio/binary exclusion and no silent DSP/transplant.
5. `tests/test_nereida_importer.py`: synthetic ZIP used only to test scanner safety, not the real Nereida archive.
6. Windows build script now checks the stand-alone preview is a genuine AMD64 PE executable before including it with the CLAP/VST3 artifacts.

## How to build on Windows

```powershell
powershell -ExecutionPolicy Bypass -File .\Build_Windows_x64.ps1 -Configuration Release
```

After compilation the Windows distribution includes `albedo_native_gui_preview.exe`. Launch it to test UI gestures and F12 to save `Albedo_CP09_Native_Editor_Capture.bmp` for pixel parity review. Then test actual CLAP/VST3 in Bitwig with host automation, CLAP resize, VST3 state recall, MIDI, preset change and audio playback.

## Validation

- Linux DSP and native-independent GUI tests: **13/13 passed** (CLAP smoke, source mapping, 64 factory presets, 32 materials and dirty-state suite).
- Synthetic-importer safety test: passed. All real Nereida resources remain unextracted.
- Windows PE and native GUI: **not built or run here**.
- Pixel-identical native/HTML parity, GPU/WGL and Bitwig behavior: **not certified**.
